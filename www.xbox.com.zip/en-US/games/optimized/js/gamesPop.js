$(document).ready(function() {

    var urlRegion = document.URL.split("/")[3].toLowerCase();
  
    if (urlRegion === "fr-fr") {
      $(".rotator-heading h3").each(function(i) {
        $(this).after('<span class="disclosureContainer">' +
            '<button class="glyph-prepend glyph-prepend-info" type="button" aria-describedby="frDisclosure' + i + '"></button>' +
            '<div class="c-flyout f-beak frDisclosure" id="frDisclosure' + i + '" role="tooltip" data-js-flyout-placement="top" data-js-flyout-dismissible="true" aria-hidden="true">' +
              '<button tabindex="0" class="disclosureClose" aria-label="bouton de fermeture pour l\'info-bulle">' +
              '<img src="https://assets.xboxservices.com/assets/3b/df/3bdfab2d-d1b1-4019-9bac-d953db4fd7fb.svg?n=Games-Catalog_Image-0_X-Button_230x120.svg" alt="bouton de fermeture">' +
            '</button>' +
              '<p class="c-paragraph">Voir <a href="https://www.microsoft.com/fr-fr/store/b/imprint" target="_blank">mentions légales et informations consommateurs</a> pour ' +
              'plus d\'informations sur les critères de classement.</p>' +
            '</div>' +
          '</span>')
      })
      $(".disclosureContainer .glyph-prepend").click(function() {
        const butInd = $(this).index(".glyph-prepend");
        
        setTimeout(function() {
          if ($(".frDisclosure").css("display") !== 'none') {
            if ($(".CatAnnounce").text() === "l'info-bulle s'est ouverte") {
              $(".CatAnnounce").text("l'info-bulle s'est ouverte.")
            } else {
              $(".CatAnnounce").text("l'info-bulle s'est ouverte")
            }
          } else {  
            $(".CatAnnounce").text("l'info-bulle s'est fermée")
          }
          $(".disclosureClose")[butInd].focus()
        }, 30)
      })
      $(".disclosureClose").click(function() {
        $(this).closest(".c-flyout").prev("button").click();
      })
    }
  
    var recentOptimizedListUrl = "https://reco-public.rec.mp.microsoft.com/channels/Reco/V8.0/Lists/Computed/new?Market=" + urlRegion.split("-")[1] + "&Language=" + urlRegion.split("-")[0] + "&ItemTypes=Game&deviceFamily=Windows.Xbox&gamecapabilities=ConsoleGen9Optimized&count=15&skipitems=2";
    //var bestSellersListUrl = "https://reco-public.rec.mp.microsoft.com/channels/Reco/V8.0/Lists/Computed/toppaid?Market=" + urlRegion.split("-")[1] + "&Language=" + urlRegion.split("-")[0] + "&ItemTypes=Game&deviceFamily=Windows.Xbox&count=15&skipitems=0";
  
    var recentOptimizedArray = [];
    var bestSellersListArray = []
  
    // Get GUIDS
    $.get(recentOptimizedListUrl)
        .done(function(responseData) {
            responseData.Items.forEach(function(e) {
                recentOptimizedArray.push(e.Id)
            })
  
            var recentOptimizedGuids = recentOptimizedArray.join(",")

            gamesPop(recentOptimizedGuids);
/*
  
            $.get(bestSellersListUrl)
                .done(function(responseData) {
                    responseData.Items.forEach(function(e) {
                        bestSellersListArray.push(e.Id)
                    })
  
                    var bestSellersGuids = bestSellersListArray.join(",")
  
                    gamesPop(recentOptimizedGuids, bestSellersGuids);
  
                })*/
        })
  
  
  
    function gamesPop(recentOptimized) {
  
        var countryCode = urlRegion.split("-")[1].toUpperCase();
        var guidUrlrecentOptimized = 'https://displaycatalog.mp.microsoft.com/v7.0/products?bigIds=GAMEIDS&market=' + countryCode + '&languages=' + urlRegion + '&MS-CV=DGU1mcuYo0WMMp+F.1'
        //var guidUrlbestSellers = 'https://displaycatalog.mp.microsoft.com/v7.0/products?bigIds=GAMEIDS&market=' + countryCode + '&languages=' + urlRegion + '&MS-CV=DGU1mcuYo0WMMp+F.1'
  
        guidUrlrecentOptimized = guidUrlrecentOptimized.replace("GAMEIDS", recentOptimized);
        //guidUrlbestSellers = guidUrlbestSellers.replace("GAMEIDS", bestSellers);
  
        $.get(guidUrlrecentOptimized)
            .done(function(responseData) {
                var recentOptimizedData = responseData;
                console.log("recentOptimizedData " + recentOptimizedData);
  
                populateRecentOptimized(recentOptimizedData);
            })
  /*
        $.get(guidUrlbestSellers)
            .done(function(responseData) {
                var bestSellersData = responseData;
                console.log("bestSellersData " + bestSellersData);
  
                populateBestSellers(bestSellersData);
            })
            */
    }
  
  
    function populateRecentOptimized(data) {
        var bigidUrls = biUrls.items.urls;
        var biuArray = Object.keys(bigidUrls);
  
        var productQuantity = data.Products.length;
  
        for (var x = 0; x < productQuantity; x++) {
            // Item Id/Title
            var itemId = data.Products[x].ProductId.toUpperCase();
            var itemTitle = data.Products[x].LocalizedProperties[0].ProductTitle;
            var itemGenre = data.Products[x].Properties.Category;
            console.log("itemGenre " + itemGenre);
            if (itemTitle === undefined) {
                itemTitle = "";
            }
            var itemUrlName = itemTitle.toLowerCase().replace(/\s/g, "-").replace(/[^a-z0-9-]/gi, "");
            if (itemUrlName === "") {
                itemUrlName = "-"
            }
  
            var shortDesc = data.Products[x].LocalizedProperties[0].ShortDescription;
            if (shortDesc === "") {
                shortDesc = data.Products[x].LocalizedProperties[0].ProductDescription;
            }
            if (shortDesc === undefined) {
                shortDesc = "";
            }
  
            var imagesNum = data.Products[x].LocalizedProperties[0].Images.length;
            var imgEnd = 999;
  
            for (var j = 0; j < imagesNum; j++) {
                if (data.Products[x].LocalizedProperties[0].Images[j].ImagePurpose === "Poster") {
                    imgEnd = j;
                    break;
                }
            }
  
            if (imgEnd === 999) {
                for (var j = 0; j < imagesNum; j++) {
                    if (data.Products[x].LocalizedProperties[0].Images[j].Width < data.Products[x].LocalizedProperties[0].Images[j].Height) {
                        imgEnd = j;
                        break
                    }
                }
            }
  
            if (imgEnd === 999) {
                imgEnd = 1;
            }
  
            // Grabbing Image Path
            if (data.Products[x].LocalizedProperties[0].Images[imgEnd]) {
                var itemBoxshot = data.Products[x].LocalizedProperties[0].Images[imgEnd].Uri.replace("http:", "https:");
                var itemBoxshotSmall;
            } else {
                var itemBoxshot = "https://assets.xboxservices.com/assets/d4/da/d4da80b7-2e08-425c-adb3-e279c152adec.jpg?n=X1-Standard-digital-boxshot_584x800.jpg";
                var itemBoxshotSmall = "https://assets.xboxservices.com/assets/d4/da/d4da80b7-2e08-425c-adb3-e279c152adec.jpg?n=X1-Standard-digital-boxshot_584x800.jpg";
            }
            if (itemBoxshot.indexOf("store-images") !== -1) {
                itemBoxshotSmall = itemBoxshot + "?w=140";
                // itemBoxshot = itemBoxshot + "&h=300&w=200&format=jpg";
                itemBoxshot = itemBoxshot + "?w=280";
            } else {
                itemBoxshotSmall = itemBoxshot;
            }
  
            // URL
            if (biuArray.indexOf(itemId) === -1 || bigidUrls[itemId].toLowerCase().indexOf(urlRegion) !== -1) {
                var itemhref = 'https://www.xbox.com/' + urlRegion + '/games/store/' + itemUrlName + '/' + itemId;
            } else {
                var itemhref = bigidUrls[itemId].split("<exc>")[0];
                var splitHref = itemhref.split("/");
                splitHref.splice(3, 0, urlRegion);
                itemhref = splitHref.join("/");
            }
  
            $(".recentOptimized" + " ul").append('<li>' +
                '<section class="m-product-placement-item f-size-large context-device" data-prodid="' + itemId + '">' +
                '<a target="blank" href="' + itemhref + '" data-retailer="MS Store" aria-label="' + itemTitle + ', ' + itemGenre + '">' +
                '<picture>' +
                '<source srcset="' + itemBoxshot + '" media="(min-width:0)">' +
                '<img class="c-image" srcset="' + itemBoxshot + '" src="' + itemBoxshot + '" ' +
                'alt="' + itemTitle + ' boxshot">' +
                '</picture>' +
                '<div class="slide-content high-contrast">' +
                '<h3 class="c-heading-6 f-lean" itemprop="game name">' + itemTitle + '</h3>' +
                '<p class=" c-caption-1">' + itemGenre + '</p>' +
                '</div>' +
                '</a>' +
                '</section>' +
                '</li>')
  
        }
        $(".recentOptimized").closest(".featured-games").fadeIn("slow");
  
  
    }
  
  
  });