$(document).ready(function() {

    $(".hero-product-placement").each(function(index) {
        let ppGroup = $(this).find(".m-product-placement");
        ppGroup.each(function(index) {
            $(this).removeClass("hidden"); // removing legacy class that doesn't work
            if (index !== 0) {
                $(this).addClass("pp-hidden");
            } else {
                $(this).removeClass("pp-hidden");
            }
        });
    });

    // mutation observer to detect changes when hero class changes ("f-active") and call ppWrangler accordingly
    let config = {
        attributes: true,
        attributeFilter: ['class'],
        subtree: true
    };
    let heroObserver = new MutationObserver(ppWrangler);

    let ppHeroes = $(".hero-product-placement");
    let heroList = new Array();
    $(ppHeroes).each(function(index) {
        heroList[index] = $(this).find(".center-carousel").get(0);
        let theTarget = heroList[index];
        heroObserver.observe(theTarget, config);

    });

    // ============================================================

    // Multiple elements are observed. This function needs to know which element (hero) has changed so it only acts upon relevent PPs..
    function ppWrangler(mutations) {

        for (var mutation of mutations) {
            // mutation.target is the element that is acted upon. Further operations are relevant only to this hero/pp group.
            if ($(mutation.target).hasClass("panel-show")) {

                var newActive = $(mutation.target).closest(".hero-product-placement").find(".center-carousel .stealth-sub-carousel-panel.panel-show");
                var newActiveIndex = $(newActive).index();

                var productPlacements = $(newActive).closest(".hero-product-placement").find(".m-product-placement");
                $(productPlacements).addClass("pp-hidden");
                $(productPlacements).eq(newActiveIndex).removeClass("pp-hidden");
                // ^^^^^^ $(productPlacements).eq(newActiveIndex) -- acts on product placement in same order it appears in the HTML as hero item. 
                // REQUIRES PPs to be in order and same number of PPs as hero items.
                //themeWrangler();
            }
        };
    }
    // theme wrangler to make PP banner and blurb match hero theme
    $(".hero-product-placement .stealth-carousel .center-carousel").each(function() {
        $(this).find(".m-hero-item").each(function(index) {
            //console.log($(this).find("h2").html() + " " + index);
            if ($(this).hasClass("theme-dark")) {
                //console.log($(this).find("h2").html() + " " + "hasClass theme-dark");

                $(this).closest(".hero-product-placement").find(".m-product-placement").eq(index).find(".m-banner").addClass("theme-dark");
            } else {
                //console.log($(this).find("h2").html() + " " + "does not hasClass theme-dark");

                $(this).closest(".hero-product-placement").find(".m-product-placement").eq(index).find(".m-banner").addClass("theme-light");
            }
        });
    });


    // make screen reader read the hero flipper button every time it's activated

    $(".hero-product-placement .m-hero .c-flipper").on("click", function() {
        $(".hero-product-placement .m-hero .c-flipper").removeClass("x-hidden-focus");
        thisArrow = $(this);
        $(thisArrow).attr("aria-live", "polite");
        thisArrowAria = $(thisArrow).attr("aria-label");
        $(thisArrow).attr({ "aria-label": "", "style": "display: none;" });
        $(thisArrow).blur();
        $(thisArrow).attr({ "aria-label": thisArrowAria, "style": "display: block;" });
        setTimeout(function() {
            $(thisArrow).focus();
        }, 10);
    });

    $(".hero-product-placement .m-hero .c-flipper").removeClass("x-hidden-focus");


    function ppFlipperHeights(){
        // adjust flipper heights based on add-on image size
        var flipperHeight = $(".product-placements-container .m-product-placement-item picture").first().height() / 2 + 16;
        //console.log("flipperHeight " + flipperHeight);
        $(".product-placements-container .m-product-placement .c-flipper").css('top', flipperHeight + "px");
    }

    function checkLoaded() { 
        setTimeout(function() {
            if ($(".product-placements-container .m-product-placement-item picture").first().height() > 0){
                //console.log("calling ppFlipperHeights");
                ppFlipperHeights();
                //clearTimeout(timer);
            } else {
                //console.log("going around again ");
                checkLoaded();
            }
        }, 250)
    }

    checkLoaded();

    $(window).on("resize", function() {
        ppFlipperHeights();
    }); 


});


