$(document).ready(function() {
    regionContent = globalContent.locales[urlRegion];

    // noncloud regions
    const nonCloudRegions = "ar-ae, ar-sa, el-gr, en-hk, en-in, en-sg, en-za, es-cl, es-co, he-il, ru-ru, tr-tr, zh-hk, zh-tw";

    if (urlRegion === "en-ae") {
        urlRegion = "ar-ae";
    } else if (urlRegion === "en-sa") {
        urlRegion = "ar-sa";
    } else if (urlRegion === "en-il") {
        urlRegion = "he-il";
    }

    var ratingsApi = (function() {
        var ratingsUrl = "https://displaycatalog.mp.microsoft.com/v7.0/ratings?market=US&languages=LANG&MS-CV=DGU1mcuYo0WMMp+F.1";
        ratingsUrl = ratingsUrl.replace("US", urlRegion.split("-")[1]).replace("LANG", urlRegion);

        $.get(ratingsUrl).done(function(listData) {
            ratingData = listData;
            grabLists();
        });
    }
    )();

    var listArray = ["TopFree:topfree", "MostPlayed:mostplayed"];
    // Options: "TopPaid:toppaid", "New:newreleases", "BestRated:bestrated", "ComingSoon:upcoming", "Deal:onsale", "TopFree:topfree", "MostPlayed:mostplayed"
    var capArray = [];
    // Options: "&gamecapabilities=capabilityxboxenhanced:enhanced", "&gamecapabilities=capability4k:fourk", "&gamecapabilities=capabilityhdr:HDRGaming", "&NumberOfPlayers=SinglePlayer:singleplayer", "&NumberOfPlayers=OnlineMultiplayerWithGold:multionline", "&NumberOfPlayers=LocalMultiplayer:multilocal", "&NumberOfPlayers=CoopSupportOnline:cooponline", "&NumberOfPlayers=CoopSupportLocal:cooplocal", "&gamecapabilities=XPA:xpa", "&gamecapabilities=gamestreaming:cloud", "&gamecapabilities=consolecrossgen:cross", "&gamecapabilities=ConsoleGen9Optimized:genNine"
    var addonArray = [];

    function grabLists() {
        var recoUrl = "https://reco-public.rec.mp.microsoft.com/channels/Reco/V8.0/Lists/Computed/LIST?Market=US&Language=EN&ItemTypes=Game&deviceFamily=Windows.Xbox&count=2000&skipitems=0";
        recoUrl = recoUrl.replace("US", urlRegion.split("-")[1]).replace("EN", urlRegion.split("-")[0]);

        var capUrls = ["https://reco-public.rec.mp.microsoft.com/channels/Reco/V8.0/Lists/Computed/TopFree?Market=" + urlRegion.split("-")[1] + "&Language=" + urlRegion.split("-")[0] + "&ItemTypes=Game&deviceFamily=Windows.XboxCAPABILITY&count=2000&skipitems=0", ];

        // grab indie SIGL list
        gameIdArrays["indie"] = [];
        fullGameArray = [];
        excludebids = ["C5GDG0CQ99RJ", "9MZCQQK860T1"];
        var cloudUrl = "https://catalog.gamepass.com/sigls/v2?id=95f39cf3-48ec-4d3c-83e6-a7f6916fbdfe&language=" + urlRegion.split("-")[0] + "&market=" + urlRegion.split("-")[1];
        $.get(cloudUrl).done(function(listData) {
            listData.forEach(function(b) {
                if (gameIdArrays["indie"] && gameIdArrays["indie"].indexOf(b.id) === -1 && b.id !== undefined) {
                    gameIdArrays["indie"].push(b.id);
                }
            });
            cloudList();
        });

        // grab cloud sigl list
        function cloudList() {
            var cloudUrl = "https://catalog.gamepass.com/sigls/v2?id=29a81209-df6f-41fd-a528-2ae6b91f719c&language=" + urlRegion.split("-")[0] + "&market=" + urlRegion.split("-")[1];
            $.get(cloudUrl).done(function(listData) {
                listData.forEach(function(b) {
                    if (gameIdArrays["cloud"] && gameIdArrays["cloud"].indexOf(b.id) === -1 && b.id !== undefined) {
                        gameIdArrays["cloud"].push(b.id);
                    }
                });
                mainLists();
            });
        }

        // main list arrays
        function mainLists() {
            for (var i = 0; i < listArray.length; i++) {
                (function(i) {
                    var listreplace = listArray[i].split(":")[0];
                    var arrayname = listArray[i].split(":")[1];
                    gameIdArrays[arrayname] = [];
                    var listUrl = recoUrl.replace("LIST", listreplace);
                    $.get(listUrl).done(function(responseData) {
                        var totalitems = responseData.PagingInfo.TotalItems;
                        responseData.Items.forEach(function(e) {
                            if (excludebids.indexOf(e.Id) === -1) {
                                gameIdArrays[arrayname].push(e.Id);
                            }
                            if (fullGameArray.indexOf(e.Id) === -1 && excludebids.indexOf(e.Id) === -1) {
                                fullGameArray.push(e.Id);
                            }
                        });
                        if (totalitems > 200) {
                            var chunks = Math.ceil(totalitems / 200);
                            largeList(listUrl, arrayname, chunks);
                        }
                        if (i === listArray.length - 1) {
                            var recoactivecheck = setInterval(function() {
                                var recoactiveAjax = $.active;
                                if (recoactiveAjax === 0) {
                                    recodone();
                                    clearInterval(recoactivecheck);
                                }
                            }, 500);
                        }
                    });
                }
                )(i);
            }
        }

        // capability list arrays
        for (var i = 0; i < capArray.length; i++) {
            var arrayname = capArray[i].split(":")[1];
            gameIdArrays[arrayname] = [];
        }
        for (var i = 0; i < capUrls.length; i++) {
            (function(i) {
                for (var j = 0; j < capArray.length; j++) {
                    (function(j) {
                        var listreplace = capArray[j].split(":")[0];
                        var arrayname = capArray[j].split(":")[1];
                        var listUrl = capUrls[i].replace("CAPABILITY", listreplace);
                        $.get(listUrl).done(function(responseData) {
                            var totalitems = responseData.PagingInfo.TotalItems;
                            responseData.Items.forEach(function(e) {
                                if (gameIdArrays[arrayname] && gameIdArrays[arrayname].indexOf(e.Id) === -1 && excludebids.indexOf(e.Id) === -1) {
                                    gameIdArrays[arrayname].push(e.Id);
                                }
                            });
                            if (totalitems > 200) {
                                var chunks = Math.ceil(totalitems / 200);
                                largeList(listUrl, arrayname, chunks, true);
                            }
                        });
                    }
                    )(j);
                }
            }
            )(i);
        }

        function largeList(url, arrayname, chunks, cap) {
            for (var i = 1; i < chunks; i++) {
                (function(i) {
                    var skipnum = 200 * i;
                    var largeUrl = url.replace("skipitems=0", "skipitems=" + skipnum);
                    $.get(largeUrl).done(function(responseData) {
                        responseData.Items.forEach(function(e) {
                            if (cap === true) {
                                if (gameIdArrays[arrayname] && gameIdArrays[arrayname].indexOf(e.Id) === -1 && excludebids.indexOf(e.Id) === -1) {
                                    gameIdArrays[arrayname].push(e.Id);
                                }
                            } else {
                                if (excludebids.indexOf(e.Id) === -1) {
                                    gameIdArrays[arrayname].push(e.Id);
                                }
                                if (fullGameArray.indexOf(e.Id) === -1 && excludebids.indexOf(e.Id) === -1) {
                                    fullGameArray.push(e.Id);
                                }
                            }
                        });
                    });
                }
                )(i);
            }
        }

        function recodone() {
            for (var i = 0; i < listArray.length; i++) {
                var arrayname = listArray[i].split(":")[1];
                for (var j = 0; j < gameIdArrays[arrayname].length; j++) {
                    if (fullGameArray.indexOf(gameIdArrays[arrayname][j]) === -1 && excludebids.indexOf(gameIdArrays[arrayname][j]) === -1) {
                        fullGameArray.push(gameIdArrays[arrayname][j]);
                    }
                }
            }
            if (gameIdArrays["cloud"]) {
                for (var j = 0; j < gameIdArrays["cloud"].length; j++) {
                    if (fullGameArray.indexOf(gameIdArrays["cloud"][j]) === -1 && excludebids.indexOf(gameIdArrays["cloud"][j]) === -1) {
                        fullGameArray.push(gameIdArrays["cloud"][j]);
                    }
                }
            }
            popJSON();
        }
    }

    function popJSON() {
        regionRatingOrgs = {
            "en-us": "ESRB",
            "en-au": "COB-AU",
            "en-hk": "IARC",
            "en-in": "IARC",
            "en-nz": "OFLC-NZ",
            "en-sg": "IARC",
            "ja-jp": "CERO",
            "ko-kr": "GRB",
            "zh-hk": "IARC",
            "zh-tw": "CSRR",
            "ar-ae": "IARC",
            "ar-sa": "IARC",
            "cs-cz": "PEGI",
            "da-dk": "PEGI",
            "de-at": "PEGI",
            "de-ch": "PEGI",
            "de-de": "USK",
            "el-gr": "PEGI",
            "en-gb": "PEGI",
            "en-ie": "PEGI",
            "en-za": "FPB",
            "fi-fi": "PEGI",
            "fr-be": "PEGI",
            "fr-ch": "PEGI",
            "fr-fr": "PEGI",
            "he-il": "PEGI",
            "hu-hu": "PEGI",
            "it-it": "PEGI",
            "nb-no": "PEGI",
            "nl-be": "PEGI",
            "nl-nl": "PEGI",
            "pl-pl": "PEGI",
            "pt-pt": "PEGI",
            "ru-ru": "PCBP",
            "sk-sk": "PEGI",
            "sv-se": "PEGI",
            "tr-tr": "PEGI",
            "en-ca": "ESRB",
            "fr-ca": "ESRB",
            "es-ar": "ESRB",
            "es-cl": "CCC",
            "es-co": "ESRB",
            "es-es": "PEGI",
            "es-mx": "ESRB",
            "pt-br": "DJCTQ",
        };
        ratingorg = regionRatingOrgs[urlRegion];
        //overrides
        fullcarouselimages = ["9PGSCB1X2P7G", "BRKX5CRMRTC2", "BZGJRJC1FGF3", "BPL68T0XK96W", "BV0NSD4NN4V4", "BPQ955FQFPH6", "BZRK5C951KK7", "BWPKGQV97N7N", "BPJ686W6S0NH", "9PDV8FKWP3B4", "BNG91PT95LQN", "C0QN5M9ZTC38", "C0GWTPD0S8S1", "C40860J5R2MP", "BR7X7MVBBQKM", "C4LLMHFQ1BXQ", "9NDDH3R9DF40", "BS36XT3Z5ZKL", "C17SFN1NXZ37", "BVFDTJ1XF6CS", "C4VLMWJWM7BG", "C57L9GR0HHB7", "BX4RTV7M28VS", "BS37BWWP2PZ1", "BW2XDRNSCCPZ", "BSZM480TSWGP", "BRGPD72KHM3Q", "C3KLDKZBHNCZ", "C3HQKX3B35PD", "C2N9CS4FS1QR", "C0X2HNVH08FB", "9NBLGGH51QT4", "BPBC39LH0Q9B", "BVV8LHVGPBS3", "BWC95BZPFBS7", "BXL4538LK4DK", "BQMVWCMB8P59", "C2BTFXNW3TTT", "9P4WKZXWP1QW", "BRJGPRMBV1NT", ];
        omitimages = ["https://images-eds-ssl.xboxlive.com/image?url=8Oaj9Ryq1G1_p3lLnXlsaZgGzAie6Mnu24_PawYuDYIoH77pJ.X5Z.MqQPibUVTcB7WVDn.f4Uli2dyqvJAR1iMrHLquSMr6CthfgctOtrvg54xKrmjYXQ1BkhiG4i6RT1HzvxN47vdGKnWcFR1BrIpKbs257dc4YHkUyePffX5a.c3Z9hfO6bkguMWKak4QJZyll1iBDl8IFZ12EEgxVXSW2Bh6iGMM6qEszDFtB80-&w=980&format=jpg", ];
        specialexclusives = ["9P5SL4LDLMG3"];
        // games excluded in particular locale
        locExclusions = ["9NT4X7P8B9NB:ja-jp", "9PDV8FKWP3B4:ja-jp", "BZJH12CJ6N3R:ja-jp", "C3FXTTH4NFQN:ja-jp", "BRXK34KJJXH8:ja-jp", "C1TBCX541JW7:ja-jp", "BSD19LV8DMRN:ja-jp", ];
        for (var i = 0; i < locExclusions.length; i++) {
            var thegame = locExclusions[i].split(":")[0];
            var theloc = locExclusions[i].split(":")[1];
            if (urlRegion === theloc) {
                fullGameArray = fullGameArray.filter(function(v) {
                    return v !== thegame;
                });
            }
        }
        // games only included in particular locale
        var locInclusions = ["9NLM45C6729Z:ja-jp"];
        for (var i = 0; i < locInclusions.length; i++) {
            var thegame = locInclusions[i].split(":")[0];
            var theloc = locInclusions[i].split(":")[1];
            if (urlRegion !== theloc) {
                fullGameArray = fullGameArray.filter(function(v) {
                    return v !== thegame;
                });
            }
        }
        //end overrides
        
        function addManualIDs(selector, arraysToPush) {
            var tempIDs = [];

            $(selector).each(function(){
                tempIDs.push($(this).attr("data-thebigids").split(","));
            });

            tempIDs = tempIDs.flat();

            for (var i = 0; i < tempIDs.length; i++) {
                var tempID = tempIDs[i].toUpperCase().trim();
                arraysToPush.forEach(array => array.push(tempID));
            }
        }

        // Add-ons - Grab from hero product placement span data attr
        addManualIDs(".addOnBigIds", [addonArray, fullGameArray]);

        // Grab any curated-lists for recommended rotators
        addManualIDs('.featured-games[data-games-filter="curated-list"]', [fullGameArray]);

        pageloadfocus = 0;
        entrycat = false;

        clickname = "www>games>xbox-one>GAMETITLE>click";
        regionContent = globalContent.locales[urlRegion];

        setTimeout(function() {
            GUID_pop(fullGameArray);
            ieFix();
            $("body").css("visibility", "visible");
        }, 650);

        //fix for IE  hero
        // window resizing
        function ieFix() {
            var userAgentString = navigator.userAgent;
            if (userAgentString.indexOf("Trident") >= 0) {
                //only IE browsers
                $(".m-content-placement-item.f-size-large").each(function() {
                    $(this).find("img").attr("src", $(this).find("img").attr("srcset"));
                });
                var winWidth = $(document).width();
                if (winWidth < 767) {
                    $(".c-image").each(function() {
                        if ($(this).find("source").length === 3) {
                            $(this).find("img").attr("src", $(this).find("source").eq(2).attr("srcset"));
                        } else if ($(this).find("source").length === 2) {
                            $(this).find("img").attr("src", $(this).find("source").eq(1).attr("srcset"));
                        } else {
                            $(this).find("img").attr("src", $(this).find("source").eq(0).attr("srcset"));
                        }
                    });
                } else if (winWidth >= 768 && winWidth < 1083) {
                    $(".c-image").each(function() {
                        if ($(this).find("source").length === 3) {
                            $(this).find("img").attr("src", $(this).find("source").eq(1).attr("srcset"));
                        } else {
                            $(this).find("img").attr("src", $(this).find("source").eq(0).attr("srcset"));
                        }
                    });
                } else if (winWidth >= 1084) {
                    $(".c-image").each(function() {
                        $(this).find("img").attr("src", $(this).find("source").eq(0).attr("srcset"));
                    });
                }

                var windowresized = (function() {
                    var timers = {};
                    return function(callback, ms, uniqueId) {
                        if (!uniqueId) {
                            uniqueId = "Fires only once.";
                        }
                        if (timers[uniqueId]) {
                            clearTimeout(timers[uniqueId]);
                        }
                        timers[uniqueId] = setTimeout(callback, ms);
                    }
                    ;
                }
                )();

                $(window).resize(function() {
                    windowresized(function() {
                        $(".m-content-placement-item.f-size-large").each(function() {
                            $(this).find("img").attr("src", $(this).find("img").attr("srcset"));
                        });
                        var newWidth = $(document).width();
                        if (newWidth < 767) {
                            $(".c-image").each(function() {
                                if ($(this).find("source").length === 3) {
                                    $(this).find("img").attr("src", $(this).find("source").eq(2).attr("srcset"));
                                } else if ($(this).find("source").length === 2) {
                                    $(this).find("img").attr("src", $(this).find("source").eq(1).attr("srcset"));
                                } else {
                                    $(this).find("img").attr("src", $(this).find("source").eq(0).attr("srcset"));
                                }
                            });
                        } else if (newWidth >= 768 && newWidth < 1083) {
                            $(".c-image").each(function() {
                                if ($(this).find("source").length === 3) {
                                    $(this).find("img").attr("src", $(this).find("source").eq(1).attr("srcset"));
                                } else {
                                    $(this).find("img").attr("src", $(this).find("source").eq(0).attr("srcset"));
                                }
                            });
                        } else if (newWidth >= 1084) {
                            $(".c-image").each(function() {
                                $(this).find("img").attr("src", $(this).find("source").eq(0).attr("srcset"));
                            });
                        }
                    }, 200, "pageresize");
                });
            }
        }
    }

    function GUID_pop(rawGuids) {
        var chunknum = 300;
        var chunktotal = Math.ceil(fullGameArray.length / chunknum);
        // console.log("running guid_pop: " + fullGameArray.length);
        var countryCode = urlRegion.split("-")[1].toUpperCase();
        var guidUrl = "https://displaycatalog.mp.microsoft.com/v7.0/products?bigIds=GAMEIDS&market=" + countryCode + "&languages=" + urlRegion + "&MS-CV=DGU1mcuYo0WMMp+F.1";

        var firstchunk = rawGuids.slice(0, chunknum);
        rawGuids = rawGuids.slice(chunknum);

        var firstToUrl = firstchunk.join(",");
        guidUrl = guidUrl.replace("GAMEIDS", firstToUrl);
        // console.log("starting GUID_pop with the first  " + firstchunk.length);
        $.get(guidUrl).done(function(responseData) {
            var apiData = responseData;
            buildGamesObj(apiData, 0, firstToUrl);
            guidUrl = "https://displaycatalog.mp.microsoft.com/v7.0/products?bigIds=GAMEIDS&market=" + countryCode + "&languages=" + urlRegion + "&MS-CV=DGU1mcuYo0WMMp+F.1";
            restPop();
        }).fail(apiFailHandler);

        function restPop() {
            var m, n, temparray, chunk = chunknum;
            var arrayCount = 1;
            for (m = 0,
            n = rawGuids.length; m < n; m += chunk) {
                (function(m, n) {
                    // console.log("carrying over to restPop with the next " + chunk);
                    temparray = rawGuids.slice(m, m + chunk);
                    var guidsToUrl = temparray.join(",");
                    guidUrl = guidUrl.replace("GAMEIDS", guidsToUrl);

                    $.get(guidUrl).done(function(responseData) {
                        var apiData = responseData;
                        buildGamesObj(apiData, arrayCount, guidsToUrl);
                        arrayCount++;
                    }).fail(apiFailHandler);
                    guidUrl = "https://displaycatalog.mp.microsoft.com/v7.0/products?bigIds=GAMEIDS&market=" + countryCode + "&languages=" + urlRegion + "&MS-CV=DGU1mcuYo0WMMp+F.1";
                }
                )(m, n);
            }
        }

        function apiFailHandler() {
            console.log("Error fetching BigIDs - Removing Recommended carousels and Add-ons");
            $(".gamesSection").remove();
            $(".hero-product-placement .product-placements-container").remove();
            return false;
        }

        var gamehtml = "";
        var popcounter = 0;
        var bigidUrls = biUrls.items.urls;
        var biuArray = Object.keys(bigidUrls);
        allGames = {};
        allGamesExcludes = [];
        gameIdArrays["exclusives"] = [];
        gameIdArrays["multiplayer"] = [];
        gameIdArrays["kidsfamily"] = [];

        selectedGames = [];
        prunedGames = [];
        shownGames = [];

        var nowdate = new Date();
        var nowmonthsdate = new Date();
        var monthsagofilterdate = new Date(nowmonthsdate.setMonth(nowmonthsdate.getMonth() - 2));
        var locgamesremoved = 0;

        function buildGamesObj(data, count, bigidsgiven) {
            var productQuantity = data.Products.length;

            bigidsgiven = bigidsgiven.split(",");
            var allprodids = [];
            for (var s = 0; s < productQuantity; s++) {
                allprodids.push(data.Products[s].ProductId);
            }
            var eliminated = [];
            eliminated = bigidsgiven.filter(function(v) {
                return allprodids.indexOf(v) === -1;
            });

            for (var w = 0; w < eliminated.length; w++) {
                locgamesremoved++;
                var idind = fullGameArray.indexOf(eliminated[w]);
                if (idind !== -1) {
                    fullGameArray.splice(idind, 1);
                    // console.log(`Removing ${eliminated[w]} from fullGameArray`)
                }
                var idind1 = gameIdArrays["HDRGaming"] ? gameIdArrays["HDRGaming"].indexOf(eliminated[w]) : -1;
                if (idind1 !== -1) {
                    gameIdArrays["HDRGaming"].splice(idind1, 1);
                    // console.log(`Removing ${eliminated[w]} from HDRGaming`)
                }
                var idind2 = gameIdArrays["topfree"] ? gameIdArrays["topfree"].indexOf(eliminated[w]) : -1;
                if (idind2 !== -1) {
                    gameIdArrays["topfree"].splice(idind2, 1);
                    // console.log(`Removing ${eliminated[w]} from topfree`)
                }
                var idind3 = gameIdArrays["enhanced"] ? gameIdArrays["enhanced"].indexOf(eliminated[w]) : -1;
                if (idind3 !== -1) {
                    gameIdArrays["enhanced"].splice(idind3, 1);
                    // console.log(`Removing ${eliminated[w]} from enhanced`)
                }
                var idind4 = gameIdArrays["fourk"] ? gameIdArrays["fourk"].indexOf(eliminated[w]) : -1;
                if (idind4 !== -1) {
                    gameIdArrays["fourk"].splice(idind4, 1);
                    // console.log(`Removing ${eliminated[w]} from fourk`)
                }
                var idind5 = gameIdArrays["xpa"] ? gameIdArrays["xpa"].indexOf(eliminated[w]) : -1;
                if (idind5 !== -1) {
                    gameIdArrays["xpa"].splice(idind5, 1);
                    // console.log(`Removing ${eliminated[w]} from xpa`)
                }
                var idind6 = gameIdArrays["exclusives"] ? gameIdArrays["exclusives"].indexOf(eliminated[w]) : -1;
                if (idind6 !== -1) {
                    gameIdArrays["exclusives"].splice(idind6, 1);
                    // console.log(`Removing ${eliminated[w]} from exclusives`)
                }
                var idind7 = gameIdArrays["kidsfamily"] ? gameIdArrays["kidsfamily"].indexOf(eliminated[w]) : -1;
                if (idind7 !== -1) {
                    gameIdArrays["kidsfamily"].splice(idind7, 1);
                    // console.log(`Removing ${eliminated[w]} from kidsfamily`)
                }
                var idind8 = gameIdArrays["newreleases"] ? gameIdArrays["newreleases"].indexOf(eliminated[w]) : -1;
                if (idind8 !== -1) {
                    gameIdArrays["newreleases"].splice(idind8, 1);
                    // console.log(`Removing ${eliminated[w]} from newreleases`)
                }
                var idind9 = gameIdArrays["multiplayer"] ? gameIdArrays["multiplayer"].indexOf(eliminated[w]) : -1;
                if (idind9 !== -1) {
                    gameIdArrays["multiplayer"].splice(idind9, 1);
                    // console.log(`Removing ${eliminated[w]} from multiplayer`)
                }
                var idind10 = gameIdArrays["upcoming"] ? gameIdArrays["upcoming"].indexOf(eliminated[w]) : -1;
                if (idind10 !== -1) {
                    gameIdArrays["upcoming"].splice(idind10, 1);
                    // console.log(`Removing ${eliminated[w]} from upcoming`)
                }
                var idind11 = gameIdArrays["cloud"] ? gameIdArrays["cloud"].indexOf(eliminated[w]) : -1;
                if (idind11 !== -1) {
                    gameIdArrays["cloud"].splice(idind11, 1);
                    // console.log(`Removing ${eliminated[w]} from cloud`)
                }
                var idind12 = gameIdArrays["onsale"] ? gameIdArrays["onsale"].indexOf(eliminated[w]) : -1;
                if (idind12 !== -1) {
                    gameIdArrays["onsale"].splice(idind12, 1);
                    // console.log(`Removing ${eliminated[w]} from onsale`)
                }
                // var idind13 = gameIdArrays["physical"] ? gameIdArrays["physical"].indexOf(eliminated[w]) : -1;
                // if (idind13 !== -1) { gameIdArrays["physical"].splice(idind13, 1); }
                var idind14 = gameIdArrays["mostplayed"] ? gameIdArrays["mostplayed"].indexOf(eliminated[w]) : -1;
                if (idind14 !== -1) {
                    gameIdArrays["mostplayed"].splice(idind14, 1);
                    // console.log(`Removing ${eliminated[w]} from mostplayed`)
                }
                var idind15 = addonArray ? addonArray.indexOf(eliminated[w]) : -1;
                if (idind15 !== -1) {
                    addonArray.splice(idind15, 1);
                    // console.log(`Removing ${eliminated[w]} from addonArray`)
                }
            }

            for (var t = 0; t < allprodids.length; t++) {
                var excludetest = false;
                var producttest = data.Products[t];
                var excludeit404 = 0;
                var excludeitpurch = 0;
                producttest.DisplaySkuAvailabilities.forEach(function(d) {
                    d.Availabilities.forEach(function(av) {
                        if (av.Actions.indexOf("Purchase") !== -1) {
                            excludeit404 += 1;
                            excludeitpurch += 1;
                        }
                        if (av.Actions.indexOf("Details") !== -1) {
                            excludeit404 += 1;
                        }
                    });
                });
                if (excludeitpurch === 0) {
                    // Free-to-play - no need to check for Purchase Availability and exclude but revert if it becomes an issue for ROW
                    // excludetest = true;
                }

                if (excludetest === true) {
                    allGamesExcludes.push(allprodids[t]);
                    console.log("NOTE: BigID " + allprodids[t] + " unavailable to buy in this locale. Removing from game lists.");
                    locgamesremoved++;
                    popcounter--;
                    
                    var idind = fullGameArray.indexOf(allprodids[t]);
                    if (idind !== -1) {
                        fullGameArray.splice(idind, 1);
                        // console.log(`Removing allprodids ${allprodids[t]} from fullGameArray`)
                    }
                    var idind1 = gameIdArrays["HDRGaming"] ? gameIdArrays["HDRGaming"].indexOf(allprodids[t]) : -1;
                    if (idind1 !== -1) {
                        gameIdArrays["HDRGaming"].splice(idind1, 1);
                        // console.log(`Removing allprodids ${allprodids[t]} from HDRGaming`)
                    }
                    var idind2 = gameIdArrays["topfree"] ? gameIdArrays["topfree"].indexOf(allprodids[t]) : -1;
                    if (idind2 !== -1) {
                        gameIdArrays["topfree"].splice(idind2, 1);
                        // console.log(`Removing allprodids ${allprodids[t]} from topfree`)
                    }
                    var idind3 = gameIdArrays["enhanced"] ? gameIdArrays["enhanced"].indexOf(allprodids[t]) : -1;
                    if (idind3 !== -1) {
                        gameIdArrays["enhanced"].splice(idind3, 1);
                        // console.log(`Removing allprodids ${allprodids[t]} from enhanced`)
                    }
                    var idind4 = gameIdArrays["fourk"] ? gameIdArrays["fourk"].indexOf(allprodids[t]) : -1;
                    if (idind4 !== -1) {
                        gameIdArrays["fourk"].splice(idind4, 1);
                        // console.log(`Removing allprodids ${allprodids[t]} from fourk`)
                    }
                    var idind5 = gameIdArrays["xpa"] ? gameIdArrays["xpa"].indexOf(allprodids[t]) : -1;
                    if (idind5 !== -1) {
                        gameIdArrays["xpa"].splice(idind5, 1);
                        // console.log(`Removing allprodids ${allprodids[t]} from xpa`)
                    }
                    var idind6 = gameIdArrays["exclusives"] ? gameIdArrays["exclusives"].indexOf(allprodids[t]) : -1;
                    if (idind6 !== -1) {
                        gameIdArrays["exclusives"].splice(idind6, 1);
                        // console.log(`Removing allprodids ${allprodids[t]} from exclusives`)
                    }
                    var idind7 = gameIdArrays["kidsfamily"] ? gameIdArrays["kidsfamily"].indexOf(allprodids[t]) : -1;
                    if (idind7 !== -1) {
                        gameIdArrays["kidsfamily"].splice(idind7, 1);
                        // console.log(`Removing allprodids ${allprodids[t]} from kidsfamily`)
                    }
                    var idind8 = gameIdArrays["newreleases"] ? gameIdArrays["newreleases"].indexOf(allprodids[t]) : -1;
                    if (idind8 !== -1) {
                        gameIdArrays["newreleases"].splice(idind8, 1);
                        // console.log(`Removing allprodids ${allprodids[t]} from newreleases`)
                    }
                    var idind9 = gameIdArrays["multiplayer"] ? gameIdArrays["multiplayer"].indexOf(allprodids[t]) : -1;
                    if (idind9 !== -1) {
                        gameIdArrays["multiplayer"].splice(idind9, 1);
                        // console.log(`Removing allprodids ${allprodids[t]} from multiplayer`)
                    }
                    var idind10 = gameIdArrays["upcoming"] ? gameIdArrays["upcoming"].indexOf(allprodids[t]) : -1;
                    if (idind10 !== -1) {
                        gameIdArrays["upcoming"].splice(idind10, 1);
                        // console.log(`Removing allprodids ${allprodids[t]} from upcoming`)
                    }
                    var idind11 = gameIdArrays["cloud"] ? gameIdArrays["cloud"].indexOf(allprodids[t]) : -1;
                    if (idind11 !== -1) {
                        gameIdArrays["cloud"].splice(idind11, 1);
                        // console.log(`Removing allprodids ${allprodids[t]} from cloud`)
                    }
                    var idind12 = gameIdArrays["onsale"] ? gameIdArrays["onsale"].indexOf(allprodids[t]) : -1;
                    if (idind12 !== -1) {
                        gameIdArrays["onsale"].splice(idind12, 1);
                        // console.log(`Removing allprodids ${allprodids[t]} from onsale`)
                    }
                    // var idind13 = gameIdArrays["physical"] ? gameIdArrays["physical"].indexOf(allprodids[t]) : -1;
                    // if (idind13 !== -1) { gameIdArrays["physical"].splice(idind13, 1); }
                    var idind14 = gameIdArrays["mostplayed"] ? gameIdArrays["mostplayed"].indexOf(allprodids[t]) : -1;
                    if (idind14 !== -1) {
                        gameIdArrays["mostplayed"].splice(idind14, 1);
                        // console.log(`Removing allprodids ${allprodids[t]} from mostplayed`)
                    }
                    var idind15 = addonArray ? addonArray.indexOf(allprodids[t]) : -1;
                    if (idind15 !== -1) {
                        addonArray.splice(idind15, 1);
                        // console.log(`Removing allprodids ${allprodids[t]} from addonArray`)
                    }
                }
            }

            for (var i = 0; i < productQuantity; i++) {
                var itemId = data.Products[i].ProductId.toUpperCase();
                var descriptionSizeLimit = 300;

                var itemTitle = data.Products[i].LocalizedProperties[0].ProductTitle;
                if (itemTitle === undefined) {
                    itemTitle = "";
                }
                var titleClickname = itemTitle.toLowerCase().replace(/\s/g, "-").replace(/[^a-z0-9-]/gi, "");
                if (titleClickname === "") {
                    titleClickname = "-";
                }

                var shortdesc = data.Products[i].LocalizedProperties[0].ShortDescription;
                if (shortdesc === "") {
                    shortdesc = data.Products[i].LocalizedProperties[0].ProductDescription;
                }
                if (shortdesc === undefined) {
                    shortdesc = "";
                }
                if (shortdesc && shortdesc.length > descriptionSizeLimit) {
                    // This should trim the description to prevent overflow
                    for (var j = descriptionSizeLimit; j > 0; j--) {
                        var curChar = shortdesc.charAt(j);
                        if (curChar == "." || curChar == "?" || curChar == "!") {
                            shortdesc = shortdesc.substring(0, j + 1);
                            break;
                        }
                    }
                }
                // determine physical or download
                // if (gameIdArrays["physical"] && gameIdArrays["physical"].indexOf(itemId) !== -1) {
                //   var phys = "true";
                // } else {
                var phys = "false";
                // }

                // get boxshot
                if (phys === "false" && data.Products[i].LocalizedProperties[0].Images !== undefined) {
                    var imagesNum = data.Products[i].LocalizedProperties[0].Images.length;
                    var imageInd = 999;
                    for (var j = 0; j < imagesNum; j++) {
                        if (data.Products[i].LocalizedProperties[0].Images[j].ImagePurpose === "Poster") {
                            // boxshots BrandedKeyArt
                            imageInd = j;
                            break;
                        }
                    }
                    if (imageInd === 999) {
                        for (var j = 0; j < imagesNum; j++) {
                            if (data.Products[i].LocalizedProperties[0].Images[j].Width < data.Products[i].LocalizedProperties[0].Images[j].Height) {
                                imageInd = j;
                                break;
                            }
                        }
                    }
                    if (imageInd === 999) {
                        imageInd = 1;
                    }
                    if (data.Products[i].LocalizedProperties[0].Images[imageInd]) {
                        var itemBoxshot = data.Products[i].LocalizedProperties[0].Images[imageInd].Uri.replace("http:", "https:");
                        var itemBoxshotSmall;
                    } else {
                        var itemBoxshot = "https://assets.xboxservices.com/assets/d4/da/d4da80b7-2e08-425c-adb3-e279c152adec.jpg?n=X1-Standard-digital-boxshot_584x800.jpg";
                        var itemBoxshotSmall = "https://assets.xboxservices.com/assets/d4/da/d4da80b7-2e08-425c-adb3-e279c152adec.jpg?n=X1-Standard-digital-boxshot_584x800.jpg";
                    }
                    if (itemBoxshot.indexOf("store-images") !== -1) {
                        itemBoxshotSmall = itemBoxshot + "?w=140";
                        itemBoxshot = itemBoxshot + "?w=280";
                    } else {
                        itemBoxshotSmall = itemBoxshot;
                    }
                } else if (phys === "true" && data.Products[i].LocalizedProperties[0].Images !== undefined) {
                    var imagesNum = data.Products[i].LocalizedProperties[0].Images.length;
                    var imageInd = 999;
                    for (var j = 0; j < imagesNum; j++) {
                        if (data.Products[i].LocalizedProperties[0].Images[j].ImagePurpose === "Poster") {
                            imageInd = j;
                            break;
                        }
                    }
                    if (data.Products[i].LocalizedProperties[0].Images[imageInd]) {
                        var itemBoxshot = data.Products[i].LocalizedProperties[0].Images[imageInd].Uri.replace("http:", "https:");
                        var itemBoxshotSmall;
                    } else {
                        if (data.Products[i].LocalizedProperties[0].Images[0]) {
                            if (data.Products[i].LocalizedProperties[0].Images[0].Uri.toLowerCase().indexOf("s-microsoft") === -1) {
                                var itemBoxshot = data.Products[i].LocalizedProperties[0].Images[0].Uri.replace("http:", "https:") + "&w=231&h=197&q=90&m=6&b=%23FFFFFFFF&o=f";
                            } else {
                                var itemBoxshot = data.Products[i].LocalizedProperties[0].Images[0].Uri.replace("http:", "https:");
                            }
                            var itemBoxshotSmall = itemBoxshot;
                        } else {
                            var itemBoxshot = "https://assets.xboxservices.com/assets/d4/da/d4da80b7-2e08-425c-adb3-e279c152adec.jpg?n=X1-Standard-digital-boxshot_584x800.jpg";
                            var itemBoxshotSmall = "https://assets.xboxservices.com/assets/d4/da/d4da80b7-2e08-425c-adb3-e279c152adec.jpg?n=X1-Standard-digital-boxshot_584x800.jpg";
                        }
                    }
                } else {
                    var itemBoxshot = "https://assets.xboxservices.com/assets/d4/da/d4da80b7-2e08-425c-adb3-e279c152adec.jpg?n=X1-Standard-digital-boxshot_584x800.jpg";
                    var itemBoxshotSmall = "https://assets.xboxservices.com/assets/d4/da/d4da80b7-2e08-425c-adb3-e279c152adec.jpg?n=X1-Standard-digital-boxshot_584x800.jpg";
                }

                if (addonArray.indexOf(itemId) !== -1) {
                    var imagesNum = data.Products[i].LocalizedProperties[0].Images.length;
                    var ssInd = 1;
                    for (var j = 0; j < imagesNum; j++) {
                        if (document.URL.toLowerCase().indexOf("playerunknowns-battlegrounds") !== -1) {
                            if (data.Products[i].LocalizedProperties[0].Images[j].ImagePurpose === "BoxArt") { //FeaturePromotionalSquareArt
                                ssInd = j;
                                break;
                            }
                        } else {
                            if (data.Products[i].LocalizedProperties[0].Images[j].ImagePurpose === "BoxArt" && data.Products[i].LocalizedProperties[0].Images[j].Width === data.Products[i].LocalizedProperties[0].Images[j].Height && data.Products[i].LocalizedProperties[0].Images[j].Width > 271) {
                                ssInd = j;
                                break;
                            }
                            if ((data.Products[i].LocalizedProperties[0].Images[j].ImagePurpose === "Tile" || data.Products[i].LocalizedProperties[0].Images[j].ImagePurpose === "tile") &&
                                data.Products[i].LocalizedProperties[0].Images[j].Width === data.Products[i].LocalizedProperties[0].Images[j].Height && data.Products[i].LocalizedProperties[0].Images[j].Width > 271) {
                                ssInd = j;
                                //break;
                            }
                            // if ((data.Products[i].LocalizedProperties[0].Images[j].ImagePurpose === "Tile" || data.Products[i].LocalizedProperties[0].Images[j].ImagePurpose === "tile") 
                            //   && data.Products[i].LocalizedProperties[0].Images[j].Width === data.Products[i].LocalizedProperties[0].Images[j].Height && data.Products[i].LocalizedProperties[0].Images[j].Width > 149) {
                            //   ssInd = j;
                            //   break;
                            // } 
                            if (data.Products[i].LocalizedProperties[0].Images[j].Width === data.Products[i].LocalizedProperties[0].Images[j].Height && data.Products[i].LocalizedProperties[0].Images[j].Width > 271) {
                                ssInd = j;
                                //break;
                            }
                            if (data.Products[i].LocalizedProperties[0].Images[j].ImagePurpose === "Poster") {
                                ssInd = j;
                                //break
                            }
                        }
                    }
                    var squareshot = data.Products[i].LocalizedProperties[0].Images[ssInd].Uri.replace("http:", "https:");
                    var boxbgColor = data.Products[i].LocalizedProperties[0].Images[ssInd].BackgroundColor;
                    var itemId = data.Products[i].ProductId.toUpperCase();

                    if (itemId === "9NBLGGH1Z6FQ") {
                        squareshot = "https://assets.xboxservices.com/assets/0a/03/0a03fc1f-b232-43d2-b15c-1f0aea2d4187.jpg?n=ReCore_Boxshot-digital-X1_294x215.jpg";
                    }
                    if (itemId === "BZFK7WNK7R4M") {
                        squareshot = "https://images-eds-ssl.xboxlive.com/image?url=8Oaj9Ryq1G1_p3lLnXlsaZgGzAie6Mnu24_PawYuDYIoH77pJ.X5Z.MqQPibUVTc6LYEXhNheFwp2halN6MiJq0hK8tHwcOslhHzFcqc.uw90wjv2YtwC_mZJs.lEh1cto.K33xsXgRNctiGCKrDjVsG9PhS5GzkLXFMF5wlXsJAfaI6.Hc6zR2KrB00Sjgkn0kvJZv.PD1.7g.ytDgP368SN3vocTlHhhyS_BQ8qZs-";
                    }
                    if (itemId === "9WZDNCRFJ3P2" || itemId === "9WZDNCRFJ1XX") {
                        boxbgColor = "blue";
                    }
                }

                // get screenshot
                if (phys === "false" && data.Products[i].LocalizedProperties[0].Images !== undefined) {
                    var imagesNum = data.Products[i].LocalizedProperties[0].Images.length;
                    var imageInd = 1;
                    for (var j = 0; j < imagesNum; j++) {
                        var im = data.Products[i].LocalizedProperties[0].Images[j];
                        if ((im.ImagePurpose === "ImageGallery" || im.ImagePurpose === "Screenshot") && im.Height < im.Width) {
                            imageInd = j;
                            break;
                        }
                    }
                    if (data.Products[i].LocalizedProperties[0].Images[imageInd]) {
                        var itemScreenshot = data.Products[i].LocalizedProperties[0].Images[imageInd].Uri.replace("http:", "https:");
                    } else {
                        var itemScreenshot = "https://assets.xboxservices.com/assets/d4/da/d4da80b7-2e08-425c-adb3-e279c152adec.jpg?n=X1-Standard-digital-boxshot_584x800.jpg";
                    }
                    if (itemScreenshot.indexOf("xboxlive.com") !== -1) {
                        itemScreenshot = itemScreenshot + "&w=480&format=jpg";
                    }
                } else {
                    if (data.Products[i].LocalizedProperties[0].Images !== undefined && data.Products[i].LocalizedProperties[0].Images[0]) {
                        var itemScreenshot = data.Products[i].LocalizedProperties[0].Images[0].Uri.replace("http:", "https:") + "&w=231&h=197&q=90&m=6&b=%23FFFFFFFF&o=f";
                    } else {
                        var itemScreenshot = "https://assets.xboxservices.com/assets/d4/da/d4da80b7-2e08-425c-adb3-e279c152adec.jpg?n=X1-Standard-digital-boxshot_584x800.jpg";
                    }
                }

                // get screenshot array
                var ssarray = [];
                var superheroart = "";
                if (phys === "false" && data.Products[i].LocalizedProperties[0].Images !== undefined) {
                    var imagesNum = data.Products[i].LocalizedProperties[0].Images.length;
                    var sslimit = 5;
                    var imageInd = 1;
                    for (var j = 0; j < imagesNum; j++) {
                        var im = data.Products[i].LocalizedProperties[0].Images[j];
                        if ((im.ImagePurpose.toLowerCase() === "imagegallery" || im.ImagePurpose.toLowerCase() === "screenshot") && im.Height < im.Width) {
                            if (im.Uri.indexOf("xboxlive.com") !== -1) {
                                var ssimg = im.Uri.replace("http:", "https:") + "&w=980&format=jpg";
                            } else {
                                var ssimg = im.Uri.replace("http:", "https:");
                            }
                            if (ssarray.length < sslimit) {
                                if (ssarray.indexOf(ssimg) === -1 && omitimages.indexOf(ssimg) === -1) {
                                    ssarray.push(ssimg);
                                }
                            } else {
                                break;
                            }
                        } else if (im.ImagePurpose.toLowerCase() === "superheroart") {
                            if (im.Uri.indexOf("xboxlive.com") !== -1) {
                                var shimg = im.Uri.replace("http:", "https:") + "&w=980&format=jpg";
                            } else {
                                var shimg = im.Uri.replace("http:", "https:");
                            }
                            //console.log("keyart = " + kaimg);
                            superheroart = shimg;
                        }
                    }
                }

                var releaseDate = data.Products[i].MarketProperties[0].OriginalReleaseDate;
                if (releaseDate === undefined) {
                    releaseDate = 0;
                }
                var msproduct = data.Products[i].IsMicrosoftProduct;
                if (specialexclusives.indexOf(itemId) !== -1) {
                    msproduct = true;
                }
                var multiplayer = "false";
                var coop = "false";
                var mptest = data.Products[i].Properties;
                if (mptest.Attributes) {
                    for (var n = 0; n < mptest.Attributes.length; n++) {
                        if (mptest.Attributes[n].Name.toLowerCase().indexOf("multiplayer") !== -1) {
                            multiplayer = "true";
                        }
                        if (mptest.Attributes[n].Name.toLowerCase().indexOf("coop") !== -1) {
                            coop = "true";
                        }
                    }
                }

                //get prices
                var listprice;
                var msrpprice;
                var recurrenceprice;
                var taxincluded = "false";
                var enddate = "none";
                var currencycode;
                var onsale = "false";
                var gwg = "false";
                var golddiscount = "false";
                // deals with gold ... and gold member sale prices?
                var goldandsilversale = "false";
                var goldandsilversalegoldprice = 100000000;
                var specialprice = 100000000;
                var eaaccessgame = "false";
                var gamepassgame = "false";
                var eaplaygame = "false";
                var gamepassprice = 0;
                var eaplayprice = 0;
                var purchasable = "false";
                var tempea = "false"
                var tempgs = "false";
                var goldaffids = [];
                var silversaleperc = "0%";
                var goldandsilversalegoldperc = "0%";
                var subskus = {};
                var platxbox = "false";
                var platxo = "false";
                var platxsx = "false";
                var platpc = "false";

                if (phys === "false") {
                    if (data.Products[i].LocalizedProperties[0].EligibilityProperties !== null && data.Products[i].LocalizedProperties[0].EligibilityProperties !== undefined && data.Products[i].LocalizedProperties[0].EligibilityProperties !== "undefined") {
                        if (data.Products[i].LocalizedProperties[0].EligibilityProperties.Affirmations.length > 0) {
                            data.Products[i].LocalizedProperties[0].EligibilityProperties.Affirmations.forEach(function(aff) {
                                if (aff.Description.toLowerCase().indexOf("ea access") !== -1) {
                                    tempea = "true";
                                }
                                if (aff.Description.toLowerCase().indexOf("game pass") !== -1) {
                                    gamepassgame = "true";
                                }
                                if (aff.Description.toLowerCase().indexOf("ea play") !== -1) {
                                    eaplaygame = "true";
                                }
                                if (aff.Description.toLowerCase().indexOf("gold") !== -1) {
                                    tempgs = "true";
                                    goldaffids.push(aff.AffirmationProductId);
                                }
                            });
                        }
                        if (data.Products[i].LocalizedProperties[0].EligibilityProperties.Remediations.length > 0) {
                            data.Products[i].LocalizedProperties[0].EligibilityProperties.Remediations.forEach(function (re) {
                                if (re.Description.toLowerCase().indexOf("ea access") !== -1) {
                                    tempea = "true";
                                }
                                // if (re.Description.toLowerCase().indexOf("game pass") !== -1) {
                                //     gamepassgame = "true";
                                // }
                                if (re.Description.toLowerCase().indexOf("ea play") !== -1) {
                                    eaplaygame = "true";
                                }
                                // if (re.Description.toLowerCase().indexOf("gold") !== -1) {
                                //     tempgs = "true";
                                //     goldaffids.push(aff.AffirmationProductId);
                                // }
                            })
                        }
                    }
                    var purchindexes = [];
                    data.Products[i].DisplaySkuAvailabilities.forEach(function(sku, skuind) {
                        var purchnum = 0;
                        sku.Availabilities.forEach(function(av, ind) {
                            if (av.Actions.indexOf("Purchase") !== -1) {
                                purchasable = "true";
                                purchnum++;
                                if (purchnum > 1 && tempgs === "true" && av.RemediationRequired === true && goldaffids.indexOf(av.Remediations[0].BigId) !== -1) {
                                    goldandsilversale = "true";
                                }
                                // get platform info
                                av.Conditions.ClientConditions.AllowedPlatforms.forEach(function(plat) {
                                    if (plat.PlatformName === "Windows.Xbox") {
                                        platxbox = "true";
                                    }
                                    if (plat.PlatformName === "Windows.Desktop") {
                                        platpc = "true";
                                    }
                                })
                                if (av.Remediations && av.Remediations[0].BigId === "CFQ7TTC0K5DJ") {
                                    tempgs = "true";
                                    goldandsilversale = "true";
                                    golddiscount = "true";
                                }
                                // if (subscriptiongames.indexOf(data.Products[i].ProductId) !== -1 && purchindexes.indexOf(skuind) === -1) {
                                //     purchindexes.push(skuind);
                                // }
                                if (gamepassgame === "true") {
                                    if (av.RemediationRequired === true) {
                                        av.Remediations.forEach(function(rm) {
                                            if (rm.BigId === "CFQ7TTC0K6L8") {
                                                gamepassprice = av.OrderManagementData.Price.ListPrice;
                                            }
                                        })
                                    }
                                }
                                if (eaplaygame === "true") {
                                    if (av.RemediationRequired === true) {
                                        av.Remediations.forEach(function(rm) {
                                            if (rm.BigId === "CFQ7TTC0K5DH" && av.OrderManagementData.Price.MSRP !== 0) {
                                                eaplayprice = av.OrderManagementData.Price.ListPrice;
                                            }
                                        })
                                    }
                                }
                            }
                            if (av.Actions.indexOf("Purchase") !== -1 && (av.OrderManagementData.Price.MSRP !== 0 || (av.OrderManagementData.Price.MSRP === 0 && av.OrderManagementData.Price.ListPrice === 0)) &&
                                sku.Sku.Properties.IsTrial === false) {
                                if ((av.OrderManagementData.Price.ListPrice !== av.OrderManagementData.Price.MSRP || (av.OrderManagementData.Price.MSRP === 0 && av.OrderManagementData.Price.ListPrice === 0)) && ind !== 0) {
                                    specialprice = av.OrderManagementData.Price.ListPrice;
                                } else {
                                    listprice = av.OrderManagementData.Price.ListPrice;
                                    enddate = av.Conditions.EndDate;
                                }
                                if (ind === 0) {
                                    msrpprice = av.OrderManagementData.Price.MSRP;
                                }
                                currencycode = av.OrderManagementData.Price.CurrencyCode;
                                if (av.Properties.MerchandisingTags !== undefined) {
                                    if (av.Properties.MerchandisingTags.indexOf("LegacyGamesWithGold") !== -1) {
                                        gwg = "true";
                                        specialprice = listprice;
                                        listprice = msrpprice;
                                        enddate = av.Conditions.EndDate;
                                    }
                                    if (av.Properties.MerchandisingTags.indexOf("LegacyDiscountGold") !== -1) {
                                        golddiscount = "true";
                                    }
                                }
                                if (goldandsilversale === "true" && av.DisplayRank === 1) {
                                    goldandsilversalegoldprice = av.OrderManagementData.Price.ListPrice;
                                    var golddiff = msrpprice - goldandsilversalegoldprice;
                                    goldandsilversalegoldperc = Math.round(golddiff / msrpprice * 100).toString() + "%";
                                }
                                if (tempea === "true" && av.Actions.length >= 2) {
                                    eaaccessgame = "true";
                                }
                                if (listprice < msrpprice) {
                                    onsale = "true";
                                    var listdiff = msrpprice - listprice;
                                    silversaleperc = Math.round(listdiff / msrpprice * 100).toString() + "%";
                                    if (gameIdArrays["onsale"] && gameIdArrays["onsale"].indexOf(itemId) === -1) {
                                        gameIdArrays["onsale"].push(itemId);
                                    }
                                }
                                if (av.OrderManagementData.Price.TaxType && av.OrderManagementData.Price.TaxType === "ConsumptionTaxIncluded") {
                                    taxincluded = "true";
                                }
                            }
                        });
                        sku.HistoricalBestAvailabilities.forEach(function(z) {
                            recurrenceprice = z.OrderManagementData.Price.ListPrice;
                        });
                        if (purchindexes.length > 0) {
                            for (var p = 0; p < purchindexes.length; p++) {
                                var subsku = data.Products[i].DisplaySkuAvailabilities[p].Sku.SkuId;
                                var subpricetext = data.Products[i].DisplaySkuAvailabilities[p].Sku.LocalizedProperties[0].SkuTitle;
                                var subprice = data.Products[i].DisplaySkuAvailabilities[p].Availabilities[0].OrderManagementData.Price.RecurrencePrice;
                                subskus[subsku] = {};
                                subskus[subsku]["subpricetext"] = subpricetext;
                                subskus[subsku]["subprice"] = subprice;
                            }
                        }
                    })

                    if (data.Products[i].Properties.XboxConsoleGenCompatible === null) {
                        platxo = "true";
                        platxsx = "true";
                    } else if (data.Products[i].Properties.XboxConsoleGenCompatible === undefined) {
                        platxo = "true";
                    } else if (data.Products[i].Properties.XboxConsoleGenCompatible.length === 2) {
                        platxo = "true";
                        platxsx = "true";
                    } else if (data.Products[i].Properties.XboxConsoleGenCompatible[0] === "ConsoleGen8") {
                        platxo = "true";
                    } else if (data.Products[i].Properties.XboxConsoleGenCompatible[0] === "ConsoleGen9") {
                        platxsx = "true";
                    }
                } else {
                    data.Products[i].DisplaySkuAvailabilities.forEach(function (sku) {
                        sku.Availabilities.forEach(function (av) {
                            if (av.Actions.indexOf("Purchase") !== -1 && av.Actions.indexOf("Browse") !== -1 && (av.OrderManagementData.Price.MSRP !== 0 || (av.OrderManagementData.Price.MSRP === 0 && av.OrderManagementData.Price.ListPrice === 0)) && av.Actions.length > 2) {
                                listprice = av.OrderManagementData.Price.ListPrice;
                                enddate = av.Conditions.EndDate;
                                msrpprice = av.OrderManagementData.Price.MSRP;
                                currencycode = av.OrderManagementData.Price.CurrencyCode;
                                if (listprice < msrpprice) {
                                    onsale = "true";
                                    if (gameIdArrays["onsale"].indexOf(itemId) === -1) {
                                        gameIdArrays["onsale"].push(itemId);
                                    }
                                };
                            }
                        })
                    });
                }

                if (listprice === undefined) {
                    console.log("NOTE: BigID " + itemId + " has no price information.");
                    listprice = 100000000;
                    msrpprice = 100000000;
                    currencycode = "USD";
                }

                var thesystems = {
                    "ar-ae": "PEGI",
                    "ar-sa": "PEGI",
                    "cs-cz": "PEGI",
                    "da-dk": "PEGI",
                    "de-at": "PEGI",
                    "de-ch": "PEGI",
                    "de-de": "USK",
                    "el-gr": "PEGI",
                    "en-au": "OFLC-AU",
                    "en-ca": "ESRB",
                    "en-gb": "PEGI",
                    "en-hk": "Microsoft",
                    "en-ie": "PEGI",
                    "en-in": "Microsoft",
                    "en-nz": "OFLC-NZ",
                    "en-sg": "Microsoft",
                    "en-us": "ESRB",
                    "en-za": "PEGI",
                    "es-ar": "Microsoft",
                    "es-cl": "ESRB",
                    "es-co": "ESRB",
                    "es-es": "ESRB",
                    "es-mx": "ESRB",
                    "fi-fi": "PEGI",
                    "fr-be": "PEGI",
                    "fr-ca": "ESRB",
                    "fr-ch": "PEGI",
                    "fr-fr": "PEGI",
                    "he-il": "PEGI",
                    "hu-hu": "PEGI",
                    "it-it": "PEGI",
                    "ja-jp": "CERO",
                    "ko-kr": "GRB",
                    "nb-no": "PEGI",
                    "nl-be": "PEGI",
                    "nl-nl": "PEGI",
                    "pl-pl": "DJCTQ",
                    "pt-br": "DJCTQ",
                    "pt-pt": "PEGI",
                    "ru-ru": "RUSSIA",
                    "sk-sk": "PEGI",
                    "sv-se": "PEGI",
                    "tr-tr": "PEGI",
                    "zh-tw": "CSSR",
                    "zh-hk": "Microsoft",
                };
                var rating = "none";
                var ratingUrl = "https://www.esrb.org/";
                var ratingcode = "";
                var ratingage = 99;
                var ratingsystem = "none";
                var kidfamilyratings = ["ESRB:T", "ESRB:E10", "ESRB:E", "PEGI:3", "PEGI:7", "PEGI:12", "COB-AU:G", "COB-AU:PG", "OFLC-NZ:G", "OFLC-NZ:PG", "OFLC-NZ:R13", "USK:Everyone", "USK:6", "USK:12", "PCBP:0", "PCBP:6", "PCBP:12", "DJCTQ:L", "DJCTQ:10", "DJCTQ:12", "DJCTQ:14", "CSRR:G", "CSRR:PG12", "CSRR:PG15", ];
                var rawdescriptors = "none";
                var rawinteractive = "none";
                var rawdisclaimers = "none";
                var pegiFallbackRegions = "en-za ,";
                var iarcFallbackRegions = "ja-jp ,";
                var cr = 99;
                var cresrb = 99;
                var crfallback = 0;
                var crfallback_PEGI = -1;
                var crfallback_IARC = -1;
                if (data.Products[i].MarketProperties[0].ContentRatings !== undefined && data.Products[i].MarketProperties[0].ContentRatings !== null && data.Products[i].MarketProperties[0].ContentRatings.length > 0) {
                    for (var c = 0; c < data.Products[i].MarketProperties[0].ContentRatings.length; c++) {
                        // if (data.Products[i].MarketProperties[0].ContentRatings[c].RatingSystem === "ESRB") {
                        //  cresrb = c;
                        // }
                        if (data.Products[i].MarketProperties[0].ContentRatings[c].RatingSystem === "Microsoft") {
                            // Microsoft rating is fallback
                            crfallback = c;
                        }
                        if (pegiFallbackRegions.includes(urlRegion) && data.Products[i].MarketProperties[0].ContentRatings[c].RatingSystem === "PEGI") {
                            // PEGI fallback for en-za
                            crfallback_PEGI = c;
                        }
                        if (iarcFallbackRegions.includes(urlRegion) && data.Products[i].MarketProperties[0].ContentRatings[c].RatingSystem === "IARC") {
                            // PEGI fallback for en-za
                            crfallback_IARC = c;
                        }
                        if (data.Products[i].MarketProperties[0].ContentRatings[c].RatingSystem === ratingorg) {
                            cr = c;
                        }
                    }
                    if (cr === 99) {
                        cr = cresrb;
                    }
                    // if region's rating system is not found, use esrb
                    if (cr === 99) {
                        cr = crfallback;
                    }
                    // fallback if no esrb either
                    if (pegiFallbackRegions.includes(urlRegion) && crfallback_PEGI !== -1 && cr === crfallback) {
                        cr = crfallback_PEGI;
                    }
                    // fallback if pegi needed
                    if (iarcFallbackRegions.includes(urlRegion) && crfallback_IARC !== -1 && cr === crfallback) {
                        cr = crfallback_IARC;
                    }
                    // fallback if iarc needed
                    ratingsystem = data.Products[i].MarketProperties[0].ContentRatings[cr].RatingSystem;
                    ratingcode = data.Products[i].MarketProperties[0].ContentRatings[cr].RatingId;
                    var ratimage = ratingData.RatingBoards[ratingsystem].Ratings[ratingcode].LocalizedProperties[0].LogoUrl;
                    ratingage = ratingData.RatingBoards[ratingsystem].Ratings[ratingcode].Age;
                    rating = ratingData.RatingBoards[ratingsystem].Ratings[ratingcode].LocalizedProperties[0].LongName;
                    ratingUrl = ratingData.RatingBoards[ratingsystem].LocalizedProperties[0].Url;

                    if (kidfamilyratings.indexOf(rating) !== -1) {
                        gameIdArrays["kidsfamily"].push(itemId);
                    }
                    rawdescriptors = data.Products[i].MarketProperties[0].ContentRatings[cr].RatingDescriptors.join(",");
                    if (data.Products[i].MarketProperties[0].ContentRatings[cr].InteractiveElements !== undefined) {
                        rawinteractive = data.Products[i].MarketProperties[0].ContentRatings[cr].InteractiveElements.join(",");
                    }
                    rawdisclaimers = data.Products[i].MarketProperties[0].ContentRatings[cr].RatingDisclaimers.join(",");
                }
                if (urlRegion === "ja-jp" || urlRegion === "ko-kr") {
                    $(".c-label[data-game='kids and family']").remove();
                }

                if (biuArray.indexOf(itemId) === -1 || bigidUrls[itemId].toLowerCase().indexOf(urlRegion) !== -1) {
                    var itemhref = "https://www.xbox.com/" + urlRegion + "/games/store/" + titleClickname + "/" + itemId;
                } else {
                    var itemhref = bigidUrls[itemId].split("<exc>")[0];
                    var splitHref = itemhref.split("/");
                    splitHref.splice(3, 0, urlRegion);
                    itemhref = splitHref.join("/");
                }

                var avgstars = 0;
                var ratingcount = 0;
                if (data.Products[i].MarketProperties[0].UsageData[0]) {
                    avgstars = data.Products[i].MarketProperties[0].UsageData[0].AverageRating;
                    ratingcount = data.Products[i].MarketProperties[0].UsageData[0].RatingCount;
                }

                // custom boxshots
                if (itemId === "9NBLGGH1Z6FQ") {
                    itemBoxshot = "https://assets.xboxservices.com/assets/78/48/7848614c-0966-482a-8cc9-7d1b13fc338a.jpg?n=ReCore_Boxshot-digital-X1_294x215.jpg";
                    itemBoxshotSmall = "https://assets.xboxservices.com/assets/78/48/7848614c-0966-482a-8cc9-7d1b13fc338a.jpg?n=ReCore_Boxshot-digital-X1_294x215.jpg";
                }
                if (itemId === "BZFK7WNK7R4M") {
                    itemBoxshot = "https://images-eds-ssl.xboxlive.com/image?url=8Oaj9Ryq1G1_p3lLnXlsaZgGzAie6Mnu24_PawYuDYIoH77pJ.X5Z.MqQPibUVTc6LYEXhNheFwp2halN6MiJq0hK8tHwcOslhHzFcqc.uw90wjv2YtwC_mZJs.lEh1cto.K33xsXgRNctiGCKrDjVsG9PhS5GzkLXFMF5wlXsJAfaI6.Hc6zR2KrB00Sjgkn0kvJZv.PD1.7g.ytDgP368SN3vocTlHhhyS_BQ8qZs-&w=200&format=jpg";
                    itemBoxshotSmall = "https://images-eds-ssl.xboxlive.com/image?url=8Oaj9Ryq1G1_p3lLnXlsaZgGzAie6Mnu24_PawYuDYIoH77pJ.X5Z.MqQPibUVTc6LYEXhNheFwp2halN6MiJq0hK8tHwcOslhHzFcqc.uw90wjv2YtwC_mZJs.lEh1cto.K33xsXgRNctiGCKrDjVsG9PhS5GzkLXFMF5wlXsJAfaI6.Hc6zR2KrB00Sjgkn0kvJZv.PD1.7g.ytDgP368SN3vocTlHhhyS_BQ8qZs-&w=200&format=jpg";
                }
                if (itemId === "C2320MJQP0MS") {
                    itemBoxshot = "https://assets.xboxservices.com/assets/d3/f5/d3f5917d-6fdc-4603-a699-b92cb9265536.jpg?n=DwG_Boxshot-digital-X1_Plants-Vs-Zombies-Deluxe_584x800.jpg";
                    itemBoxshotSmall = "https://assets.xboxservices.com/assets/d3/f5/d3f5917d-6fdc-4603-a699-b92cb9265536.jpg?n=DwG_Boxshot-digital-X1_Plants-Vs-Zombies-Deluxe_584x800.jpg";
                }

                // genres
                if (data.Products[i].Properties.Categories !== undefined && data.Products[i].Properties.Categories !== null) {
                    var gamegenres = data.Products[i].Properties.Categories.join(", ").toLowerCase();
                } else if (data.Products[i].Properties.Category !== undefined && data.Products[i].Properties.Category !== null) {
                    var gamegenres = data.Products[i].Properties.Category.toLowerCase();
                } else {
                    var gamegenres = "unlisted";
                }

                allGames[itemId] = {
                    releasedate: releaseDate,
                    msproduct: msproduct,
                    multiplayer: multiplayer,
                    coop: coop,
                    rating: rating,
                    ratingage: ratingage,
                    ratingsystem: ratingsystem,
                    gameurl: itemhref,
                    titleclickname: titleClickname,
                    boxshot: itemBoxshot,
                    boxshotsmall: itemBoxshotSmall,
                    title: itemTitle,
                    msrpprice: msrpprice,
                    listprice: listprice,
                    currencycode: currencycode,
                    onsale: onsale,
                    upcoming: "false",
                    newrelease: "false",
                    physical: phys,
                    genres: gamegenres,
                    screenshot: itemScreenshot,
                    ratingUrl: ratingUrl,
                    ratimage: ratimage,
                    descriptors: rawdescriptors,
                    disclaimers: rawdisclaimers,
                    interactive: rawinteractive,
                    stars: avgstars,
                    starcount: ratingcount,
                    screenarray: ssarray,
                    superheroart: superheroart,
                    description: shortdesc,
                    gameswithgold: gwg,
                    golddiscount: golddiscount,
                    goldandsilversale: goldandsilversale,
                    goldandsilversalegoldprice: goldandsilversalegoldprice,
                    specialprice: specialprice,
                    eaaccessgame: eaaccessgame,
                    gamepassgame: gamepassgame,
                    eaplaygame: eaplaygame,
                    purchasable: purchasable,
                    silversaleperc: silversaleperc,
                    goldandsilversalegoldperc: goldandsilversalegoldperc,
                    x360game: "false",
                    includes: "",
                    excludes: "",
                    playson: "false",
                    enddate: enddate,
                    squareshot: squareshot,
                    boxbgcolor: boxbgColor,
                    taxincluded: taxincluded,
                    subskus: subskus,
                    gamepassprice: gamepassprice,
                    eaplayprice: eaplayprice,
                    platformxbox: platxbox,
                    platformpc: platpc,
                    platformxo: platxo,
                    platformxsx: platxsx,
                    recurrenceprice: recurrenceprice
                }

                //make API-provided lists
                if (allGamesExcludes.indexOf(itemId) === -1) {
                    if (msproduct === true) {
                        gameIdArrays["exclusives"].push(itemId);
                    }
                    if (multiplayer === "true") {
                        gameIdArrays["multiplayer"].push(itemId);
                    }
                    var reldate = new Date(releaseDate);
                    // if (reldate > nowdate && itemId !== "9NBLGGH51QT4") {
                    //   gameIdArrays["upcoming"].push(itemId);
                    //   allGames[itemId]["upcoming"] = "true";
                    // }
                    if (gameIdArrays["upcoming"] && gameIdArrays["upcoming"].indexOf(itemId) !== -1) {
                        allGames[itemId]["upcoming"] = "true";
                    }
                    // if (gameIdArrays["newreleases"] && gameIdArrays["newreleases"].indexOf(itemId) !== -1) {
                    //   allGames[itemId]["newrelease"] = "true";
                    // }
                    if (reldate < nowdate && monthsagofilterdate < reldate) {
                        // only show as new release based on release date, not list
                        allGames[itemId]["newrelease"] = "true";
                    }
                    if (new Date(allGames[itemId]["releasedate"]).getFullYear() > 2025) {
                        allGames[itemId]["releasedate"] = 0;
                    }
                }

                popcounter++;

                //console.log("itemId:" + itemId + "  " + i + ":" + (productQuantity -1) + "   " + popcounter + ":" + (fullGameArray.length) + "  locagamesremoved:" + locgamesremoved + "   " + count + ":" + chunktotal)
                //console.log("i: " + i + " and product quantity: " + productQuantity + " and count: " + count + " and chunktotal: " + chunktotal)
                if (i === productQuantity - 1 && count === chunktotal - 1) {
                    var activecheck = setInterval(function() {
                        var activeAjax = $.active;
                        if (activeAjax === 0) {
                            ajaxdone();
                            clearInterval(activecheck);
                        }
                    }, 500);

                    function ajaxdone() {
                        fullGameArray = fullGameArray.filter(function(v) {
                            return gameIdArrays["topfree"].indexOf(v) > -1;
                        });
                        var gia = Object.keys(gameIdArrays);
                        for (var a = 0; a < gia.length; a++) {
                            gameIdArrays[gia[a]] = gameIdArrays[gia[a]].filter(function(v) {
                                return gameIdArrays["topfree"].indexOf(v) > -1;
                            });
                        }

                        for (var r = 0; r < allGamesExcludes.length; r++) {
                            delete allGames[allGamesExcludes[r]];
                        }

                        var x1RegionPop = (function() {
                            $(".gameDiv a").each(function() {
                                var rawHref = $(this).attr("href");
                                var splitHref = rawHref.split("/");
                                splitHref.splice(3, 0, urlRegion);
                                var newHref = splitHref.join("/");
                                $(this).attr("href", newHref);
                            });
                        }
                        )();

                        $("a[data-sorting='release']").eq(2).remove();

                        // Populate Add-ons rotators
                        $(".addOnBigIds").each(function(i, elem) {
                            var gameAddonsArray = $(elem).attr("data-thebigids").split(",");
                            var carousel = $(elem).siblings(".c-carousel").find("ul");
                            populateAddOns(gameAddonsArray, carousel);
                        });


                        // Grab data attributes from carousels for Recommended Games
                        $(".gamesSection .featured-games").each(function(i, elem) {
                            var listGamesObj = {
                                cat: "mostplayed",
                                filt: "avail-download",
                                sort: "featured",
                                changeurl: "nochange",
                            };

                            if ($(elem).attr("data-games-filter") !== "avail-download") {
                                listGamesObj.cat = "all";
                                listGamesObj.filt = $(elem).attr("data-games-filter");
                            }
                            
                            if (listGamesObj.filt === "curated-list") {
                                var curatedGamesArray = $(elem).attr("data-thebigids").split(",").filter(bigid => {
                                    if (allGames[bigid]) {
                                        return true;
                                    } else {
                                        console.log("BigID is not present in response and has been removed: ", bigid);
                                        return false;
                                    }
                                });
                                populateQL(curatedGamesArray, 0, listGamesObj.filt, curatedGamesArray.length);
                            } else {
                                listGames(listGamesObj.cat, listGamesObj.filt, listGamesObj.sort, listGamesObj.changeurl);
                            }
                        });
                    }
                }
            }
        }
    }

    function listGames(cat, filt, sort, changeurl) {
        setTimeout(function() {
            cat = (function() {
                switch (cat) {
                case "all":
                case "freetoplay":
                    return gameIdArrays["topfree"] ?? "";
                case "hdr":
                    return gameIdArrays["HDRGaming"] ?? "";
                case "search":
                    return searchArray;
                default:
                    return gameIdArrays[cat] ?? "";
                }
            }
            )();

            // filters
            selectedGames = cat;
            //remove based on ratings
            prunedGames = [];
            var ratarrlen = selectedGames.length;
            // if (filt !== "all") {
            //   for (var i = 0; i < ratarrlen; i++) {
            //     if (allGames[selectedGames[i]]["rating"] === filt) {
            //       prunedGames.push(selectedGames[i]);
            //     }
            //   }
            // } else {
            //prunedGames = selectedGames;
            //}

            var filterarray = filt.split(",");
            if (filterarray.indexOf("avail-download") === -1) {
                // when there are no other availabilities
                filterarray.push("avail-download");
            }

            if (filterarray.length > 1) {
                for (var i = 0; i < ratarrlen; i++) {
                    var availset, platset, genreset, featureset, ratingset;
                    availset = platset = genreset = featureset = ratingset = 0;
                    var filtsettotal;

                    // avail filter
                    if (filterarray.indexOf("avail-download") !== -1 && allGames[selectedGames[i]]["physical"] === "false") {
                        availset = 1;
                    } else if (filterarray.indexOf("avail-physical") !== -1 && allGames[selectedGames[i]]["physical"] === "true") {
                        availset = 1;
                    } else {
                        availset = 0;
                    }

                    // plat filter
                    if (filt.indexOf("plat-") !== -1) {
                        if (filt.indexOf("plat-xsx") !== -1 && allGames[selectedGames[i]]["platformxsx"] === "true") {
                            platset = 1;
                        } else if (filt.indexOf("plat-xo") !== -1 && allGames[selectedGames[i]]["platformxo"] === "true") {
                            platset = 1;
                        }
                    } else {
                        platset = 1;
                    }

                    // genre filter
                    if (filt.indexOf("genre-") !== -1) {
                        if (filt.indexOf("genre-indie") !== -1) {
                            for (var h = 0; h < gameIdArrays["indie"].length; h++) {
                                if (selectedGames[i] === gameIdArrays["indie"][h]) {
                                    genreset = 1;
                                    break;
                                }
                            }
                        }
                        var genfilters = [];
                        filterarray.forEach(function(fa) {
                            if (fa.indexOf("genre-") !== -1) {
                                fa = fa.replace("genre-", "");
                                genfilters.push(fa);
                            }
                        });
                        genfilters.forEach(function(gf) {
                            if (allGames[selectedGames[i]]["genres"].indexOf(gf) !== -1) {
                                genreset = 1;
                            }
                        });
                    } else {
                        genreset = 1;
                    }

                    // feature filter
                    if (filt.indexOf("feature-") !== -1) {
                        var allfeats = [];
                        filterarray.forEach(function(fa) {
                            if (fa.indexOf("feature-") !== -1) {
                                allfeats.push(fa);
                            }
                        });
                        var featcount = 0;
                        for (var f = 0; f < allfeats.length; f++) {
                            if (allfeats[f] === "feature-4k") {
                                if (gameIdArrays["fourk"] && gameIdArrays["fourk"].indexOf(selectedGames[i]) !== -1) {
                                    featcount++;
                                }
                            } else if (allfeats[f] === "feature-hdr") {
                                if (gameIdArrays["HDRGaming"] && gameIdArrays["HDRGaming"].indexOf(selectedGames[i]) !== -1) {
                                    featcount++;
                                }
                            } else if (allfeats[f] === "feature-singleplayer") {
                                if (gameIdArrays["singleplayer"] && gameIdArrays["singleplayer"].indexOf(selectedGames[i]) !== -1) {
                                    featcount++;
                                }
                            } else if (allfeats[f] === "feature-multiplayer") {
                                if (gameIdArrays["multionline"] && gameIdArrays["multionline"].indexOf(selectedGames[i]) !== -1) {
                                    featcount++;
                                }
                            } else if (allfeats[f] === "feature-multiplayerlocal") {
                                if (gameIdArrays["multilocal"] && gameIdArrays["multilocal"].indexOf(selectedGames[i]) !== -1) {
                                    featcount++;
                                }
                            } else if (allfeats[f] === "feature-coop") {
                                if (gameIdArrays["cooponline"] && gameIdArrays["cooponline"].indexOf(selectedGames[i]) !== -1) {
                                    featcount++;
                                }
                            } else if (allfeats[f] === "feature-cloudenabled") {
                                if (gameIdArrays["cloud"] && gameIdArrays["cloud"].indexOf(selectedGames[i]) !== -1) {
                                    featcount++;
                                }
                            } else if (allfeats[f] === "feature-smartdelivery") {
                                if (gameIdArrays["cross"] && gameIdArrays["cross"].indexOf(selectedGames[i]) !== -1) {
                                    featcount++;
                                }
                            } else if (allfeats[f] === "feature-genNine") {
                                if (gameIdArrays["genNine"] && gameIdArrays["genNine"].indexOf(selectedGames[i]) !== -1) {
                                    featcount++;
                                }
                            } else if (allfeats[f] === "feature-cooplocal") {
                                if (gameIdArrays["cooplocal"] && gameIdArrays["cooplocal"].indexOf(selectedGames[i]) !== -1) {
                                    featcount++;
                                }
                            }
                        }
                        if (featcount === allfeats.length) {
                            featureset = 1;
                        }
                    } else {
                        featureset = 1;
                    }

                    // rating filter
                    if (filt.indexOf("rating-") !== -1) {
                        var allrats = [];
                        filterarray.forEach(function(fa) {
                            if (fa.indexOf("rating-") !== -1) {
                                allrats.push(fa.replace("rating-", ""));
                            }
                        });
                        for (var f = 0; f < allrats.length; f++) {
                            if (allGames[selectedGames[i]]["rating"] === allrats[f]) {
                                ratingset = 1;
                            }
                        }
                    } else {
                        ratingset = 1;
                    }

                    filtsettotal = availset + platset + genreset + featureset + ratingset;
                    if (filtsettotal === 5) {
                        // game passes all 5 filters
                        prunedGames.push(selectedGames[i]);
                    }
                }
            } else {
                if (filterarray.indexOf("avail-download") !== -1) {
                    for (var p = 0; p < ratarrlen; p++) {
                        if (allGamesExcludes.indexOf(selectedGames[p]) === -1 && allGames[selectedGames[p]] && allGames[selectedGames[p]]["physical"] === "false") {
                            prunedGames.push(selectedGames[p]);
                        }
                    }
                } else if (filterarray.indexOf("avail-physical") !== -1) {
                    for (var p = 0; p < ratarrlen; p++) {
                        if (allGames[selectedGames[p]]["physical"] === "true") {
                            prunedGames.push(selectedGames[p]);
                        }
                    }
                }
            }

            //sort based on sort
            if (sort === "featured") {
                if (cat === gameIdArrays["mostplayed"]) {
                    prunedGames = prunedGames.sort(asc_sort);

                    function asc_sort(a, b) {
                        return gameIdArrays["mostplayed"].indexOf(b) < gameIdArrays["mostplayed"].indexOf(a) ? 1 : -1;
                    }
                } else if (cat === gameIdArrays["multionline"]) {
                    function asc_sort(a, b) {
                        return gameIdArrays["multionline"].indexOf(b) < gameIdArrays["mostplayed"].indexOf(a) ? 1 : -1;
                    }
                } else {
                    prunedGames = prunedGames.sort(asc_sort);

                    function asc_sort(a, b) {
                        return fullGameArray.indexOf(b) < fullGameArray.indexOf(a) ? 1 : -1;
                    }
                }
            } else if (sort === "release") {
                prunedGames = prunedGames.sort(asc_sort);

                function asc_sort(a, b) {
                    return new Date(allGames[a]["releasedate"]) < new Date(allGames[b]["releasedate"]) ? 1 : -1;
                }
            } else if (sort === "az") {
                prunedGames = prunedGames.sort(asc_sort);

                function asc_sort(a, b) {
                    return allGames[b]["title"].toLowerCase().trim().replace("ō", "o").replace("®", "").replace("é", "e") < allGames[a]["title"].toLowerCase().trim().replace("ō", "o").replace("®", "").replace("é", "e") ? 1 : -1;
                }
            } else if (sort === "za") {
                prunedGames = prunedGames.sort(asc_sort);

                function asc_sort(a, b) {
                    return allGames[a]["title"].toLowerCase().trim().replace("ō", "o").replace("®", "").replace("é", "e") < allGames[b]["title"].toLowerCase().trim().replace("ō", "o").replace("®", "").replace("é", "e") ? 1 : -1;
                }
            }

            // Check for games featured in parent Hero to remove from related More Recommendation rotators
            var dupFeaturedGames = [];
            $(".copy-hero.hero-product-placement .m-hero-item[data-bigid]").each(function(){
                dupFeaturedGames.push($(this).attr("data-bigid"));
            });

            if (filt.indexOf("avail-download") === -1) {
                prunedGames = prunedGames.filter(function(id) {
                    return dupFeaturedGames.indexOf(id) === -1;
                });
            }

            populateQL(prunedGames, 0, filt, 12);
        }, 10);
    }

    function populateQL(array, page, filt, total) {
        docwidth = $(document).width();
        var currregion;
        var startgame = page * total;
        shownGames = array.slice(startgame, startgame + total);
        gamehtml = "";
        var catarrlen = shownGames.length;

        for (var i = 0; i < catarrlen; i++) {
            var thebigid = shownGames[i];
            if (urlRegion !== "ar-sa" && urlRegion !== "ar-ae") {
                var msrpshown = allGames[thebigid]["msrpprice"].toLocaleString(urlRegion, {
                    style: "currency",
                    currency: allGames[thebigid]["currencycode"]
                });
                var listshown = allGames[thebigid]["listprice"].toLocaleString(urlRegion, {
                    style: "currency",
                    currency: allGames[thebigid]["currencycode"]
                });
            } else {
                if (urlRegion === "ar-sa") {
                    currregion = "en-us";
                } else {
                    currregion = "en-ca";
                }
                var msrpshown = allGames[thebigid]["msrpprice"].toLocaleString(currregion, {
                    style: "currency",
                    currency: allGames[thebigid]["currencycode"]
                });
                var listshown = allGames[thebigid]["listprice"].toLocaleString(currregion, {
                    style: "currency",
                    currency: allGames[thebigid]["currencycode"]
                });
            }

            if (allGames[thebigid]["listprice"] !== 100000000) {
                if (allGames[thebigid]["msrpprice"] !== allGames[thebigid]["listprice"] && allGames[thebigid]["gameswithgold"] === "false") {
                    var priceshown = '<div class="c-price" itemprop="offers" itemscope="" itemtype="http://schema.org/Offer">' + //'<s aria-label="' + regionContent["keyFullprice"].replace("<PLACEHOLDER>", msrpshown) + '">' + msrpshown + '</s>' +
                    '<s><span class="x-screen-reader">' + regionContent["keyFullprice"] + "</span> " + msrpshown + "</s>" + '<meta itemprop="priceCurrency" content="' + allGames[thebigid]["currencycode"] + '">' + '<span class="textpricenew x-hidden-focus" itemprop="price">' + listshown + "</span>" + "</div>";
                } else {
                    var priceshown = '<div class="c-price" itemprop="offers" itemscope="" itemtype="http://schema.org/Offer">' + '<meta itemprop="priceCurrency" content="' + allGames[thebigid]["currencycode"] + '">' + '<span class="textpricenew x-hidden-focus" itemprop="price">' + msrpshown + "</span>" + "</div>";
                }
            } else {
                var priceshown = "";
            }

            var pricestartingat = "";
            if (gameIdArrays["startingat"] && gameIdArrays["startingat"].indexOf(thebigid) !== -1) {
                pricestartingat = '<div class="startingattext">' + regionContent["keyStartingat"] + "</div>";
            }

            badges = "";
            if (allGames[thebigid]["gameswithgold"] === "true") {
                badges += '<span class="c-badge f-small f-highlight">' + regionContent["keyBadgegwg"] + "</span>";
            } else if (allGames[thebigid]["onsale"] === "true") {
                badges += '<span class="c-badge f-small f-highlight">' + regionContent["keyBadgeonsale"] + "</span>";
            }
            if (allGames[thebigid]["newrelease"] === "true") {
                badges += '<span class="c-badge f-small badge-silver">' + regionContent["keyBadgenewrelease"] + "</span>";
            }
            if (allGames[thebigid]["upcoming"] === "true" && allGames[thebigid]["purchasable"] === "false") {
                badges += '<span class="c-badge f-small badge-silver">' + regionContent["keyBadgecomingsoon"] + "</span>";
            }
            if (allGames[thebigid]["title"].toLowerCase().indexOf("preview") !== -1 || (allGames[thebigid]["description"] !== null && allGames[thebigid]["description"].toLowerCase().indexOf("game preview") !== -1) || (allGames[thebigid]["description"] !== null && allGames[thebigid]["description"].toLowerCase().indexOf("gamepreview") !== -1)) {
                badges += "";
            } else if (allGames[thebigid]["upcoming"] === "true" && allGames[thebigid]["purchasable"] === "true" && allGames[thebigid]["title"].toLowerCase().indexOf("game preview") === -1) {
                badges += '<span class="c-badge f-small badge-silver">' + regionContent["keyBadgepreorder"] + "</span>";
            }

            var theboxshot = allGames[thebigid]["boxshot"];

            var disprelease = "-";
            if (allGames[thebigid]["releasedate"] !== 0) {
                var d = new Date(allGames[thebigid]["releasedate"]);
                if (d.getFullYear() < 2027) {
                    disprelease = d.toLocaleDateString(urlRegion, {
                        year: "numeric",
                        month: "long",
                        day: "numeric",
                    });
                }
            }

            var thestars = "";
            if (allGames[thebigid]["starcount"] > 4) {
                var totalratings = allGames[thebigid]["starcount"];
                var avgrating = allGames[thebigid]["stars"];
                var percentfilled = (avgrating / 5) * 100;
                var offset;
                if (percentfilled <= 20) {
                    offset = 0;
                } else if (percentfilled > 20 && percentfilled <= 40) {
                    offset = 12;
                } else if (percentfilled > 40 && percentfilled <= 60) {
                    offset = 24;
                } else if (percentfilled > 60 && percentfilled <= 80) {
                    offset = 36;
                } else if (percentfilled > 80 && percentfilled <= 100) {
                    offset = 48;
                }
                var starsfilled = (percentfilled / 100) * 90 + offset;
                thestars = '<div class="ratingstars" data-starpercent="' + starsfilled + '"><div class="c-rating f-individual emptystars" data-value="' + avgrating + '" data-max="5" itemscope itemtype="https://schema.org/Rating">' + '<p class="x-screen-reader">User rating:' + '<span itemprop="ratingValue">' + avgrating + "</span>/" + '<span itemprop="bestRating">5</span>' + "</p>" + '<div class="c-rating f-individual filledstars" data-value="5" data-max="5" itemscope itemtype="https://schema.org/Rating">' + '<p class="x-screen-reader">' + '<span itemprop="ratingValue">5</span>/' + '<span itemprop="bestRating">5</span>' + "</p>" + "<div></div>" + '</div></div></div><span class="reviewtotal">' + allGames[thebigid]["starcount"] + "</span>";
            }

            var thedescriptors = "";
            var rawdesc = allGames[thebigid]["descriptors"];
            var rdarray = rawdesc.split(",");
            var rdtext = [];
            for (var r = 0; r < rdarray.length; r++) {
                var descnum = ratingData.RatingBoards[allGames[thebigid]["ratingsystem"]].LocalizedProperties[0].Descriptors.length;
                for (var s = 0; s < descnum; s++) {
                    if (ratingData.RatingBoards[allGames[thebigid]["ratingsystem"]].LocalizedProperties[0].Descriptors[s].Key === rdarray[r]) {
                        var desc = ratingData.RatingBoards[allGames[thebigid]["ratingsystem"]].LocalizedProperties[0].Descriptors[s].Descriptor;
                        rdtext.push(desc);
                    }
                }
            }
            thedescriptors = rdtext.join(",</span> <span class='descNoWrap'>");
            if (thedescriptors !== "") {
                thedescriptors = '<span class="descNoWrap">' + thedescriptors + "</span>";
            }
            var theinteractive = "";
            var rawint = allGames[thebigid]["interactive"];
            var rintarray = rawint.split(",");
            var rinttext = [];
            for (var r = 0; r < rintarray.length; r++) {
                var intnum = ratingData.RatingBoards[allGames[thebigid]["ratingsystem"]].LocalizedProperties[0].InteractiveElements.length;
                for (var s = 0; s < intnum; s++) {
                    if (ratingData.RatingBoards[allGames[thebigid]["ratingsystem"]].LocalizedProperties[0].InteractiveElements[s].Key === rintarray[r]) {
                        var int = ratingData.RatingBoards[allGames[thebigid]["ratingsystem"]].LocalizedProperties[0].InteractiveElements[s].InteractiveElement;
                        rinttext.push(int);
                    }
                }
            }
            theinteractive = rinttext.join(",</span> <span class='descNoWrap'>");
            if (theinteractive !== "") {
                theinteractive = '<span class="descNoWrap">' + theinteractive + "</span>";
            }
            var thedisclaimers = "";
            var rawdisc = allGames[thebigid]["disclaimers"];
            var rdiscarray = rawdisc.split(",");
            var rdisctext = [];
            for (var r = 0; r < rdiscarray.length; r++) {
                var discnum = ratingData.RatingBoards[allGames[thebigid]["ratingsystem"]].LocalizedProperties[0].Disclaimers.length;
                for (var s = 0; s < discnum; s++) {
                    if (ratingData.RatingBoards[allGames[thebigid]["ratingsystem"]].LocalizedProperties[0].Disclaimers[s].Key === rdiscarray[r]) {
                        var disc = ratingData.RatingBoards[allGames[thebigid]["ratingsystem"]].LocalizedProperties[0].Disclaimers[s].Disclaimer;
                        if (disc.length > 48) {
                            var discarr = disc.split(". ");
                            disc = discarr.join(". <br>");
                        }
                        rdisctext.push(disc);
                    }
                }
            }
            thedisclaimers = rdisctext.join(",</span> <span class='descNoWrap'>");
            if (thedisclaimers !== "") {
                thedisclaimers = '<span class="descNoWrap">' + thedisclaimers + "</span>";
            }

            var popiconRating, popiconEnhanced, popiconsXpa, popicon4k, popiconHdr;
            popiconRating = popiconEnhanced = popiconXpa = popicon4k = popiconHdr = "";

            var previousExists = false;
            if (allGames[thebigid]["rating"] === "none") {
                popiconRating = "";
                // } else if (ratingImages[allGames[thebigid]["rating"]] !== undefined) {
                //   popiconRating = '<span class="popicon piRating"><img src="' + ratingImages[allGames[thebigid]["rating"]] + '"></span>';
            } else {
                popiconRating = '<span class="popicon piRating">' + allGames[thebigid]["rating"] + "</span>";
            }

            if (gameIdArrays["genNine"] && gameIdArrays["genNine"].indexOf(thebigid) !== -1) {
                popiconEnhanced = '<span class="c-paragraph-3"> ' + quickLookLocStrings.locales[urlRegion]["keyOptimizedforxboxseriesxs"] + " </span>";
                previousExists = true;
            }

            if (gameIdArrays["cross"] && gameIdArrays["cross"].indexOf(thebigid) !== -1) {
                if (previousExists) {
                    popiconXpa = '<span class="featureCircle">&nbsp;&nbsp;●&nbsp;&nbsp;</span>';
                }
                popiconXpa += '<span class="c-paragraph-3"> ' + quickLookLocStrings.locales[urlRegion]["keySmartdelivery"] + " </span>";
                previousExists = true;
            }

            // if (gameIdArrays["cloud"] && gameIdArrays["cloud"].indexOf(thebigid) !== -1) {
            //     if (previousExists) {
            //         popiconXpa = '<span class="featureCircle">&nbsp;&nbsp;●&nbsp;&nbsp;</span>'
            //     }
            //     popiconXpa += '<span class="c-paragraph-3"> ' + quickLookLocStrings.locales[urlRegion]["keyCloudenabled"] + ' </span>';
            //     previousExists = true;
            // }

            // if (gameIdArrays["enhanced"] && gameIdArrays["enhanced"].indexOf(thebigid) !== -1) {
            //     popiconEnhanced = '<span class="popicon" aria-label="Xbox One Enhanced"><img style="width:100px;" alt="" src=""></span>';
            // }

            // if (gameIdArrays["xpa"] && gameIdArrays["xpa"].indexOf(thebigid) !== -1) {
            //     popiconXpa = '<span class="popicon" aria-label="Xbox Play Anywhere"><img style="width:94px;" alt="" src=""></span>';
            // }

            // if (gameIdArrays["fourk"] && gameIdArrays["fourk"].indexOf(thebigid) !== -1) {
            //     popicon4k = '<span class="popicon" aria-label="4K Ultra HD"><img style="width:57px;" alt="" src=""></span>';
            // }

            // if (gameIdArrays["HDRGaming"] && gameIdArrays["HDRGaming"].indexOf(thebigid) !== -1) {
            //     popiconHdr = '<span class="popicon" aria-label="HDR"><img style="width:79px;" alt="" src=""></span>';
            // }

            var popbadges = "";
            var popgoldprice = "";
            if (allGames[thebigid]["msrpprice"] !== allGames[thebigid]["listprice"]) {
                var listdiff = allGames[thebigid]["msrpprice"] - allGames[thebigid]["listprice"];
                var listperc = Math.round((listdiff / allGames[thebigid]["msrpprice"]) * 100).toString() + "%";
                popbadges += '<span class="c-badge f-small badge-silver">' + regionContent["keyPopbadgepercent"].replace("<PLACEHOLDER>", listperc) + "</span>";
            }

            if (allGames[thebigid]["goldandsilversale"] === "true") {
                popbadges += '<span class="c-badge f-small f-highlight">' + regionContent["keyPopgolddiscount"] + "</span>";
                if (urlRegion !== "ar-sa" && urlRegion !== "ar-ae") {
                    var specialshown = allGames[thebigid]["goldandsilversalegoldprice"].toLocaleString(urlRegion, {
                        style: "currency",
                        currency: allGames[thebigid]["currencycode"],
                    });
                } else {
                    if (urlRegion === "ar-sa") {
                        currregion = "en-us";
                    } else {
                        currregion = "en-ca";
                    }
                    var specialshown = allGames[thebigid]["goldandsilversalegoldprice"].toLocaleString(currregion, {
                        style: "currency",
                        currency: allGames[thebigid]["currencycode"],
                    });
                }

                popgoldprice += '<div class="popgoldarea"><div class="c-price popgoldprice" itemprop="offers" itemscope="" itemtype="http://schema.org/Offer">' + '<meta itemprop="priceCurrency" content="' + allGames[thebigid]["currencycode"] + '">' + '<span class="textpricenew x-hidden-focus" itemprop="price">' + specialshown + "</span>" + "</div>" + '<img class="popgoldlogo" src="https://assets.xboxservices.com/assets/3c/51/3c5104fc-1eda-4d65-8703-40357746731a.svg?n=X1-Games-Catalog_0_Gold-Logo_64x23.svg"></div>';
            } else if (allGames[thebigid]["golddiscount"] === "true" || allGames[thebigid]["gameswithgold"] === "true") {
                popbadges += '<span class="c-badge f-small f-highlight">' + regionContent["keyPopgolddiscount"] + "</span>";
                if (urlRegion !== "ar-sa" && urlRegion !== "ar-ae") {
                    var specialshown = allGames[thebigid]["specialprice"].toLocaleString(urlRegion, {
                        style: "currency",
                        currency: allGames[thebigid]["currencycode"]
                    });
                } else {
                    if (urlRegion === "ar-sa") {
                        currregion = "en-us";
                    } else {
                        currregion = "en-ca";
                    }
                    var specialshown = allGames[thebigid]["specialprice"].toLocaleString(currregion, {
                        style: "currency",
                        currency: allGames[thebigid]["currencycode"]
                    });
                }
                popgoldprice += '<div class="popgoldarea"><div class="c-price popgoldprice" itemprop="offers" itemscope="" itemtype="http://schema.org/Offer">' + '<meta itemprop="priceCurrency" content="' + allGames[thebigid]["currencycode"] + '">' + '<span class="textpricenew x-hidden-focus" itemprop="price">' + specialshown + "</span>" + "</div>" + '<img class="popgoldlogo" src="https://assets.xboxservices.com/assets/3c/51/3c5104fc-1eda-4d65-8703-40357746731a.svg?n=X1-Games-Catalog_0_Gold-Logo_64x23.svg"></div>';
            }

            var popservices = "";
            var abovetitle = "";
            if (allGames[thebigid]["gamepassgame"] === "true") {
                // popservices += '<div class="servicesarea"><p>' + regionContent["keyPopgpgame"] + '</p></div>';
                abovetitle = '<div class="c-glyph gp-glyph"><img src="https://assets.xboxservices.com/assets/bd/d6/bdd616b4-9210-4d36-9d4f-0f9f21969131.svg?n=Games-Catalog_Image-0_Game-Pass-Badge_144x24.svg" alt="game pass icon"/></div>';
            }
            if (allGames[thebigid]["eaaccessgame"] === "true" && allGames[thebigid]["specialprice"] !== 100000000) {
                if (urlRegion !== "ar-sa" && urlRegion !== "ar-ae") {
                    var eaprice = allGames[thebigid]["specialprice"].toLocaleString(urlRegion, {
                        style: "currency",
                        currency: allGames[thebigid]["currencycode"]
                    });
                } else {
                    if (urlRegion === "ar-sa") {
                        currregion = "en-us";
                    } else {
                        currregion = "en-ca";
                    }
                    var eaprice = allGames[thebigid]["specialprice"].toLocaleString(currregion, {
                        style: "currency",
                        currency: allGames[thebigid]["currencycode"]
                    });
                }

                popservices += '<div class="servicesarea"><p>' + regionContent["keyPopeagame"].replace("<PLACEHOLDER>", eaprice) + "</p></div>";
            }

            // Free-to-play -- use "LEARN MORE" instead
            // var popbuytext = regionContent["keyBuynow"];
            var popbuytext = regionContent["keyLearnmore"];
            if (allGames[thebigid]["title"].toLowerCase().indexOf("preview") !== -1 || (allGames[thebigid]["description"] !== null && allGames[thebigid]["description"].toLowerCase().indexOf("game preview") !== -1) || (allGames[thebigid]["description"] !== null && allGames[thebigid]["description"].toLowerCase().indexOf("gamepreview") !== -1)) {
                // Free-to-play -- use "LEARN MORE" instead
                // var popbuytext = regionContent["keyBuynow"];
                popbuytext = regionContent["keyLearnmore"];
            } else if (gameIdArrays["upcoming"] && gameIdArrays["upcoming"].indexOf(thebigid) !== -1 && allGames[thebigid]["purchasable"] === "true") {
                popbuytext = regionContent["keyPreordernow"];
            }

            var datatrack = 'data-retailer="ms store"';
            if (allGames[thebigid]["gameurl"].toLowerCase().indexOf("games/store") === -1) {
                datatrack = 'data-cta="learn"';
            }

            if (allGames[thebigid]["gameurl"].toLowerCase().indexOf("games/store") !== -1) {
                priceButtons = '<a href="' + allGames[thebigid]["gameurl"] + '" data-clickname="www>games>xbox-one>' + allGames[thebigid]["titleclickname"] + '>buy-now>click" class="c-call-to-action c-glyph popbuynow" target="_blank" ' + datatrack + ' aria-label="' + popbuytext + ", " + allGames[thebigid]["title"] + '">' + "<span>" + popbuytext + "</span>" + "</a>";
            } else {
                priceButtons = '<a href="' + allGames[thebigid]["gameurl"] + '" data-clickname="www>games>xbox-one>' + allGames[thebigid]["titleclickname"] + '>learn-more>click" class="c-call-to-action c-glyph poplastbutton" target="_blank" ' + datatrack + ">" + "<span>" + regionContent["keyLearnmore"] + "</span>" + "</a>";
            }
            if (gameIdArrays["upcoming"] && gameIdArrays["upcoming"].indexOf(thebigid) !== -1 && allGames[thebigid]["purchasable"] === "false") {
                popbadges = "";
                priceshown = '<div class="c-price" itemprop="offers" itemscope="" itemtype="http://schema.org/Offer">' + '<span class="textpricenew soontextprice x-hidden-focus" itemprop="price">' + regionContent["keyBadgecomingsoonlower"] + "</span>" + "</div>";
                popgoldprice = "";
                popservices = "";
                priceButtons = '<a href="' + allGames[thebigid]["gameurl"] + '" data-clickname="www>games>xbox-one>' + allGames[thebigid]["titleclickname"] + '>learn-more>click" class="c-call-to-action c-glyph poplastbutton" target="_blank">' + "<span>" + regionContent["keyLearnmore"] + "</span>" + "</a>";
            }

            // 24 hours hide price
            var tempreldate = new Date(allGames[thebigid]["releasedate"]);
            var tempnowdate = new Date();
            var hoursaway = new Date(tempreldate.toGMTString()) - new Date(tempnowdate.toGMTString());
            hoursaway = hoursaway / 1000 / 60 / 60;
            // gives hours

            var poppriceclass = "";
            if (gameIdArrays["upcoming"] && gameIdArrays["upcoming"].indexOf(thebigid) !== -1 && hoursaway > 0 && hoursaway < 24) {
                priceshown = "";
                popprice = "";
                poppriceclass = " nopricegame ";
            } else {
                popprice = '<div class="popprice">';
            }

            var plxb = "";
            var plpc = "";
            var plxsx = "";
            var plmo = "";

            if (allGames[thebigid]["platformxsx"] === "true") {
                plxsx = '<div class="c-tag">' + // '<span class="c-glyph svg-xbox-series-x" role="img" aria-label=""><svg class="high-contrast-svg-white" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 2048 2048" width="20" height="20"><path d="M832 384q-26 0-45-19t-19-45q0-26 19-45t45-19q26 0 45 19t19 45q0 26-19 45t-45 19zM512 0h1024v2048H512V0zm896 1920V128H640v1792h128v-896h128v896h512z" alt=""></path></svg></span>' +
                "Xbox Series X|S" + "</div>";
            }

            if (allGames[thebigid]["platformxo"] === "true") {
                plxb = '<div class="c-tag">' + // '<span class="c-glyph glyph-xbox-one-console" role="img" aria-label=""></span>' +
                "Xbox One" + "</div>";
            }
            if (allGames[thebigid]["platformpc"] === "true") {
                plpc = '<div class="c-tag">' + // '<span class="c-glyph glyph-pc1"></span>' +
                quickLookLocStrings.locales[urlRegion]["keyPc"] + "</div>";
            }
            if (gameIdArrays["cloud"] && gameIdArrays["cloud"].indexOf(thebigid) !== -1 && nonCloudRegions.indexOf(urlRegion) === -1) {
                plmo = '<div class="c-tag capitalFirst">' + // '<span class="c-glyph glyph-mobile-tablet"></span>' +
                quickLookLocStrings.locales[urlRegion]["keyCloud"].toLowerCase() + "</div>";
            }

            var qlbutclass = "";
            if (allGames[thebigid]["physical"] === "true") {
                qlbutclass = " physgame";
            }

            var eachGameClass = "";
            if (docwidth > 1083 && navigator.userAgent.indexOf("iPad") === -1) {
                // Added check -EL 11/23/20
                eachGameClass = "m-product-placement-item f-size-large context-device gameDiv";
            } else {
                eachGameClass = "m-product-placement-item f-size-large context-device gameDiv qlButtonFunc";
            }

            var filtPromoteHeading = (filt === "avail-download" || filt === "curated-list");

            var eachGameTitleHeadingLevel = filtPromoteHeading ? 'h3' : 'h4';

            var eachgameA = "<li>" + '<section class="' + eachGameClass + qlbutclass + '" itemscope="" itemtype="http://schema.org/Product" data-bigid="' + thebigid + '" ' + 'data-prodid="' + thebigid + '" ' + 'data-releasedate="' + allGames[thebigid]["releasedate"] + '" data-msproduct="' + allGames[thebigid]["msproduct"] + '" data-multiplayer="' + allGames[thebigid]["multiplayer"] + '" data-rating="' + allGames[thebigid]["rating"] + '" data-ratingsystem="' + allGames[thebigid]["ratingsystem"] + '" data-listprice="' + allGames[thebigid]["listprice"] + '">' + '<a class="gameDivLink" href="' + allGames[thebigid]["gameurl"] + '" target="_blank" data-clickname="www>games>xbox-one>' + allGames[thebigid]["titleclickname"] + '>click" ' + datatrack + ">" + "<picture>" + '<img class="c-image" aria-hidden="true" alt="' + boxshotlocstrings.locales[urlRegion]["keyPlaceholderboxshot"].replace("<PLACEHOLDER>", allGames[thebigid]["title"]) + '" srcset="" src="' + theboxshot + '">' + "</picture>" + "<div>" + `<${eachGameTitleHeadingLevel} class="c-heading" itemprop="product name">` + allGames[thebigid]["title"] + `</${eachGameTitleHeadingLevel}>` + "</div>" + "</a>";

            var interactiveLine = "";
            var disclaimersLine = "";
            if (theinteractive !== "" && thedescriptors !== "") {
                interactiveLine = '<div class="descLine"></div>';
            }
            if (thedisclaimers !== "" && (theinteractive !== "" || thedescriptors !== "")) {
                disclaimersLine = '<div class="descLine"></div>';
            }

            var quickLookButton = '<div class="qlButton">' + '<button class="c-call-to-action c-glyph black-c" role="button" tabindex="0" aria-label="' + regionContent["keyQuickaria"] + '">' + regionContent["keyQuicklook"] + "</button>" + "</div>";

            var thepoptitle = allGames[thebigid]["title"];
            if (thepoptitle.length > 68) {
                thepoptitle = thepoptitle.slice(0, 68) + "...";
            }
            var thedescription = "";
            if (allGames[thebigid]["description"] !== null) {
                thedescription = allGames[thebigid]["description"];
            }
            if (thedescription.length > 200) {
                var descarr = thedescription.split(".");
                var newdesc = "";
                if (descarr[0].length > 200) {
                    thedescription = descarr[0].slice(0, 200) + "...";
                } else if (descarr.length > 1) {
                    newdesc = descarr[0];
                    for (var d = 1; d < descarr.length; d++) {
                        if (newdesc.length + descarr[d].length > 200) {
                            break;
                        } else {
                            newdesc = newdesc + ". " + descarr[d];
                        }
                    }
                    thedescription = newdesc + ".";
                }
            }

            var eawin10class = "";
            var eachgamePopup = '<div class="gameMoreInfo' + poppriceclass + '" data-gameRating="' + '" role="dialog" aria-label="dialog window with ' + allGames[thebigid]["title"] + ' information">' + '<button tabindex="0" class="qclosebutton" aria-label="close button for dialog window">' + '<img src="https://assets.xboxservices.com/assets/3b/df/3bdfab2d-d1b1-4019-9bac-d953db4fd7fb.svg?n=Games-Catalog_Image-0_X-Button_230x120.svg" alt="close button">' + "</button>" + '<div class="poprotator">' + '<div class="c-age-rating"><img class="c-image" src="' + allGames[thebigid]["ratimage"] + '" alt=""></div>' + "</div>" + '<div class="popinfo">' + abovetitle + '<div class="poptitle">' + '<h3 class="c-heading" itemprop="product name">' + thepoptitle + "</h3>" + thestars + "</div>" + '<div class="popdescription">' + '<div class="furtherrelease"><span class="furthheading">' + regionContent["keyDescription"] + ': </span><span class="furthcontent">' + thedescription.replace("’", "'") + "</span></div>" + "</div>" + '<div class="platformdescription"><div class="furtherplatform">' + plxsx + plxb + plpc + plmo + "</div></div>" + '<div class="popbottom">' + popprice + //badges +
            popbadges + pricestartingat + priceshown + popgoldprice + popservices + "</div>" + '<div class="popButton">' + priceButtons + "</div>" + '<div class="poprating">' + '<div class="prLeft">' + '<div class="c-age-rating"><img class="c-image" src="' + allGames[thebigid]["ratimage"] + '" alt=""></div>' + "</div>" + '<div class="prRight">' + '<a href="' + allGames[thebigid]["ratingUrl"] + '" class="c-hyperlink poplastbutton" aria-label="' + regionContent["keyAriaratings"].replace("<PLACEHOLDER>", allGames[thebigid]["rating"]) + '" data-cta="external" target="_blank" tabindex="0">' + allGames[thebigid]["rating"] + "</a>" + '<div class="ratingdescriptors">' + thedescriptors + "</div>" + interactiveLine + '<div class="ratinginteractive">' + theinteractive + "</div>" + disclaimersLine + '<div class="ratingdisclaimers">' + thedisclaimers + "</div>" + "</div>" + "</div>" + "</div>" + "</div>" + "</div>";

            var eachgameB = "</section></li>";

            if (docwidth > 1083) {
                gamehtml += eachgameA + quickLookButton + eachgamePopup + eachgameB;
            } else {
                gamehtml += eachgameA + eachgamePopup + eachgameB;
            }
        }

        var targetCarousel = $(".featured-games[data-games-filter='" + filt + "'] " + ".c-carousel ul");
        $(targetCarousel).append(gamehtml).closest(".c-carousel").removeClass("x-hidden").siblings(".spinnerHold").addClass("x-hidden");
        mwfAutoInit.ComponentFactory.create([{
            component: mwfAutoInit.MultiSlideCarousel,
            eventToBind: mwfAutoInit.DOMContentLoaded
        }, ]);
    }

    function populateAddOns(thisArray, thisElem) {
        // populate addons
        // console.log("Populating add-ons:");
        // console.log(thisArray);
        var userratingtext = $("#userratingtext").text();
        for (var a = 0; a < thisArray.length; a++) {
            var thebigid = thisArray[a];
            // console.log("populateAddOns is adding: ");
            // console.log(allGames[thebigid]);
            if (allGames[thebigid] !== undefined) {
                var point5rounded = Math.floor(allGames[thebigid].stars * 2) / 2;

                if (urlRegion !== "ar-sa" && urlRegion !== "ar-ae") {
                    var msrpshown = allGames[thebigid]["msrpprice"].toLocaleString(urlRegion, {
                        style: "currency",
                        currency: allGames[thebigid]["currencycode"]
                    });
                    var listshown = allGames[thebigid]["listprice"].toLocaleString(urlRegion, {
                        style: "currency",
                        currency: allGames[thebigid]["currencycode"]
                    });
                    var gpshown = allGames[thebigid]["gamepassprice"].toLocaleString(urlRegion, {
                        style: "currency",
                        currency: allGames[thebigid]["currencycode"]
                    });
                    var eashown = allGames[thebigid]["eaplayprice"].toLocaleString(urlRegion, {
                        style: "currency",
                        currency: allGames[thebigid]["currencycode"]
                    });
                } else {
                    if (urlRegion === "ar-sa") {
                        currregion = "en-us";
                    } else {
                        currregion = "en-ca";
                    }
                    var msrpshown = allGames[thebigid]["msrpprice"].toLocaleString(currregion, {
                        style: "currency",
                        currency: allGames[thebigid]["currencycode"]
                    });
                    var listshown = allGames[thebigid]["listprice"].toLocaleString(currregion, {
                        style: "currency",
                        currency: allGames[thebigid]["currencycode"]
                    });
                    var gpshown = allGames[thebigid]["gamepassprice"].toLocaleString(currregion, {
                        style: "currency",
                        currency: allGames[thebigid]["currencycode"]
                    });
                    var eashown = allGames[thebigid]["eaplayprice"].toLocaleString(currregion, {
                        style: "currency",
                        currency: allGames[thebigid]["currencycode"]
                    });
                }

                var aopricing = "";
                if (allGames[thebigid]["listprice"] !== 100000000) {
                    if (allGames[thebigid]["msrpprice"] !== allGames[thebigid]["listprice"] && allGames[thebigid]["gameswithgold"] === "false") {
                        aopricing = '<section class="pricing"><div class="leftCol"><p class="origPrice" aria-label="' + // DEBUG: Pick up here with oldnewpricestrings
                        oldnewpricestrings.locales["en-us"].keyOldprice.replace("<<PLACEHOLDERPRICE>>", msrpshown) + '">' + msrpshown + "</p></div>" + '<div class="rightCol"><p aria-label="' + oldnewpricestrings.locales["en-us"].keyNewprice.replace("<<PLACEHOLDERPRICE>>", listshown) + '">' + listshown + "</p></div></section>";
                    } else {
                        aopricing = '<section class="pricing"><div class="leftCol"><p>' + listshown + "</p></div></section>";
                    }
                }

                // if (urlRegion.indexOf("en-") > -1) {
                if (allGames[thebigid]["gamepassgame"] === "true") {
                    if (allGames[thebigid]["gamepassprice"] === 0) {
                        aopricing = '<section class="pricing"><span style="font-size: 0">' + gpstrings.locales[urlRegion].keyIncluded.replace("<<PLACEHOLDERGPLOGO>>", "Game Pass") + '</span><div class="leftCol" aria-hidden="true">' + gpstrings.locales[urlRegion].keyIncluded.replace("<<PLACEHOLDERGPLOGO>>", '<span class="context-glyph-tile"><span class="c-glyph" role="img" aria-label="Game Pass"></span></span>') + "</div></section>";
                    } else {
                        aopricing = '<section class="pricing"><div class="leftCol"><p class="origPrice" aria-label="' + gamepasspricestrings.locales[urlRegion].keyOldprice.replace("<<PLACEHOLDERPRICE>>", msrpshown) + '">' + msrpshown + "</p></div>" + '<div class="rightCol"><p aria-label="' + gamepasspricestrings.locales[urlRegion].keyNewprice.replace("<<PLACEHOLDERPRICE>>", gpshown) + '">' + gpstrings.locales[urlRegion].keyWith.replace("<<PLACEHOLDERPRICE>>", gpshown).replace("<<PLACEHOLDERGPLOGO>>", '<span class="context-glyph-tile"><span class="c-glyph" role="img" aria-label="Game Pass"></span></span></img>') + "</p></div></section>";
                    }
                }

                // console.log("<<PLACEHOLDERGPLOGO>>");

                if (allGames[thebigid]["eaplaygame"] === "true") {
                    // if (allGames[thebigid]["eaplayprice"] === 0) {
                    //   aopricing = '<section class="pricing"><span style="font-size: 0">' +
                    //     gpstrings.locales[urlRegion].keyIncluded.replace("<<PLACEHOLDERGPLOGO>>", "Game Pass") + '</span><div class="leftCol" aria-hidden="true">' +
                    //     gpstrings.locales[urlRegion].keyIncluded.replace("<<PLACEHOLDERGPLOGO>>", '<span class="context-glyph-tile"><span class="c-glyph"></span></span>') + '</div></section>';
                    // } else {
                    aopricing = '<section class="pricing"><div class="leftCol"><p class="origPrice" aria-label="' + gamepasspricestrings.locales[urlRegion].keyOldprice.replace("<<PLACEHOLDERPRICE>>", msrpshown).replace("Game Pass", "EA Play") + '">' + msrpshown + "</p></div>" + '<div class="rightCol"><p aria-label="' + eashown + " " + eaplaystrings.locales[urlRegion].keyWitheaplay + '">' + eashown + " " + eaplaystrings.locales[urlRegion].keyWitheaplay + "</p></div></section>";
                    // }
                }
                // }

                // console.log(`Appending ${thebigid} to placement ul`);

                $(thisElem).not(".ignoreApi").append("<li>" + 
                '<section class="m-product-placement-item f-size-large context-software" data-bigid="' + thebigid + '">' +
                '<a href="' + allGames[thebigid].gameurl + '" data-clickname="www>games>add-ons>' + allGames[thebigid].titleclickname + '>click" data-retailer="ms store">' +
                '<picture aria-hidden="true" style="background-color: ' + allGames[thebigid].boxbgcolor + '">' +
                '<source srcset="' + allGames[thebigid].squareshot + '" media="(min-width:0)">' +
                '<img class="c-image" srcset="' + allGames[thebigid].squareshot + '" src="' + allGames[thebigid].squareshot + '" ' + 'alt="' + allGames[thebigid].title + '">' +
                "</picture>" +
                "<div>" +
                '<h4 class="c-heading" itemprop="product name">' + allGames[thebigid].title + "</h4>" +
                aopricing +
                "</div>" +
                "</a>" + 
                "</section>" + 
                "</li>");

                // if (a === thisArray.length - 1) {
                //     post pop changes
                //     $("[data-bigid='9WZDNCRFJ3TJ'] picture").css("background-color", "white");
                //     $("[data-bigid='9WZDNCRFJ3TJ'] img").css("border", "1px solid lightgrey");
                //     if ($(".product-placements-container .m-product-placement ul li").length === 0) {
                //         $("#add-ons").remove();
                //     }
                // }
            } else {
                // console.log(`${thebigid} is invalid because it is ${allGames[thebigid] === undefined ? 'undefined' : 'not available'}` );
            }
        }
    }

    // tab only in popups
    setTimeout(function() {
        // with second close button
        /*redirect last tab to first input*/
        $(document).on("keydown", function(e) {
            if (e.keyCode === 9 && !e.shiftKey) {
                if ($(".gameMoreInfo.popupShow .poplastbutton")[0] === document.activeElement) {
                    e.preventDefault();
                    $(".gameMoreInfo.popupShow .qclosebutton").focus();
                }
            }
            if ((e.keyCode === 13 || e.keyCode === 32) && $(".gameMoreInfo.popupShow .qclosebutton")[0] === document.activeElement) {
                e.preventDefault();
                $(".gameMoreInfo.popupShow .qclosebutton").click();
            }
            if (e.keyCode === 27 && $(".gameMoreInfo.popupShow").length !== 0) {
                $(".gameMoreInfo.popupShow .qclosebutton").click();
            }
        });

        /*redirect first shift+tab to last input*/
        $(document).on("keydown", ".gameMoreInfo.popupShow .qclosebutton", function(e) {
            if (e.keyCode === 9 && e.shiftKey) {
                e.preventDefault();
                $(".gameMoreInfo.popupShow .poplastbutton").focus();
                if ($(".gameMoreInfo.popupShow .qclosebutton")[0] === document.activeElement) {
                    $(".gameMoreInfo.popupShow .poplastbutton").focus();
                }
            }
        });
    }, 250);

    // shift tab to focus on quick look
    $(document).on("keydown", function(e) {
        if (e.keyCode === 9 && e.shiftKey) {
            if (document.activeElement.classList.contains("gameDivLink") && $(".gameDivLink").eq(0)[0] !== document.activeElement) {
                //e.preventDefault();
                setTimeout(function() {
                    var theactive = document.activeElement;
                    if ($(theactive)[0].nodeName === "BUTTON") {
                        $(theactive).closest(".gameDiv").next(".gameDiv").find(".qlButton").removeClass("popupShow");
                        $(theactive).closest(".gameDiv").find(".qlButton").addClass("popupShow");
                        $(theactive).closest(".gameDiv").find(".qlButton button").focus();
                    }
                }, 10);
            }
        }
    });

    // popup
    $(document).on("mouseenter", ".gameDiv a.gameDivLink", function(e) {
        $(e.target).off("mouseleave");
        var buttontoshow = $(e.target).closest(".gameDiv").find(".qlButton");
        $(".popupShow").removeClass("popupShow");
        $(buttontoshow).addClass("popupShow");
    });

    $(document).on("focus", ".gameDiv a.gameDivLink", function(e) {
        $(".qlButton").removeClass("popupShow");
        var buttontoshow = $(e.target).closest(".gameDiv").find(".qlButton");
        $(".popupShow").removeClass("popupShow");
        $(buttontoshow).addClass("popupShow");
    });

    var origPopElem, origPopElemParent;

    $(document).on("click", ".qlButton button", qlButtonHandler);
    $(document).on("click", ".qlButtonFunc", qlButtonHandler);

    function qlButtonHandler(e) {
        e.preventDefault();
        // open popup dark background
        $("body").append('<div id="ql-page-cover"></div>');
        $("body").addClass("stop-scrolling");
        origPopElemParent = $(this).closest(".gameDiv");
        origPopElem = $(origPopElemParent).find(".gameMoreInfo");
        $(origPopElem).clone().appendTo(".qlCont");
        $(origPopElem).remove();
        var poptoopen = $(".qlCont").find(".gameMoreInfo");
        var starperc = $(poptoopen).find(".ratingstars").attr("data-starpercent") || "0";
        $(poptoopen).find(".c-rating[data-value].f-individual.filledstars div").css("width", starperc + "px");
        $(poptoopen).addClass("popupShow");
        $(poptoopen).find(".qclosebutton").focus();

        // populate rotator
        if ($(poptoopen).find(".poprotator .c-carousel").length === 0) {
            var thebigid = $(origPopElemParent).attr("data-bigid");
            if (allGames[thebigid]["physical"] === "true") {
                therotator = '<img class="physScreenshot" src="' + allGames[thebigid]["screenshot"] + '">';
            } else {
                var buttonhtml = "";
                var screenhtml = "";

                if (allGames[thebigid]["screenarray"].length > 0) {
                    for (var s = 0; s < allGames[thebigid]["screenarray"].length; s++) {
                        if (s === 0) {
                            var humannum = s + 1;
                            buttonhtml += '<button role="tab" aria-selected="true" aria-label="View slide ' + humannum + '" aria-controls="' + allGames[thebigid]["titleclickname"] + s + '"></button>';
                            screenhtml += '<li id="' + allGames[thebigid]["titleclickname"] + s + '" class="f-active" role="tabpanel" data-f-theme="dark" >' + '<section class="m-hero-item f-x-center f-y-center context-device theme-dark" itemscope itemtype="http://schema.org/Product">' + '<picture class="c-image">' + '<source srcset="' + allGames[thebigid]["screenarray"][s] + '" media="(min-width:0)">' + '<img srcset="' + allGames[thebigid]["screenarray"][s] + '" src="' + allGames[thebigid]["screenarray"][s] + '" alt="' + allGames[thebigid]["title"] + " " + quickLookLocStrings.locales[urlRegion]["keyScreenshot"] + '">' + "</picture>" + "</section>" + "</li>";
                        } else {
                            var humannum = s + 1;
                            buttonhtml += '<button role="tab" aria-selected="false" aria-label="View slide ' + humannum + '" aria-controls="' + allGames[thebigid]["titleclickname"] + s + '"></button>';
                            screenhtml += '<li id="' + allGames[thebigid]["titleclickname"] + s + '" role="tabpanel" data-f-theme="dark" >' + '<section class="m-hero-item f-x-center f-y-center context-device theme-dark" itemscope itemtype="http://schema.org/Product">' + '<picture class="c-image">' + '<source srcset="' + allGames[thebigid]["screenarray"][s] + '" media="(min-width:0)">' + '<img srcset="' + allGames[thebigid]["screenarray"][s] + '" src="' + allGames[thebigid]["screenarray"][s] + '" alt="' + allGames[thebigid]["title"] + " " + quickLookLocStrings.locales[urlRegion]["keyScreenshot"] + '">' + "</picture>" + "</section>" + "</li>";
                        }
                    }
                } else if (allGames[thebigid]["superheroart"]) {
                    // Using keyart if there are no screenshots, fall back solution
                    screenhtml += '<li id="' + allGames[thebigid]["titleclickname"] + s + '" role="tabpanel" data-f-theme="dark" >' + '<section class="m-hero-item f-x-center f-y-center context-device theme-dark" itemscope itemtype="http://schema.org/Product">' + '<picture class="c-image">' + '<source srcset="' + allGames[thebigid]["superheroart"] + '" media="(min-width:0)">' + '<img srcset="' + allGames[thebigid]["superheroart"] + '" src="' + allGames[thebigid]["superheroart"] + '" alt="' + boxshotlocstrings.locales[urlRegion]["keyPlaceholderboxshot"].replace("<PLACEHOLDER>", allGames[thebigid]["title"]) + '">' + "</picture>" + "</section>" + "</li>";
                } else {
                    console.log(allGames[thebigid]["superheroart"]);
                }

                if (fullcarouselimages.indexOf(thebigid) !== -1) {
                    //var fullimageclass = " carfullimage"; // this was in to resize images to satisfy stakeholders. -EL 11/4/20
                    var fullimageclass = "";
                } else {
                    var fullimageclass = "";
                }

                var randchars = makerand10();

                therotator = '<div class="c-carousel f-multi-slide f-auto-play' + fullimageclass + '" data-js-interval="6000">' + '<div class="c-group">' + '<div class="c-sequence-indicator" role="tablist">' + buttonhtml + "</div>" + '<button class="c-action-toggle c-glyph glyph-play f-toggle high-contrast" data-toggled-label="Pause" data-toggled-glyph="glyph-pause" aria-label="Play" ' + 'aria-describedby="tooltip' + randchars + '" data-toggle="tooltip">' + '<span id="tooltip' + randchars + '" class="c-tooltip" role="tooltip" aria-hidden="true">Play or pause this rotator</span>' + "</button>" + "</div>" + '<button class="c-flipper f-previous" aria-hidden="true" tabindex="-1"></button>' + '<button class="c-flipper f-next" aria-hidden="true" tabindex="-1"></button>' + '<div itemscope itemtype="http://schema.org/ItemList">' + "<ul>" + screenhtml + "</ul>" + "</div>" + "</div>";
            }

            if (allGames[thebigid]["physical"] === "false") {
                $(poptoopen).find(".poprotator").prepend(therotator);
                mwfAutoInit.ComponentFactory.create([{
                    component: mwfAutoInit.MultiSlideCarousel
                }]);
            } else if ($(poptoopen).find(".poprotator img").length === 0 && allGames[thebigid]["physical"] === "true") {
                $(poptoopen).find(".poprotator").css("border-bottom", "1px grey solid").prepend(therotator);
            }
        } else {
            // Re-activate existing carousel element
            mwfAutoInit.ComponentFactory.create([{
                component: mwfAutoInit.MultiSlideCarousel
            }]);
        }
    }

    $(document).on("keypress", ".qlButton button", function(event) {
        if (event.keyCode == 13 || event.keyCode == 32) {
            event.preventDefault();
            $(this).click();
        }
    });
    $(document).on("keypress", ".qlButtonFunc button", function(event) {
        if (event.keyCode == 13 || event.keyCode == 32) {
            event.preventDefault();
            $(this).click();
        }
    });

    $(document).on("click", "#ql-page-cover", function() {
        $(".gameMoreInfo.popupShow .qclosebutton").click();
        $("#ql-page-cover").remove();
        $("body").removeClass("stop-scrolling");
    });

    $(document).on("click", ".qclosebutton", function(e) {
        e.preventDefault();
        $(origPopElemParent).find(".gameDivLink").eq(0).focus();
        $(".gameMoreInfo").removeClass("popupShow");
        $("#ql-page-cover").remove();
        $("body").removeClass("stop-scrolling");
        $(origPopElemParent).append($(".qlCont .gameMoreInfo"));
        $(".qlCont").html("");
    });

    $(document).on("keypress", ".qclosebutton", function(event) {
        if (event.keyCode == 32 || event.keyCode == 13) {
            event.preventDefault();
            $(this).click();
        }
    });

    // Accessibility Events
    $(".c-select-menu li").click(function() {
        $(".gameDivLink").first().eq(0).focus();
    });

    $(document).on("mouseenter", ".c-glyph.f-toggle", function() {
        var idtoshow = "#" + $(this).attr("aria-describedby");
        setTimeout(function() {
            $(idtoshow).show();
        }, 500);
    });
    $(document).on("mouseleave", ".c-glyph.f-toggle", function() {
        var idtoshow = "#" + $(this).attr("aria-describedby");
        setTimeout(function() {
            $(idtoshow).hide();
        }, 510);
    });

    // FR Disclosure
    $(".disclosureClose").click(function() {
        $(this).closest(".c-flyout").prev("button").click();
    });
    $("#disclosureContainer .glyph-prepend").click(function() {
        setTimeout(function() {
            if ($("#frDisclosure").css("display") !== "none") {
                if ($(".CatAnnounce").text() === "l'info-bulle s'est ouverte") {
                    $(".CatAnnounce").text("l'info-bulle s'est ouverte.");
                } else {
                    $(".CatAnnounce").text("l'info-bulle s'est ouverte");
                }
            } else {
                $(".CatAnnounce").text("l'info-bulle s'est fermée");
            }
            $(".disclosureClose")[0].focus();
        }, 30);
    });

    function makerand10() {
        var text = "";
        var possible = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";

        for (var i = 0; i < 10; i++)
            text += possible.charAt(Math.floor(Math.random() * possible.length));

        return text;
    }
});

quickLookLocStrings = {
    locales: {
        keys: {
            keyAddtowishlist: "Add to wish list",
            keyOptimizedforxboxseriesxs: "Optimized for Xbox Series X|S",
            keySmartdelivery: "Smart Delivery",
            keyCloudenabled: "Cloud-enabled",
            keyPc: "PC",
            keyMobile: "Mobile",
            keyGetitnow: "GET IT NOW",
            keyPreordernow: "PRE-ORDER NOW",
            keyScreenshot: "screenshot",
            keyCloud: "Cloud",
        },
        "en-us": {
            keyAddtowishlist: "Add to wish list",
            keyOptimizedforxboxseriesxs: "Optimized for Xbox Series X|S",
            keySmartdelivery: "Smart Delivery",
            keyCloudenabled: "Cloud-enabled",
            keyPc: "PC",
            keyMobile: "Mobile",
            keyGetitnow: "GET IT NOW",
            keyPreordernow: "PRE-ORDER NOW",
            keyScreenshot: "screenshot",
            keyCloud: "CLOUD",
        },
        "ar-ae": {
            keyAddtowishlist: "Add to wish list",
            keyOptimizedforxboxseriesxs: "Optimised for Xbox Series X|S",
            keySmartdelivery: "Smart Delivery",
            keyCloudenabled: "Cloud-enabled",
            keyPc: "PC",
            keyMobile: "Mobile",
            keyGetitnow: "GET IT NOW",
            keyPreordernow: "PRE-ORDER NOW",
            keyScreenshot: "screenshot",
            keyCloud: "CLOUD",
        },
        "ar-sa": {
            keyAddtowishlist: "Add to wish list",
            keyOptimizedforxboxseriesxs: "Optimised for Xbox Series X|S",
            keySmartdelivery: "Smart Delivery",
            keyCloudenabled: "Cloud-enabled",
            keyPc: "PC",
            keyMobile: "Mobile",
            keyGetitnow: "GET IT NOW",
            keyPreordernow: "PRE-ORDER NOW",
            keyScreenshot: "screenshot",
            keyCloud: "CLOUD",
        },
        "cs-cz": {
            keyAddtowishlist: "Přidat do seznamu přání",
            keyOptimizedforxboxseriesxs: "Optimalizováno pro Xbox Series X|S",
            keySmartdelivery: "Inteligentní doručení",
            keyCloudenabled: "Cloudové",
            keyPc: "PC",
            keyMobile: "Mobilní zařízení",
            keyGetitnow: "POŘIĎTE SI JI JEŠTĚ DNES",
            keyPreordernow: "PŘEDOBJEDNAT",
            keyScreenshot: "snímek obrazovky",
            keyCloud: "CLOUD",
        },
        "da-dk": {
            keyAddtowishlist: "Føj til ønskeliste",
            keyOptimizedforxboxseriesxs: "Optimeret til Xbox Series X|S",
            keySmartdelivery: "Smart Delivery",
            keyCloudenabled: "Cloudaktiveret",
            keyPc: "Pc",
            keyMobile: "Mobil",
            keyGetitnow: "FÅ DET NU",
            keyPreordernow: "FORUDBESTIL NU",
            keyScreenshot: "skærmbillede",
            keyCloud: "CLOUD",
        },
        "de-at": {
            keyAddtowishlist: "Zur Wunschliste hinzufügen",
            keyOptimizedforxboxseriesxs: "Optimiert für Xbox Series X|S",
            keySmartdelivery: "Smart Delivery",
            keyCloudenabled: "Cloudfähig",
            keyPc: "PC",
            keyMobile: "Handy",
            keyGetitnow: "JETZT KAUFEN",
            keyPreordernow: "JETZT VORBESTELLEN",
            keyScreenshot: "Screenshot",
            keyCloud: "CLOUD",
        },
        "de-ch": {
            keyAddtowishlist: "Zur Wunschliste hinzufügen",
            keyOptimizedforxboxseriesxs: "Optimiert für Xbox Series X|S",
            keySmartdelivery: "Smart Delivery",
            keyCloudenabled: "Cloudfähig",
            keyPc: "PC",
            keyMobile: "Handy",
            keyGetitnow: "JETZT KAUFEN",
            keyPreordernow: "JETZT VORBESTELLEN",
            keyScreenshot: "Screenshot",
            keyCloud: "CLOUD",
        },
        "de-de": {
            keyAddtowishlist: "Zur Wunschliste hinzufügen",
            keyOptimizedforxboxseriesxs: "Optimiert für Xbox Series X|S",
            keySmartdelivery: "Smart Delivery",
            keyCloudenabled: "Cloudfähig",
            keyPc: "PC",
            keyMobile: "Handy",
            keyGetitnow: "JETZT KAUFEN",
            keyPreordernow: "JETZT VORBESTELLEN",
            keyScreenshot: "Screenshot",
            keyCloud: "CLOUD",
        },
        "el-gr": {
            keyAddtowishlist: "Προσθήκη στη λίστα επιθυμιών",
            keyOptimizedforxboxseriesxs: "Βελτιστοποιημένο για Xbox Series X|S",
            keySmartdelivery: "Smart Delivery",
            keyCloudenabled: "Με δυνατότητα cloud",
            keyPc: "PC",
            keyMobile: "Κινητό",
            keyGetitnow: "ΑΠΟΚΤΗΣΤΕ ΤΟ ΤΩΡΑ",
            keyPreordernow: "ΠΡΟ-ΠΑΡΑΓΓΕΛΙΑ ΤΩΡΑ",
            keyScreenshot: "στιγμιότυπο",
            keyCloud: "CLOUD",
        },
        "en-au": {
            keyAddtowishlist: "Add to wish list",
            keyOptimizedforxboxseriesxs: "Optimised for Xbox Series X|S",
            keySmartdelivery: "Smart Delivery",
            keyCloudenabled: "Cloud-enabled",
            keyPc: "PC",
            keyMobile: "Mobile",
            keyGetitnow: "GET IT NOW",
            keyPreordernow: "PRE-ORDER NOW",
            keyScreenshot: "screenshot",
            keyCloud: "CLOUD",
        },
        "en-ca": {
            keyAddtowishlist: "Add to wish list",
            keyOptimizedforxboxseriesxs: "Optimized for Xbox Series X|S",
            keySmartdelivery: "Smart Delivery",
            keyCloudenabled: "Cloud-enabled",
            keyPc: "PC",
            keyMobile: "Mobile",
            keyGetitnow: "GET IT NOW",
            keyPreordernow: "PRE-ORDER NOW",
            keyScreenshot: "screenshot",
            keyCloud: "CLOUD",
        },
        "en-gb": {
            keyAddtowishlist: "Add to wish list",
            keyOptimizedforxboxseriesxs: "Optimised for Xbox Series X|S",
            keySmartdelivery: "Smart Delivery",
            keyCloudenabled: "Cloud-enabled",
            keyPc: "PC",
            keyMobile: "Mobile",
            keyGetitnow: "GET IT NOW",
            keyPreordernow: "PRE-ORDER NOW",
            keyScreenshot: "screenshot",
            keyCloud: "CLOUD",
        },
        "en-hk": {
            keyAddtowishlist: "Add to wish list",
            keyOptimizedforxboxseriesxs: "Optimised for Xbox Series X|S",
            keySmartdelivery: "Smart Delivery",
            keyCloudenabled: "Cloud-enabled",
            keyPc: "PC",
            keyMobile: "Mobile",
            keyGetitnow: "GET IT NOW",
            keyPreordernow: "PRE-ORDER NOW",
            keyScreenshot: "screenshot",
            keyCloud: "CLOUD",
        },
        "en-ie": {
            keyAddtowishlist: "Add to wish list",
            keyOptimizedforxboxseriesxs: "Optimised for Xbox Series X|S",
            keySmartdelivery: "Smart Delivery",
            keyCloudenabled: "Cloud-enabled",
            keyPc: "PC",
            keyMobile: "Mobile",
            keyGetitnow: "GET IT NOW",
            keyPreordernow: "PRE-ORDER NOW",
            keyScreenshot: "screenshot",
            keyCloud: "CLOUD",
        },
        "en-in": {
            keyAddtowishlist: "Add to wish list",
            keyOptimizedforxboxseriesxs: "Optimised for Xbox Series X|S",
            keySmartdelivery: "Smart Delivery",
            keyCloudenabled: "Cloud-enabled",
            keyPc: "PC",
            keyMobile: "Mobile",
            keyGetitnow: "GET IT NOW",
            keyPreordernow: "PRE-ORDER NOW",
            keyScreenshot: "screenshot",
            keyCloud: "CLOUD",
        },
        "en-nz": {
            keyAddtowishlist: "Add to wish list",
            keyOptimizedforxboxseriesxs: "Optimised for Xbox Series X|S",
            keySmartdelivery: "Smart Delivery",
            keyCloudenabled: "Cloud-enabled",
            keyPc: "PC",
            keyMobile: "Mobile",
            keyGetitnow: "GET IT NOW",
            keyPreordernow: "PRE-ORDER NOW",
            keyScreenshot: "screenshot",
            keyCloud: "CLOUD",
        },
        "en-sg": {
            keyAddtowishlist: "Add to wish list",
            keyOptimizedforxboxseriesxs: "Optimised for Xbox Series X|S",
            keySmartdelivery: "Smart Delivery",
            keyCloudenabled: "Cloud-enabled",
            keyPc: "PC",
            keyMobile: "Mobile",
            keyGetitnow: "GET IT NOW",
            keyPreordernow: "PRE-ORDER NOW",
            keyScreenshot: "screenshot",
            keyCloud: "CLOUD",
        },
        "en-za": {
            keyAddtowishlist: "Add to wish list",
            keyOptimizedforxboxseriesxs: "Optimised for Xbox Series X|S",
            keySmartdelivery: "Smart Delivery",
            keyCloudenabled: "Cloud-enabled",
            keyPc: "PC",
            keyMobile: "Mobile",
            keyGetitnow: "GET IT NOW",
            keyPreordernow: "PRE-ORDER NOW",
            keyScreenshot: "screenshot",
            keyCloud: "CLOUD",
        },
        "es-ar": {
            keyAddtowishlist: "Añadir a la lista de deseos",
            keyOptimizedforxboxseriesxs: "Optimizado para Xbox Series X|S",
            keySmartdelivery: "Entrega inteligente",
            keyCloudenabled: "Habilitados para la nube",
            keyPc: "PC",
            keyMobile: "Dispositivos móviles",
            keyGetitnow: "CONSÍGUELO AHORA",
            keyPreordernow: "RESERVA AHORA",
            keyScreenshot: "captura de pantalla",
            keyCloud: "NUBE",
        },
        "es-cl": {
            keyAddtowishlist: "Añadir a la lista de deseos",
            keyOptimizedforxboxseriesxs: "Optimizado para Xbox Series X|S",
            keySmartdelivery: "Entrega inteligente",
            keyCloudenabled: "Habilitados para la nube",
            keyPc: "PC",
            keyMobile: "Dispositivos móviles",
            keyGetitnow: "CONSÍGUELO AHORA",
            keyPreordernow: "RESERVA AHORA",
            keyScreenshot: "captura de pantalla",
            keyCloud: "NUBE",
        },
        "es-co": {
            keyAddtowishlist: "Añadir a la lista de deseos",
            keyOptimizedforxboxseriesxs: "Optimizado para Xbox Series X|S",
            keySmartdelivery: "Entrega inteligente",
            keyCloudenabled: "Habilitados para la nube",
            keyPc: "PC",
            keyMobile: "Dispositivos móviles",
            keyGetitnow: "CONSÍGUELO AHORA",
            keyPreordernow: "RESERVA AHORA",
            keyScreenshot: "captura de pantalla",
            keyCloud: "NUBE",
        },
        "es-es": {
            keyAddtowishlist: "Añadir a la lista de deseos",
            keyOptimizedforxboxseriesxs: "Optimizado para Xbox Series X|S",
            keySmartdelivery: "Smart Delivery",
            keyCloudenabled: "Habilitados para la nube",
            keyPc: "PC",
            keyMobile: "Dispositivos móviles",
            keyGetitnow: "CONSÍGUELO HOY",
            keyPreordernow: "RESERVAR AHORA",
            keyScreenshot: "captura de pantalla",
            keyCloud: "NUBE",
        },
        "es-mx": {
            keyAddtowishlist: "Añadir a la lista de deseos",
            keyOptimizedforxboxseriesxs: "Optimizado para Xbox Series X|S",
            keySmartdelivery: "Entrega inteligente",
            keyCloudenabled: "Habilitados para la nube",
            keyPc: "PC",
            keyMobile: "Dispositivos móviles",
            keyGetitnow: "CONSÍGUELO AHORA",
            keyPreordernow: "RESERVA AHORA",
            keyScreenshot: "captura de pantalla",
            keyCloud: "NUBE",
        },
        "fi-fi": {
            keyAddtowishlist: "Lisää toivomusluetteloon",
            keyOptimizedforxboxseriesxs: "Optimoitu Xbox Series X|S:lle",
            keySmartdelivery: "Smart Delivery",
            keyCloudenabled: "Pilvipohjainen",
            keyPc: "PC:LLE",
            keyMobile: "Mobiili",
            keyGetitnow: "HANKI SE NYT",
            keyPreordernow: "TILAA ENNAKKOON NYT",
            keyScreenshot: "näyttökuva",
            keyCloud: "PILVI",
        },
        "fr-be": {
            keyAddtowishlist: "Ajouter à la liste de souhaits",
            keyOptimizedforxboxseriesxs: "Optimisé pour Xbox Series X|S",
            keySmartdelivery: "Smart Delivery",
            keyCloudenabled: "Compatible avec le cloud",
            keyPc: "PC",
            keyMobile: "Mobile",
            keyGetitnow: "ACHETEZ-LE DÈS MAINTENANT",
            keyPreordernow: "PRÉCOMMANDER MAINTENANT",
            keyScreenshot: "capture d’écran",
            keyCloud: "CLOUD",
        },
        "fr-ca": {
            keyAddtowishlist: "Ajouter à la liste de souhaits",
            keyOptimizedforxboxseriesxs: "Optimisé pour la Xbox Series X|S",
            keySmartdelivery: "Livraison intelligente",
            keyCloudenabled: "Compatible avec le jeu en nuage",
            keyPc: "PC",
            keyMobile: "Mobile",
            keyGetitnow: "OBTENEZ-LE MAINTENANT",
            keyPreordernow: "PRÉCOMMANDER MAINTENANT",
            keyScreenshot: "capture d’écran",
            keyCloud: "NUAGE",
        },
        "fr-ch": {
            keyAddtowishlist: "Ajouter à la liste de souhaits",
            keyOptimizedforxboxseriesxs: "Optimisé pour Xbox Series X|S",
            keySmartdelivery: "Smart Delivery",
            keyCloudenabled: "Compatible avec le cloud",
            keyPc: "PC",
            keyMobile: "Mobile",
            keyGetitnow: "ACHETEZ-LE DÈS MAINTENANT",
            keyPreordernow: "PRÉCOMMANDER MAINTENANT",
            keyScreenshot: "capture d’écran",
            keyCloud: "CLOUD",
        },
        "fr-fr": {
            keyAddtowishlist: "Ajouter à la liste de souhaits",
            keyOptimizedforxboxseriesxs: "Optimisé pour Xbox Series X|S",
            keySmartdelivery: "Smart Delivery",
            keyCloudenabled: "Compatible avec le cloud",
            keyPc: "PC",
            keyMobile: "Mobile",
            keyGetitnow: "ACHETEZ-LE DÈS MAINTENANT",
            keyPreordernow: "PRÉCOMMANDER MAINTENANT",
            keyScreenshot: "capture d’écran",
            keyCloud: "CLOUD",
        },
        "he-il": {
            keyAddtowishlist: "Add to wish list",
            keyOptimizedforxboxseriesxs: "Optimised for Xbox Series X|S",
            keySmartdelivery: "Smart Delivery",
            keyCloudenabled: "Cloud-enabled",
            keyPc: "PC",
            keyMobile: "Mobile",
            keyGetitnow: "GET IT NOW",
            keyPreordernow: "PRE-ORDER NOW",
            keyScreenshot: "screenshot",
            keyCloud: "CLOUD",
        },
        "hu-hu": {
            keyAddtowishlist: "Hozzáadás a kívánságlistához",
            keyOptimizedforxboxseriesxs: "Xbox Series X|S konzolra optimalizálva",
            keySmartdelivery: "Intelligens játékletöltés",
            keyCloudenabled: "Felhőkompatibilis",
            keyPc: "PC",
            keyMobile: "Mobil",
            keyGetitnow: "SZEREZD BE MÉG MA!",
            keyPreordernow: "RENDELD ELŐ MOST!",
            keyScreenshot: "képernyőfelvétel",
            keyCloud: "FELHŐ",
        },
        "it-it": {
            keyAddtowishlist: "Aggiungi all'elenco preferenze",
            keyOptimizedforxboxseriesxs: "Ottimizzato per Xbox Series X|S",
            keySmartdelivery: "Consegna intelligente",
            keyCloudenabled: "Utilizzabili via cloud",
            keyPc: "PC",
            keyMobile: "Dispositivi mobili",
            keyGetitnow: "ACQUISTA ORA",
            keyPreordernow: "PREORDINA ORA",
            keyScreenshot: "screenshot",
            keyCloud: "CLOUD",
        },
        "ja-jp": {
            keyAddtowishlist: "欲しい物リストに追加",
            keyOptimizedforxboxseriesxs: "Optimized for Xbox Series X|S",
            keySmartdelivery: "Smart Delivery",
            keyCloudenabled: "クラウド対応",
            keyPc: "PC",
            keyMobile: "Mobile",
            keyGetitnow: "今すぐ購入",
            keyPreordernow: "今すぐ予約する",
            keyScreenshot: "スクリーンショット",
            keyCloud: "クラウド",
        },
        "ko-kr": {
            keyAddtowishlist: "위시 리스트에 추가",
            keyOptimizedforxboxseriesxs: "Xbox Series X|S 최적화",
            keySmartdelivery: "스마트 딜리버리",
            keyCloudenabled: "클라우드 활성화",
            keyPc: "PC",
            keyMobile: "모바일",
            keyGetitnow: "지금 구매하세요",
            keyPreordernow: "지금 예약 주문하기",
            keyScreenshot: "스크린샷",
            keyCloud: "클라우드",
        },
        "nb-no": {
            keyAddtowishlist: "Legg til ønskeliste",
            keyOptimizedforxboxseriesxs: "Optimalisert for Xbox Series X|S",
            keySmartdelivery: "Smart Delivery",
            keyCloudenabled: "Sky-aktivert",
            keyPc: "PC",
            keyMobile: "Mobil",
            keyGetitnow: "SKAFF DEG DET NÅ",
            keyPreordernow: "FORHÅNDSBESTILL NÅ",
            keyScreenshot: "skjermbilde",
            keyCloud: "SKY",
        },
        "nl-be": {
            keyAddtowishlist: "Toevoegen aan verlanglijstje",
            keyOptimizedforxboxseriesxs: "Geoptimaliseerd voor Xbox Series X|S",
            keySmartdelivery: "Smart Delivery",
            keyCloudenabled: "Cloud-geschikt",
            keyPc: "PC",
            keyMobile: "Mobile",
            keyGetitnow: "KOOP NU",
            keyPreordernow: "PRE-ORDER NU",
            keyScreenshot: "screenshot",
            keyCloud: "CLOUD",
        },
        "nl-nl": {
            keyAddtowishlist: "Toevoegen aan verlanglijstje",
            keyOptimizedforxboxseriesxs: "Geoptimaliseerd voor Xbox Series X|S",
            keySmartdelivery: "Smart Delivery",
            keyCloudenabled: "Cloud-geschikt",
            keyPc: "PC",
            keyMobile: "Mobile",
            keyGetitnow: "KOOP NU",
            keyPreordernow: "PRE-ORDER NU",
            keyScreenshot: "screenshot",
            keyCloud: "CLOUD",
        },
        "pl-pl": {
            keyAddtowishlist: "Dodaj do listy życzeń",
            keyOptimizedforxboxseriesxs: "Zoptymalizowane dla Xbox Series X|S",
            keySmartdelivery: "Inteligentne pobieranie",
            keyCloudenabled: "Z możliwością grania w chmurze",
            keyPc: "KOMPUTER",
            keyMobile: "Telefon komórkowy",
            keyGetitnow: "KUP JUŻ TERAZ",
            keyPreordernow: "ZAMÓW W PRZEDSPRZEDAŻY",
            keyScreenshot: "zdjęcie z gry",
            keyCloud: "CHMURA",
        },
        "pt-br": {
            keyAddtowishlist: "Adicionar à lista de desejos",
            keyOptimizedforxboxseriesxs: "Otimizado para Xbox Series X|S",
            keySmartdelivery: "Entrega Inteligente",
            keyCloudenabled: "Pronto para a nuvem",
            keyPc: "PC",
            keyMobile: "Dispositivos móveis",
            keyGetitnow: "ADQUIRA AGORA",
            keyPreordernow: "RESERVE AGORA",
            keyScreenshot: "captura de tela",
            keyCloud: "NUVEM",
        },
        "pt-pt": {
            keyAddtowishlist: "Adicionar à lista de desejos",
            keyOptimizedforxboxseriesxs: "Otimizado para a Xbox Series X|S",
            keySmartdelivery: "Entrega Inteligente",
            keyCloudenabled: "Preparado para a cloud",
            keyPc: "PC",
            keyMobile: "Dispositivos Móveis",
            keyGetitnow: "OBTER AGORA",
            keyPreordernow: "PRÉ-ENCOMENDAR AGORA",
            keyScreenshot: "captura de ecrã",
            keyCloud: "CLOUD",
        },
        "ru-ru": {
            keyAddtowishlist: "Добавить в список желаний",
            keyOptimizedforxboxseriesxs: "Оптимизировано для Xbox Series X|S",
            keySmartdelivery: "Smart Delivery",
            keyCloudenabled: "Поддержка облачного сервиса",
            keyPc: "ПК",
            keyMobile: "Мобильное устройство",
            keyGetitnow: "ПОЛУЧИТЬ СЕЙЧАС",
            keyPreordernow: "ОФОРМИТЬ ПРЕДЗАКАЗ",
            keyScreenshot: "снимок экрана",
            keyCloud: "ОБЛАКО",
        },
        "sk-sk": {
            keyAddtowishlist: "Pridať do zoznamu prianí",
            keyOptimizedforxboxseriesxs: "Optimalizované pre Xbox Series X|S",
            keySmartdelivery: "Inteligentné doručenie",
            keyCloudenabled: "Cloudové hranie",
            keyPc: "PC",
            keyMobile: "Mobilné zariadenie",
            keyGetitnow: "ZÍSKAJTE JU EŠTE DNES",
            keyPreordernow: "PREDOBJEDNAŤ",
            keyScreenshot: "snímka obrazovky",
            keyCloud: "CLOUD",
        },
        "sv-se": {
            keyAddtowishlist: "Lägg till i önskelista",
            keyOptimizedforxboxseriesxs: "Optimerad för Xbox Series X|S",
            keySmartdelivery: "Smart Delivery",
            keyCloudenabled: "Molnaktiverat",
            keyPc: "PC",
            keyMobile: "Mobil",
            keyGetitnow: "SKAFFA DET I DAG",
            keyPreordernow: "FÖRBESTÄLL NU",
            keyScreenshot: "skärmbild",
            keyCloud: "MOLN",
        },
        "tr-tr": {
            keyAddtowishlist: "İstek listenize ekleyin",
            keyOptimizedforxboxseriesxs: "Xbox Series X|S için Optimize Edildi",
            keySmartdelivery: "Akıllı Teslimat",
            keyCloudenabled: "Bulut özellikli",
            keyPc: "BİLGİSAYAR",
            keyMobile: "Mobil",
            keyGetitnow: "ŞİMDİ EDİNİN",
            keyPreordernow: "ŞİMDİ ÖN SİPARİŞ VERİN",
            keyScreenshot: "ekran görüntüsü",
            keyCloud: "BULUT",
        },
        "zh-hk": {
            keyAddtowishlist: "新增至願望清單",
            keyOptimizedforxboxseriesxs: "Xbox Series X|S 性能最佳化",
            keySmartdelivery: "智慧分發",
            keyCloudenabled: "具有雲端功能",
            keyPc: "電腦",
            keyMobile: "行動裝置",
            keyGetitnow: "立即購買",
            keyPreordernow: "立即預購",
            keyScreenshot: "畫面截圖",
            keyCloud: "雲端",
        },
        "zh-tw": {
            keyAddtowishlist: "加入願望清單",
            keyOptimizedforxboxseriesxs: "Xbox Series X|S 性能強化",
            keySmartdelivery: "智慧分發",
            keyCloudenabled: "具有雲端功能",
            keyPc: "PC",
            keyMobile: "Mobile",
            keyGetitnow: "馬上購買",
            keyPreordernow: "立即預購",
            keyScreenshot: "螢幕擷取畫面",
            keyCloud: "雲端",
        },
    },
};
boxshotlocstrings = {
    locales: {
        "en-us": {
            keyPlaceholderboxshot: "box shot of <PLACEHOLDER>",
        },
        "en-ca": {
            keyPlaceholderboxshot: "box shot of <PLACEHOLDER>",
        },
        "de-at": {
            keyPlaceholderboxshot: "<PLACEHOLDER> – Verpackung",
        },
        "tr-tr": {
            keyPlaceholderboxshot: "<PLACEHOLDER> kutu resmi",
        },
        "en-nz": {
            keyPlaceholderboxshot: "<PLACEHOLDER> boxshot",
        },
        "de-de": {
            keyPlaceholderboxshot: "<PLACEHOLDER> – Verpackung",
        },
        "el-gr": {
            keyPlaceholderboxshot: "<PLACEHOLDER> boxshot",
        },
        "nl-nl": {
            keyPlaceholderboxshot: "<PLACEHOLDER> - boxshot",
        },
        "en-za": {
            keyPlaceholderboxshot: "<PLACEHOLDER> boxshot",
        },
        "en-sg": {
            keyPlaceholderboxshot: "<PLACEHOLDER> boxshot",
        },
        "en-gb": {
            keyPlaceholderboxshot: "<PLACEHOLDER> boxshot",
        },
        "es-ar": {
            keyPlaceholderboxshot: "Imagen de la caja de <PLACEHOLDER>",
        },
        "es-mx": {
            keyPlaceholderboxshot: "Imagen de la caja de <PLACEHOLDER>",
        },
        "en-au": {
            keyPlaceholderboxshot: "<PLACEHOLDER> boxshot",
        },
        "nb-no": {
            keyPlaceholderboxshot: "<PLACEHOLDER> coverbilde",
        },
        "ar-ae": {
            keyPlaceholderboxshot: "<PLACEHOLDER> boxshot",
        },
        "ar-sa": {
            keyPlaceholderboxshot: "<PLACEHOLDER> boxshot",
        },
        "de-ch": {
            keyPlaceholderboxshot: "<PLACEHOLDER> – Verpackung",
        },
        "ja-jp": {
            keyPlaceholderboxshot: "<PLACEHOLDER> パッケージショット",
        },
        "ko-kr": {
            keyPlaceholderboxshot: "<PLACEHOLDER> 박스샷",
        },
        "fr-ca": {
            keyPlaceholderboxshot: "Image de la boîte de <PLACEHOLDER>",
        },
        "he-il": {
            keyPlaceholderboxshot: "<PLACEHOLDER> boxshot",
        },
        "fi-fi": {
            keyPlaceholderboxshot: "Pakkauksen kansi: <PLACEHOLDER>",
        },
        "pt-br": {
            keyPlaceholderboxshot: "<PLACEHOLDER> imagem da caixa",
        },
        "zh-hk": {
            keyPlaceholderboxshot: "<PLACEHOLDER> 包裝圖",
        },
        "zh-tw": {
            keyPlaceholderboxshot: "<PLACEHOLDER> 包裝圖",
        },
        "ru-ru": {
            keyPlaceholderboxshot: "<PLACEHOLDER> — обложка",
        },
        "da-dk": {
            keyPlaceholderboxshot: "<PLACEHOLDER> billede af æsken",
        },
        "cs-cz": {
            keyPlaceholderboxshot: "Obrázek krabice <PLACEHOLDER>",
        },
        "es-cl": {
            keyPlaceholderboxshot: "Imagen de la caja de <PLACEHOLDER>",
        },
        "zh-cn": {
            keyPlaceholderboxshot: "<PLACEHOLDER> 包装盒",
        },
        "sv-se": {
            keyPlaceholderboxshot: "<PLACEHOLDER> bild på förpackning",
        },
        "en-ie": {
            keyPlaceholderboxshot: "<PLACEHOLDER> boxshot",
        },
        "it-it": {
            keyPlaceholderboxshot: "Immagine della confezione di <PLACEHOLDER>",
        },
        "es-es": {
            keyPlaceholderboxshot: "Imagen de la caja de <PLACEHOLDER>",
        },
        "fr-fr": {
            keyPlaceholderboxshot: "<PLACEHOLDER> image de la boîte",
        },
        "fr-be": {
            keyPlaceholderboxshot: "<PLACEHOLDER> image de la boîte",
        },
        "es-co": {
            keyPlaceholderboxshot: "Imagen de la caja de <PLACEHOLDER>",
        },
        "en-hk": {
            keyPlaceholderboxshot: "<PLACEHOLDER> boxshot",
        },
        "fr-ch": {
            keyPlaceholderboxshot: "<PLACEHOLDER> image de la boîte",
        },
        "pl-pl": {
            keyPlaceholderboxshot: "<PLACEHOLDER> – zdjęcie opakowania",
        },
        "hu-hu": {
            keyPlaceholderboxshot: "<PLACEHOLDER> dobozának képe",
        },
        "en-in": {
            keyPlaceholderboxshot: "<PLACEHOLDER> boxshot",
        },
        "nl-be": {
            keyPlaceholderboxshot: "<PLACEHOLDER> - boxshot",
        },
        "pt-pt": {
            keyPlaceholderboxshot: "Imagem da caixa de <PLACEHOLDER>",
        },
        "sk-sk": {
            keyPlaceholderboxshot: "<PLACEHOLDER> – obrázok balenia",
        },
    },
};

var gpstrings = {
    "locales": {
        "en-us": {
            "keyIncluded": "Included with <<PLACEHOLDERGPLOGO>>",
            "keyWith": "<<PLACEHOLDERPRICE>> with <<PLACEHOLDERGPLOGO>>"
        },
        "ar-ae": {
            "keyIncluded": "Included with <<PLACEHOLDERGPLOGO>>",
            "keyWith": "<<PLACEHOLDERPRICE>> with <<PLACEHOLDERGPLOGO>>"
        },
        "ar-sa": {
            "keyIncluded": "Included with <<PLACEHOLDERGPLOGO>>",
            "keyWith": "<<PLACEHOLDERPRICE>> with <<PLACEHOLDERGPLOGO>>"
        },
        "en-ae": {
            "keyIncluded": "Included with <<PLACEHOLDERGPLOGO>>",
            "keyWith": "<<PLACEHOLDERPRICE>> with <<PLACEHOLDERGPLOGO>>"
        },
        "en-sa": {
            "keyIncluded": "Included with <<PLACEHOLDERGPLOGO>>",
            "keyWith": "<<PLACEHOLDERPRICE>> with <<PLACEHOLDERGPLOGO>>"
        },
        "cs-cz": {
            "keyIncluded": "Se zahrnutím <<PLACEHOLDERGPLOGO>>",
            "keyWith": "<<PLACEHOLDERPRICE>> s <<PLACEHOLDERGPLOGO>>"
        },
        "da-dk": {
            "keyIncluded": "Inkluderet med <<PLACEHOLDERGPLOGO>>",
            "keyWith": "<<PLACEHOLDERPRICE>> med <<PLACEHOLDERGPLOGO>>"
        },
        "de-at": {
            "keyIncluded": "Enthalten in <<PLACEHOLDERGPLOGO>>",
            "keyWith": "<<PLACEHOLDERPRICE>> mit <<PLACEHOLDERGPLOGO>>"
        },
        "de-ch": {
            "keyIncluded": "Enthalten in <<PLACEHOLDERGPLOGO>>",
            "keyWith": "<<PLACEHOLDERPRICE>> mit <<PLACEHOLDERGPLOGO>>"
        },
        "de-de": {
            "keyIncluded": "Enthalten in <<PLACEHOLDERGPLOGO>>",
            "keyWith": "<<PLACEHOLDERPRICE>> mit <<PLACEHOLDERGPLOGO>>"
        },
        "el-gr": {
            "keyIncluded": "Περιλαμβάνεται με το <<PLACEHOLDERGPLOGO>>",
            "keyWith": "<<PLACEHOLDERPRICE>> με <<PLACEHOLDERGPLOGO>>"
        },
        "en-au": {
            "keyIncluded": "Included with <<PLACEHOLDERGPLOGO>>",
            "keyWith": "<<PLACEHOLDERPRICE>> with <<PLACEHOLDERGPLOGO>>"
        },
        "en-ca": {
            "keyIncluded": "Included with <<PLACEHOLDERGPLOGO>>",
            "keyWith": "<<PLACEHOLDERPRICE>> with <<PLACEHOLDERGPLOGO>>"
        },
        "en-gb": {
            "keyIncluded": "Included with <<PLACEHOLDERGPLOGO>>",
            "keyWith": "<<PLACEHOLDERPRICE>> with <<PLACEHOLDERGPLOGO>>"
        },
        "en-hk": {
            "keyIncluded": "Included with <<PLACEHOLDERGPLOGO>>",
            "keyWith": "<<PLACEHOLDERPRICE>> with <<PLACEHOLDERGPLOGO>>"
        },
        "en-ie": {
            "keyIncluded": "Included with <<PLACEHOLDERGPLOGO>>",
            "keyWith": "<<PLACEHOLDERPRICE>> with <<PLACEHOLDERGPLOGO>>"
        },
        "en-in": {
            "keyIncluded": "Included with <<PLACEHOLDERGPLOGO>>",
            "keyWith": "<<PLACEHOLDERPRICE>> with <<PLACEHOLDERGPLOGO>>"
        },
        "en-nz": {
            "keyIncluded": "Included with <<PLACEHOLDERGPLOGO>>",
            "keyWith": "<<PLACEHOLDERPRICE>> with <<PLACEHOLDERGPLOGO>>"
        },
        "en-sg": {
            "keyIncluded": "Included with <<PLACEHOLDERGPLOGO>>",
            "keyWith": "<<PLACEHOLDERPRICE>> with <<PLACEHOLDERGPLOGO>>"
        },
        "en-za": {
            "keyIncluded": "Included with <<PLACEHOLDERGPLOGO>>",
            "keyWith": "<<PLACEHOLDERPRICE>> with <<PLACEHOLDERGPLOGO>>"
        },
        "es-ar": {
            "keyIncluded": "Incluido con <<PLACEHOLDERGPLOGO>>",
            "keyWith": "<<PLACEHOLDERPRICE>> con <<PLACEHOLDERGPLOGO>>"
        },
        "es-cl": {
            "keyIncluded": "Incluido con <<PLACEHOLDERGPLOGO>>",
            "keyWith": "<<PLACEHOLDERPRICE>> con <<PLACEHOLDERGPLOGO>>"
        },
        "es-co": {
            "keyIncluded": "Incluido con <<PLACEHOLDERGPLOGO>>",
            "keyWith": "<<PLACEHOLDERPRICE>> con <<PLACEHOLDERGPLOGO>>"
        },
        "es-es": {
            "keyIncluded": "Incluido con <<PLACEHOLDERGPLOGO>>",
            "keyWith": "<<PLACEHOLDERPRICE>> con <<PLACEHOLDERGPLOGO>>"
        },
        "es-mx": {
            "keyIncluded": "Incluido con <<PLACEHOLDERGPLOGO>>",
            "keyWith": "<<PLACEHOLDERPRICE>> con <<PLACEHOLDERGPLOGO>>"
        },
        "fi-fi": {
            "keyIncluded": "Sisältyy: <<PLACEHOLDERGPLOGO>>",
            "keyWith": "<<PLACEHOLDERGPLOGO>> – <<PLACEHOLDERPRICE>>"
        },
        "fr-be": {
            "keyIncluded": "Inclus avec <<PLACEHOLDERGPLOGO>>",
            "keyWith": "<<PLACEHOLDERPRICE>> avec <<PLACEHOLDERGPLOGO>>"
        },
        "fr-ca": {
            "keyIncluded": "Inclus avec <<PLACEHOLDERGPLOGO>>",
            "keyWith": "<<PLACEHOLDERPRICE>> avec <<PLACEHOLDERGPLOGO>>"
        },
        "fr-ch": {
            "keyIncluded": "Inclus avec <<PLACEHOLDERGPLOGO>>",
            "keyWith": "<<PLACEHOLDERPRICE>> avec <<PLACEHOLDERGPLOGO>>"
        },
        "fr-fr": {
            "keyIncluded": "Inclus avec <<PLACEHOLDERGPLOGO>>",
            "keyWith": "<<PLACEHOLDERPRICE>> avec <<PLACEHOLDERGPLOGO>>"
        },
        "he-il": {
            "keyIncluded": "Included with <<PLACEHOLDERGPLOGO>>",
            "keyWith": "<<PLACEHOLDERPRICE>> with <<PLACEHOLDERGPLOGO>>"
        },
        "hu-hu": {
            "keyIncluded": "Tartalmazza: <<PLACEHOLDERGPLOGO>>",
            "keyWith": "<<PLACEHOLDERPRICE>> ezzel: <<PLACEHOLDERGPLOGO>>"
        },
        "it-it": {
            "keyIncluded": "Incluso con <<PLACEHOLDERGPLOGO>>",
            "keyWith": "<<PLACEHOLDERPRICE>> con <<PLACEHOLDERGPLOGO>>"
        },
        "ja-jp": {
            "keyIncluded": "<<PLACEHOLDERGPLOGO>> に同梱",
            "keyWith": "<<PLACEHOLDERGPLOGO>> 入りの <<PLACEHOLDERPRICE>>"
        },
        "ko-kr": {
            "keyIncluded": "<<PLACEHOLDERGPLOGO>>에 포함",
            "keyWith": "<<PLACEHOLDERGPLOGO>>가 있는 <<PLACEHOLDERPRICE>>"
        },
        "nb-no": {
            "keyIncluded": "Inkludert med <<PLACEHOLDERGPLOGO>>",
            "keyWith": "<<PLACEHOLDERPRICE>> med <<PLACEHOLDERGPLOGO>>"
        },
        "nl-be": {
            "keyIncluded": "Inbegrepen bij <<PLACEHOLDERGPLOGO>>",
            "keyWith": "<<PLACEHOLDERPRICE>> met <<PLACEHOLDERGPLOGO>>"
        },
        "nl-nl": {
            "keyIncluded": "Inbegrepen bij <<PLACEHOLDERGPLOGO>>",
            "keyWith": "<<PLACEHOLDERPRICE>> met <<PLACEHOLDERGPLOGO>>"
        },
        "pl-pl": {
            "keyIncluded": "W zestawie z <<PLACEHOLDERGPLOGO>>",
            "keyWith": "<<PLACEHOLDERPRICE>> z <<PLACEHOLDERGPLOGO>>"
        },
        "pt-br": {
            "keyIncluded": "Incluído com <<PLACEHOLDERGPLOGO>>",
            "keyWith": "<<PLACEHOLDERPRICE>> com <<PLACEHOLDERGPLOGO>>"
        },
        "pt-pt": {
            "keyIncluded": "Incluído com <<PLACEHOLDERGPLOGO>>",
            "keyWith": "<<PLACEHOLDERPRICE>> com <<PLACEHOLDERGPLOGO>>"
        },
        "ru-ru": {
            "keyIncluded": "Включено в <<PLACEHOLDERGPLOGO>>",
            "keyWith": "<<PLACEHOLDERPRICE>> с <<PLACEHOLDERGPLOGO>>"
        },
        "sk-sk": {
            "keyIncluded": "Zahrnuté v <<PLACEHOLDERGPLOGO>>",
            "keyWith": "<<PLACEHOLDERPRICE>> s <<PLACEHOLDERGPLOGO>>"
        },
        "sv-se": {
            "keyIncluded": "Ingår med <<PLACEHOLDERGPLOGO>>",
            "keyWith": "<<PLACEHOLDERPRICE>> med <<PLACEHOLDERGPLOGO>>"
        },
        "tr-tr": {
            "keyIncluded": "<<PLACEHOLDERGPLOGO>> içerisinde yer alır",
            "keyWith": "<<PLACEHOLDERGPLOGO>> ile birlikte <<PLACEHOLDERPRICE>>"
        },
        "zh-hk": {
            "keyIncluded": "隨附於 <<PLACEHOLDERGPLOGO>>",
            "keyWith": "<<PLACEHOLDERGPLOGO>> 為 <<PLACEHOLDERPRICE>>"
        },
        "zh-tw": {
            "keyIncluded": "包含在 <<PLACEHOLDERGPLOGO>>",
            "keyWith": "<<PLACEHOLDERPRICE>> 與 <<PLACEHOLDERGPLOGO>>"
        }
    }
}

var oldnewpricestrings = {
    "locales": {
        "en-us": {
            "keyOldprice": "Old price was <<PLACEHOLDERPRICE>>",
            "keyNewprice": "New price is <<PLACEHOLDERPRICE>>"
        }
    }
}

var gamepasspricestrings = {
    "locales": {
        "en-us": {
            "keyOldprice": "Non Game Pass price is <<PLACEHOLDERPRICE>>",
            "keyNewprice": "Game Pass price is <<PLACEHOLDERPRICE>>"
        },
        "ar-ae": {
            "keyOldprice": "Non Game Pass price is <<PLACEHOLDERPRICE>>",
            "keyNewprice": "Game Pass price is <<PLACEHOLDERPRICE>>"
        },
        "ar-sa": {
            "keyOldprice": "Non Game Pass price is <<PLACEHOLDERPRICE>>",
            "keyNewprice": "Game Pass price is <<PLACEHOLDERPRICE>>"
        },
        "en-ae": {
            "keyOldprice": "Non Game Pass price is <<PLACEHOLDERPRICE>>",
            "keyNewprice": "Game Pass price is <<PLACEHOLDERPRICE>>"
        },
        "en-sa": {
            "keyOldprice": "Non Game Pass price is <<PLACEHOLDERPRICE>>",
            "keyNewprice": "Game Pass price is <<PLACEHOLDERPRICE>>"
        },
        "cs-cz": {
            "keyOldprice": "Cena zahrnující Game Pass činí <<PLACEHOLDERPRICE>>",
            "keyNewprice": "Cena nezahrnující Game Pass činí <<PLACEHOLDERPRICE>>"
        },
        "da-dk": {
            "keyOldprice": "Prisen uden Game Pass er <<PLACEHOLDERPRICE>>",
            "keyNewprice": "Prisen med Game Pass er <<PLACEHOLDERPRICE>>"
        },
        "de-at": {
            "keyOldprice": "Der Preis ohne Game Pass beträgt <<PLACEHOLDERPRICE>>",
            "keyNewprice": "Der Preis mit Game Pass beträgt <<PLACEHOLDERPRICE>>"
        },
        "de-ch": {
            "keyOldprice": "Der Preis ohne Game Pass beträgt <<PLACEHOLDERPRICE>>",
            "keyNewprice": "Der Preis mit Game Pass beträgt <<PLACEHOLDERPRICE>>"
        },
        "de-de": {
            "keyOldprice": "Der Preis ohne Game Pass beträgt <<PLACEHOLDERPRICE>>",
            "keyNewprice": "Der Preis mit Game Pass beträgt <<PLACEHOLDERPRICE>>"
        },
        "el-gr": {
            "keyOldprice": "Η τιμή χωρίς το Game Pass είναι <<PLACEHOLDERPRICE>>",
            "keyNewprice": "Η τιμή με το Game Pass είναι <<PLACEHOLDERPRICE>>"
        },
        "en-au": {
            "keyOldprice": "Non Game Pass price is <<PLACEHOLDERPRICE>>",
            "keyNewprice": "Game Pass price is <<PLACEHOLDERPRICE>>"
        },
        "en-ca": {
            "keyOldprice": "Non Game Pass price is <<PLACEHOLDERPRICE>>",
            "keyNewprice": "Game Pass price is <<PLACEHOLDERPRICE>>"
        },
        "en-gb": {
            "keyOldprice": "Non Game Pass price is <<PLACEHOLDERPRICE>>",
            "keyNewprice": "Game Pass price is <<PLACEHOLDERPRICE>>"
        },
        "en-hk": {
            "keyOldprice": "Non Game Pass price is <<PLACEHOLDERPRICE>>",
            "keyNewprice": "Game Pass price is <<PLACEHOLDERPRICE>>"
        },
        "en-ie": {
            "keyOldprice": "Non Game Pass price is <<PLACEHOLDERPRICE>>",
            "keyNewprice": "Game Pass price is <<PLACEHOLDERPRICE>>"
        },
        "en-in": {
            "keyOldprice": "Non Game Pass price is <<PLACEHOLDERPRICE>>",
            "keyNewprice": "Game Pass price is <<PLACEHOLDERPRICE>>"
        },
        "en-nz": {
            "keyOldprice": "Non Game Pass price is <<PLACEHOLDERPRICE>>",
            "keyNewprice": "Game Pass price is <<PLACEHOLDERPRICE>>"
        },
        "en-sg": {
            "keyOldprice": "Non Game Pass price is <<PLACEHOLDERPRICE>>",
            "keyNewprice": "Game Pass price is <<PLACEHOLDERPRICE>>"
        },
        "en-za": {
            "keyOldprice": "Non Game Pass price is <<PLACEHOLDERPRICE>>",
            "keyNewprice": "Game Pass price is <<PLACEHOLDERPRICE>>"
        },
        "es-ar": {
            "keyOldprice": "El precio sin Game Pass es de <<PLACEHOLDERPRICE>>",
            "keyNewprice": "El precio con Game Pass es de <<PLACEHOLDERPRICE>>"
        },
        "es-cl": {
            "keyOldprice": "El precio sin Game Pass es de <<PLACEHOLDERPRICE>>",
            "keyNewprice": "El precio con Game Pass es de <<PLACEHOLDERPRICE>>"
        },
        "es-co": {
            "keyOldprice": "El precio sin Game Pass es de <<PLACEHOLDERPRICE>>",
            "keyNewprice": "El precio con Game Pass es de <<PLACEHOLDERPRICE>>"
        },
        "es-es": {
            "keyOldprice": "El precio sin Game Pass es de <<PLACEHOLDERPRICE>>",
            "keyNewprice": "El precio con Game Pass es de <<PLACEHOLDERPRICE>>"
        },
        "es-mx": {
            "keyOldprice": "El precio sin Game Pass es de <<PLACEHOLDERPRICE>>",
            "keyNewprice": "El precio con Game Pass es de <<PLACEHOLDERPRICE>>"
        },
        "fi-fi": {
            "keyOldprice": "Ilman Game Passia hinta on <<PLACEHOLDERPRICE>>",
            "keyNewprice": "Game Passin kanssa hinta on <<PLACEHOLDERPRICE>>"
        },
        "fr-be": {
            "keyOldprice": "Le prix hors Game Pass est de <<PLACEHOLDERPRICE>>",
            "keyNewprice": "Le prix Game Pass est de <<PLACEHOLDERPRICE>>"
        },
        "fr-ca": {
            "keyOldprice": "Le prix hors Game Pass est <<PLACEHOLDERPRICE>>",
            "keyNewprice": "Le prix Game Pass est <<PLACEHOLDERPRICE>>"
        },
        "fr-ch": {
            "keyOldprice": "Le prix hors Game Pass est de <<PLACEHOLDERPRICE>>",
            "keyNewprice": "Le prix Game Pass est de <<PLACEHOLDERPRICE>>"
        },
        "fr-fr": {
            "keyOldprice": "Le prix hors Game Pass est de <<PLACEHOLDERPRICE>>",
            "keyNewprice": "Le prix Game Pass est de <<PLACEHOLDERPRICE>>"
        },
        "he-il": {
            "keyOldprice": "Non Game Pass price is <<PLACEHOLDERPRICE>>",
            "keyNewprice": "Game Pass price is <<PLACEHOLDERPRICE>>"
        },
        "hu-hu": {
            "keyOldprice": "Nem Game Pass-ár: <<PLACEHOLDERPRICE>>",
            "keyNewprice": "Game Pass-ár: <<PLACEHOLDERPRICE>>"
        },
        "it-it": {
            "keyOldprice": "Il prezzo senza Game Pass è <<PLACEHOLDERPRICE>>",
            "keyNewprice": "Il prezzo con Game Pass è <<PLACEHOLDERPRICE>>"
        },
        "ja-jp": {
            "keyOldprice": "Game Pass がない場合の価格: <<PLACEHOLDERPRICE>>",
            "keyNewprice": "Game Pass がある場合の価格 <<PLACEHOLDERPRICE>>"
        },
        "ko-kr": {
            "keyOldprice": "Game Pass 비이용자 가격: <<PLACEHOLDERPRICE>>",
            "keyNewprice": "Game Pass 이용자 가격: <<PLACEHOLDERPRICE>>"
        },
        "nb-no": {
            "keyOldprice": "Pris uten Game Pass er <<PLACEHOLDERPRICE>>",
            "keyNewprice": "Pris med Game Pass er <<PLACEHOLDERPRICE>>"
        },
        "nl-be": {
            "keyOldprice": "De prijs zonder Game Pass is <<PLACEHOLDERPRICE>>",
            "keyNewprice": "De prijs met Game Pass is <<PLACEHOLDERPRICE>>"
        },
        "nl-nl": {
            "keyOldprice": "De prijs zonder Game Pass is <<PLACEHOLDERPRICE>>",
            "keyNewprice": "De prijs met Game Pass is <<PLACEHOLDERPRICE>>"
        },
        "pl-pl": {
            "keyOldprice": "Cena bez subskrypcji Game Pass wynosi <<PLACEHOLDERPRICE>>",
            "keyNewprice": "Cena z subskrypcją Game Pass wynosi <<PLACEHOLDERPRICE>>"
        },
        "pt-br": {
            "keyOldprice": "O preço do jogo sem Game Pass é <<PLACEHOLDERPRICE>>",
            "keyNewprice": "O preço do Game Pass é <<PLACEHOLDERPRICE>>"
        },
        "pt-pt": {
            "keyOldprice": "O preço sem Game Pass é <<PLACEHOLDERPRICE>>",
            "keyNewprice": "O preço com Game Pass é <<PLACEHOLDERPRICE>>"
        },
        "ru-ru": {
            "keyOldprice": "Цена абонемента без Game Pass: <<PLACEHOLDERPRICE>>",
            "keyNewprice": "Цена абонемента Game Pass <<PLACEHOLDERPRICE>>"
        },
        "sk-sk": {
            "keyOldprice": "Cena bez predplatného Game Pass je <<PLACEHOLDERPRICE>>",
            "keyNewprice": "Cena predplatného Game Pass je <<PLACEHOLDERPRICE>>"
        },
        "sv-se": {
            "keyOldprice": "Priset utan Game Pass är <<PLACEHOLDERPRICE>>",
            "keyNewprice": "Priset med Game Pass är <<PLACEHOLDERPRICE>>"
        },
        "tr-tr": {
            "keyOldprice": "Game Pass haricindeki fiyatı <<PLACEHOLDERPRICE>>",
            "keyNewprice": "Game Pass dahilindeki fiyatı <<PLACEHOLDERPRICE>>"
        },
        "zh-hk": {
            "keyOldprice": "非 Game Pass 價格為 <<PLACEHOLDERPRICE>>",
            "keyNewprice": "Game Pass 價格為 <<PLACEHOLDERPRICE>>"
        },
        "zh-tw": {
            "keyOldprice": "非 Game Pass 的價格為 <<PLACEHOLDERPRICE>>",
            "keyNewprice": "Game Pass 的價格 <<PLACEHOLDERPRICE>>"
        }
    }
}

eaplaystrings = {
    "locales": {
        "en-us": {
            "keyWitheaplay": "via EA Play with Xbox Game Pass Ultimate"
        },
        "ar-ae": {
            "keyWitheaplay": "via EA Play with Xbox Game Pass Ultimate"
        },
        "ar-sa": {
            "keyWitheaplay": "via EA Play with Xbox Game Pass Ultimate"
        },
        "en-ae": {
            "keyWitheaplay": "via EA Play with Xbox Game Pass Ultimate"
        },
        "en-sa": {
            "keyWitheaplay": "via EA Play with Xbox Game Pass Ultimate"
        },
        "cs-cz": {
            "keyWitheaplay": "se členstvím EA Play v rámci předplatného Xbox Game Pass Ultimate"
        },
        "da-dk": {
            "keyWitheaplay": "via EA Play med Xbox Game Pass Ultimate"
        },
        "de-at": {
            "keyWitheaplay": "über EA Play mit Xbox Game Pass Ultimate"
        },
        "de-ch": {
            "keyWitheaplay": "über EA Play mit Xbox Game Pass Ultimate"
        },
        "de-de": {
            "keyWitheaplay": "über EA Play mit Xbox Game Pass Ultimate"
        },
        "el-gr": {
            "keyWitheaplay": "μέσα από το EA Play με το Xbox Game Pass Ultimate"
        },
        "en-au": {
            "keyWitheaplay": "via EA Play with Xbox Game Pass Ultimate"
        },
        "en-ca": {
            "keyWitheaplay": "via EA Play with Xbox Game Pass Ultimate"
        },
        "en-gb": {
            "keyWitheaplay": "via EA Play with Xbox Game Pass Ultimate"
        },
        "en-hk": {
            "keyWitheaplay": "via EA Play with Xbox Game Pass Ultimate"
        },
        "en-ie": {
            "keyWitheaplay": "via EA Play with Xbox Game Pass Ultimate"
        },
        "en-in": {
            "keyWitheaplay": "via EA Play with Xbox Game Pass Ultimate"
        },
        "en-nz": {
            "keyWitheaplay": "via EA Play with Xbox Game Pass Ultimate"
        },
        "en-sg": {
            "keyWitheaplay": "via EA Play with Xbox Game Pass Ultimate"
        },
        "en-za": {
            "keyWitheaplay": "via EA Play with Xbox Game Pass Ultimate"
        },
        "es-ar": {
            "keyWitheaplay": "mediante EA Play con Xbox Game Pass Ultimate"
        },
        "es-cl": {
            "keyWitheaplay": "mediante EA Play con Xbox Game Pass Ultimate"
        },
        "es-co": {
            "keyWitheaplay": "mediante EA Play con Xbox Game Pass Ultimate"
        },
        "es-es": {
            "keyWitheaplay": "mediante EA Play con Xbox Game Pass Ultimate"
        },
        "es-mx": {
            "keyWitheaplay": "mediante EA Play con Xbox Game Pass Ultimate"
        },
        "fi-fi": {
            "keyWitheaplay": "Xbox Game Pass Ultimateen kuuluvalla EA Playlla"
        },
        "fr-be": {
            "keyWitheaplay": "via EA Play avec le Xbox Game Pass Ultimate"
        },
        "fr-ca": {
            "keyWitheaplay": "via EA Jouez avec Xbox Game Pass Ultimate"
        },
        "fr-ch": {
            "keyWitheaplay": "via EA Play avec le Xbox Game Pass Ultimate"
        },
        "fr-fr": {
            "keyWitheaplay": "via EA Play avec le Xbox Game Pass Ultimate"
        },
        "he-il": {
            "keyWitheaplay": "via EA Play with Xbox Game Pass Ultimate"
        },
        "hu-hu": {
            "keyWitheaplay": "EA Playjel Xbox Game Pass Ultimate előfizetéssel"
        },
        "it-it": {
            "keyWitheaplay": "tramite EA Play con Xbox Game Pass Ultimate"
        },
        "ja-jp": {
            "keyWitheaplay": "EA Xbox Game Pass Ultimate で EA Play から"
        },
        "ko-kr": {
            "keyWitheaplay": "EA Play에서 Xbox Game Pass 얼티밋으로 플레이"
        },
        "nb-no": {
            "keyWitheaplay": "via EA Play med Xbox Game Pass Ultimate"
        },
        "nl-be": {
            "keyWitheaplay": "via EA Play met Xbox Game Pass Ultimate"
        },
        "nl-nl": {
            "keyWitheaplay": "via EA Play met Xbox Game Pass Ultimate"
        },
        "pl-pl": {
            "keyWitheaplay": "za pośrednictwem EA Play w ramach subskrypcji Xbox Game Pass Ultimate"
        },
        "pt-br": {
            "keyWitheaplay": "por meio do EA Play com o Xbox Game Pass Ultimate"
        },
        "pt-pt": {
            "keyWitheaplay": "através do EA Play com o Xbox Game Pass Ultimate"
        },
        "ru-ru": {
            "keyWitheaplay": "через EA Play с Xbox Game Pass Ultimate"
        },
        "sk-sk": {
            "keyWitheaplay": "prostredníctvom EA Play s predplatným Xbox Game Pass Ultimate"
        },
        "sv-se": {
            "keyWitheaplay": "via EA Play med Xbox Game Pass Ultimate"
        },
        "tr-tr": {
            "keyWitheaplay": "Xbox Game Pass Ultimate ile EA Play üzerinden"
        },
        "zh-hk": {
            "keyWitheaplay": "使用 Xbox Game Pass Ultimate 透過 EA Play"
        },
        "zh-tw": {
            "keyWitheaplay": "透過 EA Play 使用 Xbox Game Pass Ultimate 暢玩"
        }
    }
}
