$(document).ready(function() { // needs to be in one of these because page targets won't exist when script loads

    $(".CTAdiv button[data-cta-href]").attr("role", "link");

    var pageBar = $(".c-in-page-navigation").first();
    var pageBarAria = $(pageBar).attr("aria-label");
    var resizeTimer;
    $(window).on('load resize', function() {
        clearTimeout(resizeTimer);
        resizeTimer = setTimeout(function() {
            if ((window.innerWidth < 1084) && ($(pageBar).attr("aria-label") !== "")) {
                $(pageBar).attr("aria-label", "");
            } else if ((window.innerWidth >= 1084) && ($(pageBar).attr("aria-label") === "")) {
                $(pageBar).attr("aria-label", pageBarAria);
            }
        }, 250);
    });

    // fixes MWF glitch
    if ($(".c-navigation-menu").length) {
        $(document).on("click", ".c-navigation-menu li a, .c-navigation-menu .c-menu span", function() {
            $(".c-navigation-menu > button").attr("aria-expanded", "false");
        });
    }

    // make off-page links into buttons to remove them from the MWF highlighting script
    //$(".m-in-page-navigation button").each(function() {
    $(document).on("click", ".m-in-page-navigation button", function() {
        if ($(this).attr("data-cta-href") !== undefined) {
            if ($(this).attr('data-target') === "_blank") {
                window.open($(this).attr("data-cta-href"));
            } else {
                window.location.href = $(this).attr("data-cta-href");
            }
        }
    });

    // BEGIN make dropdown navigable at up to 400% zoom

    // the open dropdown will close when pagebar becomes affixed to the top of the window.
    // this scrolls to that point when the dropdown is focused but not clicked < 480px
    var clicked = "false";

    // focus is also reported when clicked
    // but mousedown registers before focus; click registers after focus
    // event.which == 0 identifies user interaction. "undefined" is when focus is triggered by JS.
    $(".c-navigation-menu button").on("mousedown focus", function(event) {
        if (event.type == "mousedown") {
            clicked = "true";
        } else if ((event.type == "focus") && (event.which == 0) && (clicked == "false") && ($(window).width() < 480) && !$(".c-in-page-navigation").hasClass("f-sticky")) {
            navTarget = $(".c-in-page-navigation").offset().top + 48;
            $('html').scrollTop(navTarget);
        }
        setTimeout(function() {
            clicked = "false";
        }, 150);

    });
    // END make dropdown navigable at up to 400% zoom


    // BEGIN close dropdown when user navigates out of it.
    // must work for any combination of <button> and <a>
    $(".c-navigation-menu > ul > li *").on("blur", function(e) {
        //theParent = $(".c-navigation-menu ul");
        setTimeout(function() { // delayed because focus moves to BODY before finding next element
            var theFocused = document.activeElement;
            if (theFocused.closest(".c-navigation-menu ul") == null) {
                //$(".c-navigation-menu").find("button[class^='c-heading']").focus();
                $(".c-navigation-menu ul").attr("aria-hidden", "true");
            }
        }, 20);

    });

    // END close dropdown when user navigates out of it.

});