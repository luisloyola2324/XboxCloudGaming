$(document).ready(function() {

  var urlRegion = document.URL.split("/")[3].toLowerCase();
  var regionContent = stringContent.locales[urlRegion];

  let saleOne = globalContent.locales[urlRegion].keySaleonebigids.split(",");
  let saleTwo = globalContent.locales[urlRegion].keySaletwobigids.split(",");
  let saleThree = globalContent.locales[urlRegion].keySalethreebigids.split(",");
  let saleFour = globalContent.locales[urlRegion].keySalefourbigids.split(",");
  let saleFive = globalContent.locales[urlRegion].keySalefivebigids.split(",");

  if (saleTwo[0] === "") {
      saleTwo = "";
  }

  if (saleThree[0] === "") {
      saleThree = "";
  }

  if (saleFour[0] === "") {
      saleFour = "";
  }

  if (saleFive[0] === "") {
      saleFive = "";
  }

  var allSaleGuids;

if (saleOne[0] === "") {
allSaleGuids = "";
} else if (saleTwo === "") {
allSaleGuids = saleOne;
} else if (saleTwo !== "" && saleThree === "") {
allSaleGuids = saleOne.concat(saleTwo);
} else if (saleThree !== "" && saleFour === "") {
allSaleGuids = saleOne.concat(saleTwo, saleThree);
} else if (saleFour !== "" && saleFive === "") {
allSaleGuids = saleOne.concat(saleTwo, saleThree, saleFour);
} else {
allSaleGuids = saleOne.concat(saleTwo, saleThree, saleFour, saleFive);
}

if (allSaleGuids !== "") {
  GUID_pop(allSaleGuids);
}
  

  function GUID_pop(rawGuids) {
      // chunktotal = Math.ceil((saleOne.length + saleTwo.length + saleThree.length +  saleFour.length  + saleFive.length) / 35);
      const countryCode = urlRegion.split("-")[1].toUpperCase();
      var guidUrl = 'https://displaycatalog.mp.microsoft.com/v7.0/products?bigIds=GAMEIDS&market=' + countryCode + '&languages=' + urlRegion + '&MS-CV=DGU1mcuYo0WMMp+F.1';

      guidUrl = guidUrl.replace("GAMEIDS", rawGuids);

      $.get(guidUrl)
          .done(function(responseData) {
          var apiData = responseData;
          makeallGamesData(apiData, 0);
      });
  };
    
  function makeallGamesData(data, count) {
      // Xbox PDD's (If Needed)
      // var bigidUrls = biUrls.items.urls;
      // var biuArray = Object.keys(bigidUrls);

      var productQuantity = data.Products.length;

      for (var x = 0; x < productQuantity; x++) {
          // Item Id/Title
          var itemId = data.Products[x].ProductId.toUpperCase();
          var itemTitle = data.Products[x].LocalizedProperties[0].ProductTitle;
          if (itemTitle === undefined) {
              itemTitle = "";
          };
          var itemUrlName = itemTitle.toLowerCase().replace(/\s/g, "-").replace(/[^a-z0-9-]/gi, "");
          if (itemUrlName === "") {
              itemUrlName = "-"
          };

          var shortDesc = data.Products[x].LocalizedProperties[0].ShortDescription;
          if (shortDesc === "") {
              shortDesc = data.Products[x].LocalizedProperties[0].ProductDescription;
          };
          if (shortDesc === undefined) {
              shortDesc = "";
          };

          var imagesNum = data.Products[x].LocalizedProperties[0].Images.length;
          var imgEnd = 999;

          for (var j = 0; j < imagesNum; j++) {
              if (data.Products[x].LocalizedProperties[0].Images[j].ImagePurpose === "Poster") {
                  imgEnd = j;
                  break;
              };
          };

          if (imgEnd === 999) {
              for (var j = 0; j < imagesNum; j++) {
                  if (data.Products[x].LocalizedProperties[0].Images[j].Width < data.Products[x].LocalizedProperties[0].Images[j].Height) {
                      imgEnd = j;
                      break
                  };
              };
          };

          if (imgEnd === 999) {
              imgEnd = 1;
          };

          // Grabbing Image Path
          if (data.Products[x].LocalizedProperties[0].Images[imgEnd]) {
              var itemBoxshot = data.Products[x].LocalizedProperties[0].Images[imgEnd].Uri.replace("http:", "https:");
              var itemBoxshotSmall;
          } else {
              var itemBoxshot = "https://assets.xboxservices.com/assets/d4/da/d4da80b7-2e08-425c-adb3-e279c152adec.jpg?n=X1-Standard-digital-boxshot_584x800.jpg";
              var itemBoxshotSmall = "https://assets.xboxservices.com/assets/d4/da/d4da80b7-2e08-425c-adb3-e279c152adec.jpg?n=X1-Standard-digital-boxshot_584x800.jpg";
          }
          if (itemBoxshot.indexOf("store-images") !== -1) {
              itemBoxshotSmall = itemBoxshot + "?w=140";
              // itemBoxshot = itemBoxshot + "&h=300&w=200&format=jpg";
              itemBoxshot = itemBoxshot + "?w=280";
          } else {
              itemBoxshotSmall = itemBoxshot;
          }

          // get prices
          var listprice;
          var msrpprice;
          var currencycode;
          var onsale = "false";
          var silversaleperc;
          var goldandsilversale;
          var purchasable = "false";
          var tempea = "false"
          var tempgs = "false";

          data.Products[x].DisplaySkuAvailabilities.forEach(function(sku) {
              var purchnum = 0;
              sku.Availabilities.forEach(function(av, ind) {
                if (av.Actions.indexOf("Purchase") !== -1) {
                  purchasable = "true";
                  purchnum++;
                  if (purchnum > 1 && tempgs === "true" && av.RemediationRequired === true && goldaffids.indexOf(av.Remediations[0].BigId) !== -1) {
                    goldandsilversale = "true";
                  }
                }
                if (av.Actions.indexOf("Purchase") !== -1 && (av.OrderManagementData.Price.MSRP !== 0 || (av.OrderManagementData.Price.MSRP === 0 && av.OrderManagementData.Price.ListPrice === 0)) && 
                    sku.Sku.Properties.IsTrial === false) {
                  if ((av.OrderManagementData.Price.ListPrice !== av.OrderManagementData.Price.MSRP || (av.OrderManagementData.Price.MSRP === 0 && av.OrderManagementData.Price.ListPrice === 0)) && ind !== 0) {
                    specialprice = av.OrderManagementData.Price.ListPrice;
                  } else {
                    listprice = av.OrderManagementData.Price.ListPrice;
                  }
                  if (ind === 0) {
                    msrpprice = av.OrderManagementData.Price.MSRP;
                  }
                  currencycode = av.OrderManagementData.Price.CurrencyCode;
                  if (av.Properties.MerchandisingTags !== undefined) {
                    if (av.Properties.MerchandisingTags.indexOf("LegacyGamesWithGold") !== -1) {
                      gwg = "true";
                      specialprice = listprice;
                      listprice = msrpprice;
                    }
                    if (av.Properties.MerchandisingTags.indexOf("LegacyDiscountGold") !== -1) {
                      golddiscount = "true";
  
                    }
                  }
                  if (goldandsilversale === "true" && av.DisplayRank === 1) {
                    goldandsilversalegoldprice = av.OrderManagementData.Price.ListPrice;
                  }
                  if (tempea === "true" && av.Actions.length === 2) {
                    eaaccessgame = "true";
                  }
                  if (listprice < msrpprice) { 
                    onsale = "true";
                  }
                }

                  if (listprice < msrpprice) { 
                      onsale = "true";
                      var listdiff = msrpprice - listprice;
                      silversaleperc = Math.round(listdiff / msrpprice * 100).toString() + "%";
                  }
              });
          });

          if (listprice === undefined) {
              console.log("NOTE: BigID " + itemId + " has no price information in publisher sales.");
              listprice = 100000000;
              msrpprice = 100000000;
              currencycode = "USD";
          }

          // URL
          var itemhref = 'https://www.xbox.com/' + urlRegion + '/games/store/' + itemUrlName + '/' + itemId;

          if (urlRegion !== "ar-sa" && urlRegion !== "ar-ae") {
              var msrpshown = msrpprice.toLocaleString(urlRegion, { style: 'currency', currency: currencycode });
              var listshown = listprice.toLocaleString(urlRegion, { style: 'currency', currency: currencycode });
          } else {
              if (urlRegion === "ar-sa") {
                  currregion = "en-us";
              } else {
                  currregion = "en-ca";
              }
              var msrpshown = msrpprice.toLocaleString(currregion, { style: 'currency', currency: currencycode });
              var listshown = listprice.toLocaleString(currregion, { style: 'currency', currency: currencycode });
          }

          if (listprice !== 100000000) {
              if (listprice !== msrpprice) {
                  var badge = '<span class="c-badge f-small f-highlight">' + "−" + silversaleperc + '</span>'

                  var priceshown = '<div class="c-price" itemprop="offers" itemscope="" itemtype="http://schema.org/Offer">' +
                  '<s><span class="x-screen-reader">' + regionContent["keyFullprice"] + '</span> ' + msrpshown + '</s>' +
                  '<meta itemprop="priceCurrency" content="' + currencycode + '">' +
                  '<span class="x-screen-reader">' + "New Price" + '</span>' + '<span class="textpricenew x-hidden-focus" itemprop="price" style="margin-left: 5px;">' + listshown + '</span>' +
                  '</div>';
              } else {
                  var badge = '';
                  var priceshown = '<div class="c-price" itemprop="offers" itemscope="" itemtype="http://schema.org/Offer">' +
                  '<meta itemprop="priceCurrency" content="' + currencycode + '">' +
                  '<span class="textpricenew x-hidden-focus" itemprop="price"><span class="x-screen-reader">' + regionContent["keyNewprice"] + '</span> ' + listshown + '</span>' +
                  '</div>';
              }
          } else {
              var badge = '';
              var priceshown = '';
          }

          allGamesData[itemId] = {
              onsale: onsale,
              purchasable: purchasable,
              itemhref: itemhref,
              boxshot: itemBoxshot,
              title: itemTitle,
              msrpshown: msrpshown,
              listshown: listshown,
              badge: badge,
              priceshown: priceshown
          };

          if (x === (productQuantity - 1)) {
              var activecheck = setInterval(function() {
                  var activeAjax = $.active;
                  if (activeAjax === 0) {
                      ajaxdone();
                      clearInterval(activecheck);
                  };
              }, 500);

              function ajaxdone() {
                  populate(saleOne, ".saleOne");
                  populate(saleTwo, ".saleTwo");
                  populate(saleThree, ".saleThree");
   populate(saleFour, ".saleFour");
   populate(saleFive, ".saleFive");
              };
          };
      };

      function populate(array, container) {
          $(".featured-games").find(".spinnerHold").remove();
          for (let i = 0; i < array.length; i++) {
              if (allGamesData[array[i]].purchasable === "true" && allGamesData[array[i]].onsale === "true") {

                  $(container + " ul").append('<li class="slide">' +
                  '<section class="m-product-placement-item f-size-large context-device f-clean" data-title="' + allGamesData[array[i]].title + '">' +
                  '<a target="blank" href="' + allGamesData[array[i]].itemhref + '" data-retailer="MS Store">' +
                  '<picture>' +
                  '<source srcset="' + allGamesData[array[i]].boxshot + '" media="(min-width:0)">' +
                  '<img class="c-image" srcset="' + allGamesData[array[i]].boxshot + '" src="' + allGamesData[array[i]].boxshot + '" ' +
                  'alt="' + allGamesData[array[i]].title + ' box art">' +
                  '</picture>' +
                  '<div>' +
                  allGamesData[array[i]].badge + '<br>' +
                  '<h3 class="c-heading zpt">' + allGamesData[array[i]].title + '</h3>' +
                  allGamesData[array[i]].priceshown +
                  '</div>' +
                  '</a>' +
                  '</section>' +
                  '</li>')
                  }
          };

          // $(".saleOne").closest(".featured-games").fadeIn("slow");
          // $(".saleTwo").closest(".featured-games").fadeIn("slow");
          // $(".saleThree").closest(".featured-games").fadeIn("slow");

      };
  };

  // Disclaimer
  if (urlRegion === "fr-fr") {
      $(".rotator-heading h3").each(function(i) {
          $(this).after('<span class="disclosureContainer">' +
              '<button class="glyph-prepend glyph-prepend-info" title="disclosure button" type="button" aria-describedby="frDisclosure' + i + '"></button>' +
              '<div class="c-flyout f-beak frDisclosure" id="frDisclosure' + i + '" role="tooltip" data-js-flyout-placement="top" data-js-flyout-dismissible="true" aria-hidden="true">' +
                  '<button role="none" tabindex="0" class="disclosureClose" aria-label="bouton de fermeture pour l\'info-bulle">' +
                  '<img src="https://assets.xboxservices.com/assets/3b/df/3bdfab2d-d1b1-4019-9bac-d953db4fd7fb.svg?n=Games-Catalog_Image-0_X-Button_230x120.svg" alt="bouton de fermeture">' +
              '</button>' +
                  '<p class="c-paragraph">Voir <a href="https://www.microsoft.com/fr-fr/store/b/imprint" target="_blank">mentions légales et informations consommateurs</a> pour ' +
                  'plus d\'informations sur les critères de classement.</p>' +
              '</div>' +
              '</span>');
      });

      $(".disclosureContainer .glyph-prepend").click(function() {
          const butInd = $(this).index(".glyph-prepend");
          
          setTimeout(function() {
              if ($(".frDisclosure").css("display") !== 'none') {
                  if ($(".CatAnnounce").text() === "l'info-bulle s'est ouverte") {
                      $(".CatAnnounce").text("l'info-bulle s'est ouverte.");
                  } else {
                      $(".CatAnnounce").text("l'info-bulle s'est ouverte");
                  }
              } else {  
                  $(".CatAnnounce").text("l'info-bulle s'est fermée");
              }
                  $(".disclosureClose")[butInd].focus()
          }, 30);
      });

      $(".disclosureClose").click(function() {
          $(this).closest(".c-flyout").prev("button").click();
      });
  };

});

stringContent ={
"locales": {
  "en-us": {
    "keyFullprice": "Full price was",
    "keyNewprice": "New price is"
  },
  "ar-ae": {
    "keyFullprice": "Full price was",
    "keyNewprice": "New price is"
  },
  "ar-sa": {
    "keyFullprice": "Full price was",
    "keyNewprice": "New price is"
  },
  "cs-cz": {
    "keyFullprice": "Plná cena byla",
    "keyNewprice": "Nová cena je"
  },
  "da-dk": {
    "keyFullprice": "Fuld pris var",
    "keyNewprice": "Den nye pris er"
  },
  "de-at": {
    "keyFullprice": "Der volle Preis betrug",
    "keyNewprice": "Neuer Preis:"
  },
  "de-ch": {
    "keyFullprice": "Der volle Preis betrug",
    "keyNewprice": "Neuer Preis:"
  },
  "de-de": {
    "keyFullprice": "Der volle Preis betrug",
    "keyNewprice": "Neuer Preis:"
  },
  "el-gr": {
    "keyFullprice": "Προηγούμενη τιμή:",
    "keyNewprice": "Η νέα τιμή είναι"
  },
  "en-au": {
    "keyFullprice": "Full price was",
    "keyNewprice": "New price is"
  },
  "en-ca": {
    "keyFullprice": "Full price was",
    "keyNewprice": "New price is"
  },
  "en-gb": {
    "keyFullprice": "Full price was",
    "keyNewprice": "New price is"
  },
  "en-hk": {
    "keyFullprice": "Full price was",
    "keyNewprice": "New price is"
  },
  "en-ie": {
    "keyFullprice": "Full price was",
    "keyNewprice": "New price is"
  },
  "en-in": {
    "keyFullprice": "Full price was",
    "keyNewprice": "New price is"
  },
  "en-nz": {
    "keyFullprice": "Full price was",
    "keyNewprice": "New price is"
  },
  "en-sg": {
    "keyFullprice": "Full price was",
    "keyNewprice": "New price is"
  },
  "en-za": {
    "keyFullprice": "Full price was",
    "keyNewprice": "New price is"
  },
  "es-ar": {
    "keyFullprice": "El precio original era",
    "keyNewprice": "El nuevo precio es"
  },
  "es-cl": {
    "keyFullprice": "El precio original era",
    "keyNewprice": "El nuevo precio es"
  },
  "es-co": {
    "keyFullprice": "El precio original era",
    "keyNewprice": "El nuevo precio es"
  },
  "es-es": {
    "keyFullprice": "El precio original era",
    "keyNewprice": "El nuevo precio es"
  },
  "es-mx": {
    "keyFullprice": "El precio original era",
    "keyNewprice": "El nuevo precio es"
  },
  "fi-fi": {
    "keyFullprice": "Normaalihinta oli",
    "keyNewprice": "Uusi hinta on"
  },
  "fr-be": {
    "keyFullprice": "Prix plein de",
    "keyNewprice": "Le nouveau prix s’élève à",
  },
  "fr-ca": {
    "keyFullprice": "Le prix régulier est de",
    "keyNewprice": "Le nouveau prix est"
  },
  "fr-ch": {
    "keyFullprice": "Prix plein de",
    "keyNewprice": "Le nouveau prix s’élève à"
  },
  "fr-fr": {
    "keyFullprice": "Prix plein de",
    "keyNewprice": "Le nouveau prix s’élève à"
  },
  "he-il": {
    "keyFullprice": "Full price was",
    "keyNewprice": "New Price is"
  },
  "hu-hu": {
    "keyFullprice": "Eredeti ár:",
    "keyNewprice": "Az új ár"
  },
  "it-it": {
    "keyFullprice": "Il prezzo intero era",
    "keyNewprice": "Il nuovo prezzo è"
  },
  "ja-jp": {
    "keyFullprice": "通常価格は",
    "keyNewprice": "新しい価格は"
  },
  "ko-kr": {
    "keyFullprice": "정가",
    "keyNewprice": "새로운 가격은 다음과 같습니다"
  },
  "nb-no": {
    "keyFullprice": "Full pris var",
    "keyNewprice": "Ny pris er"
  },
  "nl-be": {
    "keyFullprice": "Volledige prijs was",
    "keyNewprice": "De nieuwe prijs is"
  },
  "nl-nl": {
    "keyFullprice": "Volledige prijs was",
    "keyNewprice": "De nieuwe prijs is"
  },
  "pl-pl": {
    "keyFullprice": "Pełna cena:",
    "keyNewprice": "Nowa cena to"
  },
  "pt-br": {
    "keyFullprice": "O preço normal era",
    "keyNewprice": "O novo preço é"
  },
  "pt-pt": {
    "keyFullprice": "O preço era",
    "keyNewprice": "O novo preço é"
  },
  "ru-ru": {
    "keyFullprice": "Полная цена была",
    "keyNewprice": "Новая цена -"
  },
  "sk-sk": {
    "keyFullprice": "Plná cena:",
    "keyNewprice": "Nová cena:"
  },
  "sv-se": {
    "keyFullprice": "Fullt pris",
    "keyNewprice": "Nytt pris är"
  },
  "tr-tr": {
    "keyFullprice": "Tam ücret",
    "keyNewprice": "Yeni Fiyat"
  },
  "zh-hk": {
    "keyFullprice": "原價為",
    "keyNewprice": "新價格是"
  },
  "zh-tw": {
    "keyFullprice": "原價為",
    "keyNewprice": "新價格為"
  }
}
}