$(document).ready(function() {
var uri = new URL(document.URL);
var urlRegion = uri.pathname.slice(1,6).toLowerCase();
  function makedc(title) {
    return title.toLowerCase().replace(/\s/g, "-").replace(/[^>a-z0-9-]/gi,'');
  }

  var populateHero = (function() {
    var regHeroContent = allHeroes.locales[urlRegion] 


    var heroTypes = {};
    heroTypes["center"] = '<section class="m-hero-item f-x-center f-y-center context-accessory" role="tabpanel" tabindex="-1">' +
                           '<picture class="c-image">' +
                              '<source class="heroImgDesktop" srcset="" media="(min-width:1084px)">' +
                              '<source class="heroImgTablet" srcset="" media="(min-width:768px)">' +
                              '<source class="heroImgMobile" srcset="" media="(min-width:0)">' +
                              '<img srcset="" src="" alt="">' +
                        '</picture>' +
                          '<div>' +
                              '<div class="high-contrast">' +
                                  '<strong class="c-badge f-small"><span></span></strong>' +
                                  '<h1 class="c-heading"></h1>' +
                                  '<p class="c-subheading x-visible-inline-block"></p>' +
                                  '<div>' +
                                      '<a href="" class="c-call-to-action c-glyph f-heavyweight cta1" data-cta="learn" aria-label="">' +
                                          '<span></span>' +
                                      '</a>' +
                                      '<a href="" class="c-call-to-action c-glyph cta2 f-lightweight" data-clickname="www>xbox-one>accessories>hero-slide>click" data-cta="learn" aria-label="">' +
                                          '<span></span>' +
                                      '</a>' +
                                  '</div>' +
                                '</div>' +
                              '</div>' +
                            '</section>'

    heroTypes["centerlogo"] = '<section class="m-hero-item f-x-center f-y-center context-accessory" role="tabpanel" tabindex="-1">' +
                           '<picture class="c-image">' +
                                '<source class="heroImgDesktop" srcset="" media="(min-width:1084px)">' +
                                '<source class="heroImgTablet" srcset="" media="(min-width:768px)">' +
                                '<source class="heroImgMobile" srcset="" media="(min-width:0)">' +
                                '<img srcset="" src="" alt="">' +
                          '</picture>' +
                            '<div>' +
                                '<div class="high-contrast">' +
                                    '<strong class="c-badge f-small"><span></span></strong>' +
                                    '<h1 class="c-heading"></h1>' +
                                    '<p class="c-subheading x-visible-inline-block"></p>' +
                                    '<div>' +
                                        '<a href="" class="c-call-to-action c-glyph f-heavyweight cta1" data-cta="learn" aria-label="">' +
                                            '<span></span>' +
                                        '</a>' +
                                        '<a href="" class="c-call-to-action c-glyph cta2 f-lightweight" data-clickname="www>xbox-one>accessories>hero-slide>click" data-cta="learn" aria-label="">' +
                                            '<span></span>' +
                                        '</a>' +
                                    '</div>' +
                                  '</div>' +
                                '</div>' +
                              '</section>'

    heroTypes["right"] = '<section class="m-hero-item f-x-right f-y-center context-accessory" role="tabpanel" tabindex="-1">' +
                      '<picture class="c-image">' +
                            '<source class="heroImgDesktop" srcset="" media="(min-width:1084px)">' +
                            '<source class="heroImgTablet" srcset="" media="(min-width:768px)">' +
                            '<source class="heroImgMobile" srcset="" media="(min-width:0)">' +
                            '<img srcset="" src="" alt="">' +
                      '</picture>' +
                        '<div>' +
                            '<div class="high-contrast">' +
                                '<strong class="c-badge f-small"><span></span></strong>' +
                                '<h1 class="c-heading zpt"></h1>' +
                                '<p class="c-subheading x-visible-inline-block"></p>' +
                                '<div>' +
                                    '<a href="" class="c-call-to-action c-glyph f-heavyweight cta1" data-cta="learn" aria-label="">' +
                                        '<span></span>' +
                                    '</a>' +
                                    '<a href="" class="c-call-to-action c-glyph cta2 f-lightweight" data-clickname="www>xbox-one>accessories>hero-slide>click" data-cta="learn" aria-label="">' +
                                        '<span></span>' +
                                    '</a>' +
                                '</div>' +
                              '</div>' +
                            '</div>' +
                          '</section>'

    heroTypes["left"] = '<section class="m-hero-item f-x-left f-y-center context-accessory" role="tabpanel" tabindex="-1">' +
                         '<picture class="c-image">' +
                            '<source class="heroImgDesktop" srcset="" media="(min-width:1084px)">' +
                            '<source class="heroImgTablet" srcset="" media="(min-width:768px)">' +
                            '<source class="heroImgMobile" srcset="" media="(min-width:0)">' +
                            '<img srcset="" src="" alt="">' +
                      '</picture>' +
                        '<div>' +
                            '<div class="high-contrast">' +
                                '<strong class="c-badge f-small"><span></span></strong>' +
                                '<h1 class="c-heading zpt"></h1>' +
                                '<p class="c-subheading x-visible-inline-block"></p>' +
                                '<div>' +
                                    '<a href="" class="c-call-to-action c-glyph f-heavyweight cta1" data-cta="learn" aria-label="">' +
                                        '<span></span>' +
                                    '</a>' +
                                    '<a href="" class="c-call-to-action c-glyph cta2 f-lightweight" data-clickname="www>xbox-one>accessories>hero-slide>click" data-cta="learn" aria-label="">' +
                                        '<span></span>' +
                                    '</a>' +
                                '</div>' +
                              '</div>' +
                            '</div>' +
                          '</section>'

    heroTypes["centerbottom"] = '<section class="m-hero-item f-x-center f-y-bottom context-accessory" role="tabpanel" tabindex="-1">' +
                                  '<picture class="c-image">' +
                                    '<source class="heroImgDesktop" srcset="" media="(min-width:1084px)">' +
                                    '<source class="heroImgTablet" srcset="" media="(min-width:768px)">' +
                                    '<source class="heroImgMobile" srcset="" media="(min-width:0)">' +
                                    '<img srcset="" src="" alt="">' +
                              '</picture>' +
                                '<div>' +
                                    '<div class="high-contrast">' +
                                        '<strong class="c-badge f-small"><span></span></strong>' +
                                        '<h1 class="c-heading zpt"></h1>' +
                                        '<p class="c-subheading x-visible-inline-block"></p>' +
                                        '<div>' +
                                            '<a href="" class="c-call-to-action c-glyph f-heavyweight cta1" data-cta="learn" aria-label="">' +
                                                '<span></span>' +
                                            '</a>' +
                                            '<a href="" class="c-call-to-action c-glyph cta2 f-lightweight" data-clickname="www>xbox-one>accessories>hero-slide>click" data-cta="learn" aria-label="">' +
                                                '<span></span>' +
                                            '</a>' +
                                        '</div>' +
                                      '</div>' +
                                    '</div>' +
                                  '</section>'

    heroTypes["centertop"] = '<section class="m-hero-item f-x-center f-y-top context-accessory" role="tabpanel" tabindex="-1">' +
                                '<picture class="c-image">' +
                                  '<source class="heroImgDesktop" srcset="" media="(min-width:1084px)">' +
                                  '<source class="heroImgTablet" srcset="" media="(min-width:768px)">' +
                                  '<source class="heroImgMobile" srcset="" media="(min-width:0)">' +
                                  '<img srcset="" src="" alt="">' +
                            '</picture>' +
                              '<div>' +
                                  '<div class="high-contrast">' +
                                      '<strong class="c-badge f-small"><span></span></strong>' +
                                      '<h1 class="c-heading"></h1>' +
                                      '<p class="c-subheading x-visible-inline-block"></p>' +
                                      '<div>' +
                                          '<a href="" class="c-call-to-action c-glyph f-heavyweight cta1" data-cta="learn" aria-label="">' +
                                              '<span></span>' +
                                          '</a>' +
                                          '<a href="" class="c-call-to-action c-glyph cta2 f-lightweight" data-clickname="www>xbox-one>accessories>hero-slide>click" data-cta="learn" aria-label="">' +
                                              '<span></span>' +
                                          '</a>' +
                                      '</div>' +
                                    '</div>' +
                                  '</div>' +
                                '</section>'

    heroTypes["video"] = '<section class="m-hero-item f-x-left f-y-center context-device videohero f-precise-click" role="tabpanel"  tabindex="-1">' +
                            '<div class="m-ambient-video vid herovideo pp-button">' +
                              '<video role="img" alt="Ambient video alt text" aria-label="" poster="" muted autoplay loop>' +
                                  '<source class="heroImgDesktop" src="" type="video/mp4">' +
                              '</video>' +
                            '</div> ' +
                                 '<picture class="c-image">' +
                                    '<source class="heronovideomobbiggest" srcset="" media="(min-width:1084px)">' +
                                    '<source class="heroImgTablet" srcset="" media="(min-width:768px)">' +
                                    '<source class="heroImgMobile" srcset="" media="(min-width:0)">' +
                                    '<img class="heronovideomobile" srcset="" src="" alt="">' +
                                  '</picture>' +
                                  '<div>' +
                                      '<div class="high-contrast">' +
                                          '<strong class="c-badge f-small"><span></span></strong>' +
                                          '<h1 class="c-heading zpt"></h1>' +
                                          '<p class="c-subheading x-visible-inline-block"></p>' +
                                          '<div>' +
                                              '<a href="" class="c-call-to-action c-glyph f-heavyweight cta1" data-cta="learn" aria-label="">' +
                                                  '<span></span>' +
                                              '</a>' +
                                              '<a href="" class="c-call-to-action c-glyph cta2 f-lightweight" data-cta="learn" aria-label="">' +
                                                  '<span></span>' +
                                              '</a>' +
                                          '</div>' +
                                      '</div>' +
                                  '</div>' +
                              '</section>' +
                              '<style>.m-hero-item .m-ambient-video {padding: 0;} .videohero .m-ambient-video div button {bottom: -17vw;} .videohero .m-ambient-video video {width: 100% !important;} @media screen and (min-width: 1921px) { .home-hero .videohero { height: 720px;} .videohero .m-ambient-video div button {bottom: -325px;} } @media screen and (max-width: 1083px) { .home-hero .videohero .m-ambient-video { display: none;} }</style>'


    var numHeroes = regHeroContent["keyNumberofheroes"]
    if (numHeroes === "1") {
      var heroInsert = heroTypes[regHeroContent["keyHero1type"].toLowerCase()];
      $(".sl-hero").append(heroInsert)
      if (regHeroContent["keyHero1extraclasses"] !== "####") {
        $(".sl-hero .m-hero-item").addClass(regHeroContent["keyHero1extraclasses"])
      }
      $(".sl-hero .heroImgDesktop").attr("srcset", regHeroContent["keyHero1imagedesktop"])
      $(".sl-hero .heroImgTablet").attr("srcset", regHeroContent["keyHero1imagetablet"])
      $(".sl-hero .heroImgTabletSmall").attr("srcset", regHeroContent["keyHero1imagetabletsmall"])
      $(".sl-hero .heroImgMobile").attr("srcset", regHeroContent["keyHero1imagemobile"])
      $(".sl-hero picture img").attr("src", regHeroContent["keyHero1imagedesktop"]).attr("srcset", regHeroContent["keyHero1imagedesktop"])
      $(".sl-hero video source").attr("src", regHeroContent["keyHero1imagedesktop"]); // for video
      $(".sl-hero picture img").attr("src", regHeroContent["keyHero1imagedesktop"]);
      $(".sl-hero picture img").attr("alt", regHeroContent["keyHero1alt"]);
      $(".sl-hero video").attr("alt", regHeroContent["keyHero1alt"]).attr("aria-label", regHeroContent["keyHero1alt"]); // for video
      $(".sl-hero video").attr("poster", regHeroContent["keyHero1poster"]); 
      $(".sl-hero .heronovideomobile").attr("src", regHeroContent["keyHero1imagesmallest"]);
      $(".sl-hero .heronovideomobile").attr("src", regHeroContent["keyHero1imagesmallest"]);
      $(".sl-hero .heronovideomobsmallest").attr("srcset", regHeroContent["keyHero1imagesmallest"]);
      $(".sl-hero .heronovideomobmedium").attr("srcset", regHeroContent["keyHero1imagemobile"]);
      $(".sl-hero .heronovideomobbiggest").attr("srcset", regHeroContent["keyHero1poster"]);
      if (regHeroContent["keyHero1badgecolor"].toLowerCase() === "gold") {
          $(".sl-hero .c-badge").addClass("f-highlight");
        } else {
          $(".sl-hero .c-badge").addClass("f-lowlight"); 
        }
      if (regHeroContent["keyHero1badgecolor"].toLowerCase() === "green") {
          $(".sl-hero .c-badge").css("background-color", "#107c10");
       }
      $(".sl-hero .c-badge").attr("data-loc-color", "keyHero1badgecolor");
      $(".sl-hero .c-badge span").text(regHeroContent["keyHero1badgecopy"]);
      $(".sl-hero h1").html(regHeroContent["keyHero1headline"])
      $(".sl-hero p.c-subheading").html(regHeroContent["keyHero1subheading"])
      $(".sl-hero a.cta1").attr("href", regHeroContent["keyHero1link"])
      $(".sl-hero a.cta1 span").text(regHeroContent["keyHero1cta"])
      if (regHeroContent["keyHero1dataretailer"] !== "####") { $(".sl-hero a.cta1").attr("data-retailer", regHeroContent["keyHero1dataretailer"]) }
      $(".sl-hero a.cta1").attr("aria-label", regHeroContent["keyHero1arialabel"])
      $(".sl-hero a.cta1").attr("data-clickname", regHeroContent["keyHero1clickname"])

      $(".sl-hero a.cta2").attr("href", regHeroContent["keyHero1link2"])
      $(".sl-hero a.cta2 span").text(regHeroContent["keyHero1cta2"])
      if (regHeroContent["keyHero1dataretailer2"] !== "####") { $(".sl-hero a.cta2").attr("data-retailer", regHeroContent["keyHero1dataretailer2"]) }
      $(".sl-hero a.cta2").attr("aria-label", regHeroContent["keyHero1arialabel2"])
      $(".sl-hero a.cta2").attr("data-clickname", regHeroContent["keyHero1clickname2"])
    } else {
      var herotooltip = $("#herotooltiptext").text();

      var playslidetext = { "locales": {
                                    "en-us": {
                                      "keyPlayslideshow": "Play slideshow"
                                    },
                                    "ar-ae": {
                                      "keyPlayslideshow": "Play slideshow"
                                    },
                                    "ar-sa": {
                                      "keyPlayslideshow": "Play slideshow"
                                    },
                                    "cs-cz": {
                                      "keyPlayslideshow": "Přehrát prezentaci"
                                    },
                                    "da-dk": {
                                      "keyPlayslideshow": "Afspil slideshow"
                                    },
                                    "de-at": {
                                      "keyPlayslideshow": "Diashow abspielen"
                                    },
                                    "de-ch": {
                                      "keyPlayslideshow": "Diashow abspielen"
                                    },
                                    "de-de": {
                                      "keyPlayslideshow": "Diashow abspielen"
                                    },
                                    "el-gr": {
                                      "keyPlayslideshow": "Αναπαραγωγή παρουσίασης"
                                    },
                                    "en-au": {
                                      "keyPlayslideshow": "Play slideshow"
                                    },
                                    "en-ca": {
                                      "keyPlayslideshow": "Play slideshow"
                                    },
                                    "en-gb": {
                                      "keyPlayslideshow": "Play slideshow"
                                    },
                                    "en-hk": {
                                      "keyPlayslideshow": "Play slideshow"
                                    },
                                    "en-ie": {
                                      "keyPlayslideshow": "Play slideshow"
                                    },
                                    "en-in": {
                                      "keyPlayslideshow": "Play slideshow"
                                    },
                                    "en-nz": {
                                      "keyPlayslideshow": "Play slideshow"
                                    },
                                    "en-sg": {
                                      "keyPlayslideshow": "Play slideshow"
                                    },
                                    "en-za": {
                                      "keyPlayslideshow": "Play slideshow"
                                    },
                                    "es-ar": {
                                      "keyPlayslideshow": "Reproducir presentación de diapositivas"
                                    },
                                    "es-cl": {
                                      "keyPlayslideshow": "Reproducir presentación de diapositivas"
                                    },
                                    "es-co": {
                                      "keyPlayslideshow": "Reproducir presentación de diapositivas"
                                    },
                                    "es-es": {
                                      "keyPlayslideshow": "Reproducir presentación de diapositivas"
                                    },
                                    "es-mx": {
                                      "keyPlayslideshow": "Reproducir presentación de diapositivas"
                                    },
                                    "fi-fi": {
                                      "keyPlayslideshow": "Toista diaesitys"
                                    },
                                    "fr-be": {
                                      "keyPlayslideshow": "Lancer le diaporama"
                                    },
                                    "fr-ca": {
                                      "keyPlayslideshow": "Lancer le diaporama"
                                    },
                                    "fr-ch": {
                                      "keyPlayslideshow": "Lancer le diaporama"
                                    },
                                    "fr-fr": {
                                      "keyPlayslideshow": "Lancer le diaporama"
                                    },
                                    "he-il": {
                                      "keyPlayslideshow": "Play slideshow"
                                    },
                                    "hu-hu": {
                                      "keyPlayslideshow": "Diavetítés"
                                    },
                                    "it-it": {
                                      "keyPlayslideshow": "Esegui presentazione"
                                    },
                                    "ja-jp": {
                                      "keyPlayslideshow": "スライドショーの再生"
                                    },
                                    "ko-kr": {
                                      "keyPlayslideshow": "슬라이드쇼 재생"
                                    },
                                    "nb-no": {
                                      "keyPlayslideshow": "Spill lysbildefremvisning"
                                    },
                                    "nl-be": {
                                      "keyPlayslideshow": "Diavoorstelling afspelen"
                                    },
                                    "nl-nl": {
                                      "keyPlayslideshow": "Diavoorstelling afspelen"
                                    },
                                    "pl-pl": {
                                      "keyPlayslideshow": "Odtwórz pokaz slajdów"
                                    },
                                    "pt-br": {
                                      "keyPlayslideshow": "Ver apresentação de slides"
                                    },
                                    "pt-pt": {
                                      "keyPlayslideshow": "Reproduzir apresentação de diapositivos"
                                    },
                                    "ru-ru": {
                                      "keyPlayslideshow": "Воспроизвести слайд-шоу"
                                    },
                                    "sk-sk": {
                                      "keyPlayslideshow": "Prehrať prezentáciu"
                                    },
                                    "sv-se": {
                                      "keyPlayslideshow": "Spela bildspell"
                                    },
                                    "tr-tr": {
                                      "keyPlayslideshow": "Slayt gösterisini oynat"
                                    },
                                    "zh-hk": {
                                      "keyPlayslideshow": "播放投影片"
                                    },
                                    "zh-tw": {
                                      "keyPlayslideshow": "播放投影片"
                                    }
                                  }
                                }
      
      $(".sl-hero").append('<div class="c-carousel f-multi-slide f-auto-play" role="region" aria-label="featured items on xbox dot com" data-js-interval="6000">' +
                '<div class="c-group">' +
                '<button class="c-action-toggle high-contrast c-glyph glyph-play f-toggle" data-toggled-label="Pause" data-toggled-glyph="glyph-pause" ' +
                'aria-label="Play" aria-pressed="false"></button>' +
                '<div class="c-sequence-indicator" role="tablist">' +
                '<button role="tab" aria-selected="true" aria-label="" aria-controls="hero-1" title="' +
                regHeroContent["keyHero1headline"].replace("<br>", " ") + '"></button>' +
                '<button role="tab" aria-selected="false" aria-label="" aria-controls="hero-2" title="' +
                regHeroContent["keyHero2headline"].replace("<br>", " ") + '"></button>' +
                '</div>' +
                '</div>' +
                '<button class="c-flipper f-previous high-contrast" aria-hidden="true" tabindex="-1"></button>' +
                '<button class="c-flipper f-next high-contrast" aria-hidden="true" tabindex="-1"></button>' +
                '<div itemscope itemtype="http://schema.org/ItemList">' +
                '<ul class="heroList">' +
                '</ul>' +
                '</div>' +
                '</div>')

      for (var i = 1; i <= numHeroes; i++) {
        var heroPre = "keyHero" + i;
        if (i > 2) {
          var controllab = regHeroContent[heroPre + "headline"].replace("<br>", " ");
          if (controllab.length === 0) {
            controllab = regHeroContent[heroPre + "subheading"].replace("<br>", " ");
          }
          $(".sl-hero .c-sequence-indicator button").last().after('<button role="tab" aria-selected="false" aria-label="' + 
            controllab + '" title="' + controllab + '"></button>')
        }
        var heroInsert = heroTypes[regHeroContent[heroPre + "type"].toLowerCase()];
        $(".sl-hero .heroList").append('<li id="hero-' + i + '">' + 
                                heroInsert + 
                                '</li>')
        if (regHeroContent[heroPre + "extraclasses"] !== "####") {
          $(".sl-hero li").eq(i - 1).find(".m-hero-item").addClass(regHeroContent[heroPre + "extraclasses"])
        }
        $(".sl-hero li").eq(i - 1).find(".heroImgDesktop").attr("srcset", regHeroContent[heroPre + "imagedesktop"])
        $(".sl-hero li").eq(i - 1).find(".heroImgTablet").attr("srcset", regHeroContent[heroPre + "imagetablet"])
        $(".sl-hero li").eq(i - 1).find(".heroImgTabletSmall").attr("srcset", regHeroContent[heroPre + "imagetabletsmall"])
        $(".sl-hero li").eq(i - 1).find(".heroImgMobile").attr("srcset", regHeroContent[heroPre + "imagemobile"])
        $(".sl-hero li").eq(i - 1).find("picture img").attr("src", regHeroContent[heroPre + "imagedesktop"]).attr("srcset", regHeroContent[heroPre + "imagedesktop"])
        $(".sl-hero li").eq(i - 1).find("video source").attr("src", regHeroContent[heroPre + "imagedesktop"]); // for video
        $(".sl-hero li").eq(i - 1).find("picture img").attr("alt", regHeroContent[heroPre + "alt"])
        $(".sl-hero li").eq(i - 1).find("video").attr("alt", regHeroContent[heroPre + "alt"]); // for video
        $(".sl-hero li").eq(i - 1).find("video").attr("poster", regHeroContent[heroPre + "imagetablet"]); // for video
        $(".sl-hero li").eq(i - 1).find(".heronovideomobile").attr("src", regHeroContent[heroPre + "imagesmallest"]) 
        $(".sl-hero li").eq(i - 1).find(".heronovideomobsmallest").attr("srcset", regHeroContent[heroPre + "imagesmallest"]);
        $(".sl-hero li").eq(i - 1).find(".heronovideomobmedium").attr("srcset", regHeroContent[heroPre + "imagemobile"]);
        $(".sl-hero li").eq(i - 1).find(".heronovideomobbiggest").attr("srcset", regHeroContent[heroPre + "imagetablet"]);
        if (regHeroContent["keyHero" + i + "badgecolor"].toLowerCase() === "gold") {
          $(".sl-hero li").eq(i - 1).find(".c-badge").addClass("f-highlight");
        } else {
          $(".sl-hero li").eq(i - 1).find(".c-badge").addClass("f-lowlight"); 
        }
        if (regHeroContent["keyHero" + i + "badgecolor"].toLowerCase() === "green") {
          $(".sl-hero li").eq(i - 1).find(".c-badge").css("background-color", "#107c10");
        }
        $(".sl-hero li").eq(i - 1).find(".c-badge span").text(regHeroContent["keyHero" + i + "badgecopy"]);
        $(".sl-hero li").eq(i - 1).find("h1").html(regHeroContent[heroPre + "headline"])
        $(".sl-hero li").eq(i - 1).find("p.c-subheading").html(regHeroContent[heroPre + "subheading"])
        $(".sl-hero li").eq(i - 1).find("a.cta1").attr("href", regHeroContent[heroPre + "link"])
        $(".sl-hero li").eq(i - 1).find("a.cta1 span").text(regHeroContent[heroPre + "cta"])
        if (regHeroContent[heroPre + "dataretailer"] !== "####") {
          $(".sl-hero li").eq(i - 1).find("a.cta1").attr("data-retailer", regHeroContent[heroPre + "dataretailer"])
        }
        $(".sl-hero li").eq(i - 1).find("a.cta1").attr("aria-label", regHeroContent[heroPre + "arialabel"])
        $(".sl-hero li").eq(i - 1).find("a.cta1").attr("data-clickname", regHeroContent[heroPre + "clickname"]);

        $(".sl-hero li").eq(i - 1).find("a.cta2").attr("href", regHeroContent[heroPre + "link2"])
        $(".sl-hero li").eq(i - 1).find("a.cta2 span").text(regHeroContent[heroPre + "cta2"])
        if (regHeroContent[heroPre + "dataretailer2"] !== "####") {
          $(".sl-hero li").eq(i - 1).find("a.cta2").attr("data-retailer", regHeroContent[heroPre + "dataretailer2"])
        }
        $(".sl-hero li").eq(i - 1).find("a.cta2").attr("aria-label", regHeroContent[heroPre + "arialabel2"])
        $(".sl-hero li").eq(i - 1).find("a.cta2").attr("data-clickname", regHeroContent[heroPre + "clickname2"]);
        if ($(".sl-hero li").eq(i - 1).find("p.c-subheading").text() === "####") {
          $(".sl-hero li").eq(i - 1).find("p.c-subheading").remove();
        }
        if ($(".sl-hero li").eq(i - 1).find("h1").text() === "####") {
          $(".sl-hero li").eq(i - 1).find("h1").remove();
        }
        if ($(".sl-hero li").eq(i - 1).find("h1").text().length > 32) {
          $(".sl-hero li").eq(i - 1).find("h1").removeClass("c-heading-1").addClass("c-heading-2");
        }
      }
    }

    $(".sl-hero a").each(function() {
      if ($(this).text() === "####" || $(this).text() === "") {
        $(this).remove();
      }
      if ($(this).attr("href").indexOf("xboxdesignlab") !== -1) {
        $(this).attr("data-cta", "internal");
      }
    })
    $(".sl-hero p").each(function() {
      if ($(this).text() === "####") {
        $(this).remove();
      }
    })
    $(".sl-hero h1").each(function() {
      if ($(this).text() === "####") {
        $(this).remove();
      }
    })
    $(".sl-hero span").each(function() {
      if ($(this).text() === "####") {
        $(this).closest(".c-badge").remove();
      }
    })



    $(".sl-hero ul li").eq(0).addClass("f-active");

    $(".heroList section").each(function() {
      if ($(this).hasClass("theme-dark")) {
        $(this).parents("li").attr("data-f-theme", "dark")
      } else {
        $(this).parents("li").attr("data-f-theme", "light")
      }
    })

    $(".sl-hero h1").each(function() {
      var head = $(this);
      var temphead = $(head).html();
      var headarr = temphead.toLowerCase().replace("<br>", " ").split(" ");
      headarr.forEach(function(word) {
        if (word.length > 11) { 
          $(head).removeClass("c-heading-1").addClass("c-heading-2");
        }
      })
    })
    
    // Design Button
    // $(".m-hero-item a").each(function () {
    //   var ctaTextDL = $(this).attr("href").toLowerCase()
    //   if (ctaTextDL.indexOf("xboxdesignlab") !== -1)  {
    //       $(this).removeClass("f-heavyweight").addClass("customize-button").addClass("cta-btn-dark");
    //       $(this).closest(".m-hero-item").find(".c-subheading").addClass("c-subheading-2").removeClass("c-subheading");
    //   } 
    // });

    $(".m-hero-item h1").each(function(index) { 
      if (index !== 0) {
        var newhtext = $(this).html();
        var newhclasses = $(this).attr("class");
        $(this).after('<h2 class="' + newhclasses + ' x-hidden-focus">' + newhtext + '</h2>');
        $(this).remove();
      }
    });

      if (regHeroContent["keyHero1type"].toLowerCase().trim() === "video") {
        videoTransitionCss();
      }

        function videoTransitionCss() {
          $("body").append('<style>' +
                '.m-hero .c-carousel { background-color: black !important; }' +
                'transition-property: visibility, opacity !important; transition-delay: 1s, .3s !important; position: absolute !important; ' +
                'display: block !important; pointer-events: none; }' +
                'transition-timing-function: linear !important; transition-duration: 0s, .7s !important; transition-property: visibility, opacity !important;' +
                'transition-delay: 0.3s, .7s !important; }' +
                '</style>')
        }


    setTimeout(function() {
      $("body").css("visibility", "visible");
    }, 100)
  })();

  var populateContent = (function() {
    var uri = new URL(document.URL);
    var urlRegion = uri.pathname.slice(1, 6).toLowerCase();
    if (urlRegion === "en-ae") {
      urlRegion = "ar-ae";
    } else if (urlRegion === "en-sa") {
      urlRegion = "ar-sa";
    } else if (urlRegion === "en-il") {
      urlRegion = "he-il";
    }

    var popJSON = (function() {
      var regionContent = allHeroes.locales[urlRegion];
      var allKeys = Object.keys(regionContent)
      var keysLength = allKeys.length
      for (var i = 0; i < keysLength; i++) {
          if (allKeys[i].indexOf("keyCopy") !== -1) {
              $("[data-loc-copy=" + allKeys[i] + "]").html(regionContent[allKeys[i]]);
              $("[data-loc-aria=" + allKeys[i] + "]").attr("aria-label", regionContent[allKeys[i]]);
          } else if (allKeys[i].indexOf("keyImage") !== -1) {
              $("source[data-loc-image=" + allKeys[i] + "]").attr("srcset", regionContent[allKeys[i]]);
              $("img[data-loc-image=" + allKeys[i] + "]").attr("src", regionContent[allKeys[i]]).attr("srcset", regionContent[allKeys[i]]);
          } else if (allKeys[i].indexOf("keyAlt") !== -1) {
              $("[data-loc-alt=" + allKeys[i] + "]").attr("alt", regionContent[allKeys[i]]);
          } else if (allKeys[i].indexOf("keyLink") !== -1) {
              $("[data-loc-link=" + allKeys[i] + "]").attr("href", regionContent[allKeys[i]]);
          } else if (allKeys[i].indexOf("keyClickname") !== -1) {
              $("[data-loc-clickname=" + allKeys[i] + "]").attr("data-clickname", regionContent[allKeys[i]]);
          } else if (allKeys[i].indexOf("keyRetailer") !== -1) {
              if (regionContent[allKeys[i]] !== "####" && regionContent[allKeys[i]] !== "") {
                  $("[data-loc-retailer=" + allKeys[i] + "]").attr("data-retailer", regionContent[allKeys[i]]);
              }
          } else if (allKeys[i].indexOf("keyCta") !== -1) {
              if (regionContent[allKeys[i]] !== "####" && regionContent[allKeys[i]] !== "") {
                  $("[data-loc-cta=" + allKeys[i] + "]").attr("data-cta", regionContent[allKeys[i]]);
              }
          } else if (allKeys[i].indexOf("keyAria") !== -1) {
              $("[data-loc-aria=" + allKeys[i] + "]").attr("aria-label", regionContent[allKeys[i]]);
          } else if (allKeys[i].indexOf("keyInclude") !== -1) {
              $("[data-loc-include=" + allKeys[i] + "]").attr("data-region-include", regionContent[allKeys[i]]);
          } else if (allKeys[i].indexOf("keyExclude") !== -1) {
              $("[data-loc-exclude=" + allKeys[i] + "]").attr("data-region-exclude", regionContent[allKeys[i]]);
          } else if (allKeys[i].indexOf("keyPlayson") !== -1) {
              $("[data-loc-playson=" + allKeys[i] + "]").attr("data-playson", regionContent[allKeys[i]].toLowerCase());
          } else if (allKeys[i].indexOf("keyYoutube") !== -1) {
              $("[data-loc-youtube=" + allKeys[i] + "]").attr("data-raven-youtubeid", regionContent[allKeys[i]]);
          }
      }
    })();
  })();

  var translate = (function() {

   var spLocales = "ar-ae, en-in, es-ar, es-cl, es-co, es-mx, pt-br"

   if (spLocales.indexOf(urlRegion) !== -1) {
    $(".home-hero #hero-1 .m-hero-item.f-x-right>div>div").addClass("bNo");
   }

  var regionStrings = allHeroes.locales[urlRegion]
  $(".legal1").text(regionStrings["keyCopylegal1"]);
  $(".legal2").text(regionStrings["keyCopylegal2"]);
  $(".legal3").text(regionStrings["keyCopylegal3"]);

    if ($(".legal .legal1").text() === "####" || $(".legal .legal1").text() === "") {
        $('.legal').hide();
      }

    if ($(".legal .legal2").text() === "####") {
        $('.legal2').remove();
      }

    if ($(".legal .legal3").text() === "####") {
        $('.legal3').remove();
      }

  })();

});
