// Deals
$(document).ready(function() {

    if ($(".CatAnnounce").length === 0) {
        $("body").append('<div style="width:0;height:0;font-size:0;" class="CatAnnounce" aria-live="assertive"></div>');
    }

    regionContent = globalContent.locales[urlRegion];
    paginateclick = 0;
  
    if (urlRegion === "en-ae") {
        urlRegion = "ar-ae";
    } else if (urlRegion === "en-sa") {
        urlRegion = "ar-sa";
    } else if (urlRegion === "en-il") {
        urlRegion = "he-il";
    }
  
    var uniquefga = [];
    fullGameArray.forEach(function(c) {
        if (!uniquefga.includes(c)) { uniquefga.push(c); }
    });

    fullGameArray = uniquefga;
  
    var ratingsApi = (function() {
      var ratingsUrl = "https://displaycatalog.mp.microsoft.com/v7.0/ratings?market=US&languages=LANG&MS-CV=DGU1mcuYo0WMMp+F.1"
      ratingsUrl = ratingsUrl.replace("US", urlRegion.split("-")[1]).replace("LANG", urlRegion);
      $.get(ratingsUrl)
        .done(function(listData) {
          ratingData = listData;
          grabLists();
        })
    })();
  
    var listArray = ["TopPaid:toppaid", "New:newreleases", "BestRated:bestrated", "ComingSoon:upcoming", "Deal:onsale", "TopFree:topfree", "MostPlayed:mostplayed"];
    var capArray = ["&gamecapabilities=capabilityxboxenhanced:enhanced", "&gamecapabilities=capability4k:fourk", "&gamecapabilities=capabilityhdr:HDRGaming",
        "&NumberOfPlayers=SinglePlayer:singleplayer", "&NumberOfPlayers=OnlineMultiplayerWithGold:multionline", "&NumberOfPlayers=LocalMultiplayer:multilocal",
        "&NumberOfPlayers=CoopSupportOnline:cooponline", "&NumberOfPlayers=CoopSupportLocal:cooplocal", "&gamecapabilities=XPA:xpa", "&gamecapabilities=gamestreaming:cloud",
        "&gamecapabilities=consolecrossgen:cross", "&gamecapabilities=ConsoleGen9Optimized:genNine"
    ]
  
    function grabLists() {
        var recoUrl = "https://reco-public.rec.mp.microsoft.com/channels/Reco/V8.0/Lists/Computed/LIST?Market=US&Language=EN&ItemTypes=Game&deviceFamily=Windows.Xbox&count=2000&skipitems=0"
        recoUrl = recoUrl.replace("US", urlRegion.split("-")[1]).replace("EN", urlRegion.split("-")[0]);
  
        var capUrls = ["https://reco-public.rec.mp.microsoft.com/channels/Reco/V8.0/Lists/Computed/TopPaid?Market=" + urlRegion.split("-")[1] +
            "&Language=" + urlRegion.split("-")[0] + "&ItemTypes=Game&deviceFamily=Windows.XboxCAPABILITY&count=2000&skipitems=0",
            "https://reco-public.rec.mp.microsoft.com/channels/Reco/V8.0/Lists/Computed/TopFree?Market=" + urlRegion.split("-")[1] +
            "&Language=" + urlRegion.split("-")[0] + "&ItemTypes=Game&deviceFamily=Windows.XboxCAPABILITY&count=2000&skipitems=0",
            "https://reco-public.rec.mp.microsoft.com/channels/Reco/V8.0/Lists/Computed/New?Market=" + urlRegion.split("-")[1] +
            "&Language=" + urlRegion.split("-")[0] + "&ItemTypes=Game&deviceFamily=Windows.XboxCAPABILITY&count=2000&skipitems=0",
            "https://reco-public.rec.mp.microsoft.com/channels/Reco/V8.0/Lists/Computed/ComingSoon?Market=" + urlRegion.split("-")[1] +
            "&Language=" + urlRegion.split("-")[0] + "&ItemTypes=Game&deviceFamily=Windows.XboxCAPABILITY&count=2000&skipitems=0"
        ]
  
        forcedGames = fullGameArray;
        excludebids = [];
        gameIdArrays["cloud"] = [];

        mainLists();

        // main list arrays
        function mainLists() {
            for (var i = 0; i < listArray.length; i++) {
                (function(i) {
                    var listreplace = listArray[i].split(":")[0];
                    var arrayname = listArray[i].split(":")[1];
                    gameIdArrays[arrayname] = [];
                    var listUrl = recoUrl.replace("LIST", listreplace);
                    $.get(listUrl)
                        .done(function(responseData) {
                            var totalitems = responseData.PagingInfo.TotalItems;
                            responseData.Items.forEach(function(e) {
                                if (excludebids.indexOf(e.Id) === -1 && fullGameArray.indexOf(e.Id) > -1) {
                                    gameIdArrays[arrayname].push(e.Id);
                                }
                                // if (fullGameArray.indexOf(e.Id) === -1 && excludebids.indexOf(e.Id) === -1) {
                                //     fullGameArray.push(e.Id);
                                // }
                            })
                            if (totalitems > 200) {
                                var chunks = Math.ceil(totalitems / 200)
                                largeList(listUrl, arrayname, chunks);
                            }
                            if (i === listArray.length - 1) {
                                var recoactivecheck = setInterval(function() {
                                    var recoactiveAjax = $.active;
                                    if (recoactiveAjax === 0) {
                                      // make sure toppaid is first
                                      // fullGameArray = fullGameArray.filter(function(v) { return gameIdArrays["toppaid"].indexOf(v) === -1 });
                                      // var tpcount = gameIdArrays["toppaid"].length;
                                      // for (var f = tpcount - 1; f >= 0; f--) {
                                      //   fullGameArray.unshift(gameIdArrays["toppaid"][f]);
                                      // }
                                      recodone();
                                      clearInterval(recoactivecheck);
                                    }
                                }, 500);
                            }
                        })
                })(i);
            }
        }
  
        // capability list arrays
        for (var i = 0; i < capArray.length; i++) {
            var arrayname = capArray[i].split(":")[1];
            gameIdArrays[arrayname] = [];
        }
        for (var i = 0; i < capUrls.length; i++) {
            (function(i) {
                for (var j = 0; j < capArray.length; j++) {
                    (function(j) {
                        var listreplace = capArray[j].split(":")[0];
                        var arrayname = capArray[j].split(":")[1];
                        var listUrl = capUrls[i].replace("CAPABILITY", listreplace);
                        $.get(listUrl)
                            .done(function(responseData) {
                                var totalitems = responseData.PagingInfo.TotalItems;
                                responseData.Items.forEach(function(e) {
                                    if (gameIdArrays[arrayname].indexOf(e.Id) === -1 && excludebids.indexOf(e.Id) === -1 && fullGameArray.indexOf(e.Id) > -1) {
                                        gameIdArrays[arrayname].push(e.Id);
                                    }
                                })
                                if (totalitems > 200) {
                                    var chunks = Math.ceil(totalitems / 200)
                                    largeList(listUrl, arrayname, chunks, true);
                                }
                            })
                    })(j);
                }
            })(i);
        }
  
        function largeList(url, arrayname, chunks, cap) {
            for (var i = 1; i < chunks; i++) {
                (function(i) {
                    var skipnum = 200 * i;
                    var largeUrl = url.replace("skipitems=0", "skipitems=" + skipnum);
                    $.get(largeUrl)
                        .done(function(responseData) {
                            responseData.Items.forEach(function(e) {
                                if (cap === true) {
                                    if (gameIdArrays[arrayname].indexOf(e.Id) === -1 && excludebids.indexOf(e.Id) === -1 && fullGameArray.indexOf(e.Id) > -1) {
                                        gameIdArrays[arrayname].push(e.Id);
                                    }
                                } else {
                                    if (excludebids.indexOf(e.Id) === -1 && fullGameArray.indexOf(e.Id) > -1) {
                                        gameIdArrays[arrayname].push(e.Id);
                                    }
                                    // if (fullGameArray.indexOf(e.Id) === -1 && excludebids.indexOf(e.Id) === -1) {
                                    //     fullGameArray.push(e.Id);
                                    // }
                                }
                            })
                        })
                })(i);
            }
        }
  
        function recodone() {
            for (var i = 0; i < listArray.length; i++) {
                var arrayname = listArray[i].split(":")[1];
                for (var j = 0; j < gameIdArrays[arrayname].length; j++) {
                    // if (fullGameArray.indexOf(gameIdArrays[arrayname][j]) === -1 && excludebids.indexOf(gameIdArrays[arrayname][j]) === -1) {
                    //     fullGameArray.push(gameIdArrays[arrayname][j])
                    // }
                }
            }
            popJSON();
        }
  
    }
  
    function popJSON() {
        regionRatingOrgs = { "en-us" : "ESRB", "en-au" : "COB-AU", "en-hk" : "IARC", "en-in" : "IARC", "en-nz" : "OFLC-NZ", "en-sg" : "IARC", "ja-jp" : "CERO", "ko-kr" : "GRB", "zh-hk" : "IARC", "zh-tw" : "CSRR", "ar-ae" : "IARC", "ar-sa" : "IARC", "cs-cz" : "PEGI", "da-dk" : "PEGI", "de-at" : "PEGI", "de-ch" : "PEGI", "de-de" : "USK", "el-gr" : "PEGI", "en-gb" : "PEGI", "en-ie" : "PEGI", "en-za" : "FPB", "fi-fi" : "PEGI", "fr-be" : "PEGI", "fr-ch" : "PEGI", "fr-fr" : "PEGI", "he-il" : "PEGI", "hu-hu" : "PEGI", "it-it" : "PEGI", "nb-no" : "PEGI", "nl-be" : "PEGI", "nl-nl" : "PEGI", "pl-pl" : "PEGI", "pt-pt" : "PEGI", "ru-ru" : "PCBP", "sk-sk" : "PEGI", "sv-se" : "PEGI", "tr-tr" : "PEGI", "en-ca" : "ESRB", "fr-ca" : "ESRB", "es-ar" : "ESRB", "es-cl" : "CCC", "es-co" : "ESRB", "es-es" : "PEGI", "es-mx" : "ESRB", "pt-br": "DJCTQ" };        //overrides
        fullcarouselimages = ["9PGSCB1X2P7G", "BRKX5CRMRTC2", "BZGJRJC1FGF3", "BPL68T0XK96W", "BV0NSD4NN4V4", "BPQ955FQFPH6", "BZRK5C951KK7", "BWPKGQV97N7N", "BPJ686W6S0NH", "9PDV8FKWP3B4", "BNG91PT95LQN", "C0QN5M9ZTC38", "C0GWTPD0S8S1", "C40860J5R2MP", "BR7X7MVBBQKM", "C4LLMHFQ1BXQ", "9NDDH3R9DF40", "BS36XT3Z5ZKL", "C17SFN1NXZ37", "BVFDTJ1XF6CS", "C4VLMWJWM7BG", "C57L9GR0HHB7", "BX4RTV7M28VS", "BS37BWWP2PZ1", "BW2XDRNSCCPZ", "BSZM480TSWGP", "BRGPD72KHM3Q", "C3KLDKZBHNCZ", "C3HQKX3B35PD", "C2N9CS4FS1QR", "C0X2HNVH08FB", "9NBLGGH51QT4", "BPBC39LH0Q9B", "BVV8LHVGPBS3", "BWC95BZPFBS7", "BXL4538LK4DK", "BQMVWCMB8P59", "C2BTFXNW3TTT", "9P4WKZXWP1QW", "BRJGPRMBV1NT"]
        specialexclusives = ["9P5SL4LDLMG3"];
        // games excluded in particular locale
        locExclusions = ["9NT4X7P8B9NB:ja-jp", "9PDV8FKWP3B4:ja-jp", "BZJH12CJ6N3R:ja-jp", "C3FXTTH4NFQN:ja-jp", "BRXK34KJJXH8:ja-jp", "C1TBCX541JW7:ja-jp", "BSD19LV8DMRN:ja-jp"];
        for (var i = 0; i < locExclusions.length; i++) {
            var thegame = locExclusions[i].split(":")[0];
            var theloc = locExclusions[i].split(":")[1];
            if (urlRegion === theloc) {
                fullGameArray = fullGameArray.filter(function(v) { return v !== thegame });
            }
        }
        // games only included in particular locale
        var locInclusions = ["9NLM45C6729Z:ja-jp"];
        for (var i = 0; i < locInclusions.length; i++) {
            var thegame = locInclusions[i].split(":")[0];
            var theloc = locInclusions[i].split(":")[1];
            if (urlRegion !== theloc) {
                fullGameArray = fullGameArray.filter(function(v) { return v !== thegame });
            }
        }
        //end overrides
        pageloadfocus = 0;
        entrycat = false;
  
        var uri = new URL(document.URL);
        var urlRegion = uri.pathname.slice(1,6).toLowerCase();
        ratingorg = regionRatingOrgs[urlRegion];
  
        regionContent = globalContent.locales[urlRegion];
  
        var allKeys = Object.keys(regionContent)
        var keysLength = allKeys.length
  
        setTimeout(function() {
            for (var i = 0; i < keysLength; i++) {
                if (allKeys[i].indexOf("keyCopy") !== -1) {
                    $("[data-loc-copy=" + allKeys[i] + "]").text(regionContent[allKeys[i]]);
                } else if (allKeys[i].indexOf("keyImage") !== -1) {
                    $("source[data-loc-image=" + allKeys[i] + "]").attr("srcset", regionContent[allKeys[i]]);
                    $("img[data-loc-image=" + allKeys[i] + "]").attr("srcset", regionContent[allKeys[i]]).attr("srcset", regionContent[allKeys[i]]);
                } else if (allKeys[i].indexOf("keyAlt") !== -1) {
                    $("[data-loc-alt=" + allKeys[i] + "]").attr("alt", regionContent[allKeys[i]]);
                } else if (allKeys[i].indexOf("keyLink") !== -1) {
                    $("[data-loc-link=" + allKeys[i] + "]").attr("href", regionContent[allKeys[i]]);
                } else if (allKeys[i].indexOf("keyRetailer") !== -1) {
                    $("[data-loc-retailer=" + allKeys[i] + "]").attr("data-retailer", regionContent[allKeys[i]]);
                } else if (allKeys[i].indexOf("keyAria") !== -1) {
                    $("[data-loc-aria=" + allKeys[i] + "]").attr("aria-label", regionContent[allKeys[i]]);
                } else if (allKeys[i].indexOf("keyInclude") !== -1) {
                    $("[data-loc-include=" + allKeys[i] + "]").attr("data-region-include", regionContent[allKeys[i]]);
                } else if (allKeys[i].indexOf("keyExclude") !== -1) {
                    $("[data-loc-exclude=" + allKeys[i] + "]").attr("data-region-exclude", regionContent[allKeys[i]]);
                } else if (allKeys[i].indexOf("keyPlayson") !== -1) {
                    $("[data-loc-playson=" + allKeys[i] + "]").attr("data-playson", regionContent[allKeys[i]].toLowerCase());
                }
            }
            GUID_pop(fullGameArray);
        }, 650);
        // special needs for page
  
  
        $(".xghsearch input").attr("placeholder", regionContent["keyAriasearchplaceholder"]);

  
    }
  
    function GUID_pop(rawGuids) {
        var chunktotal = Math.ceil(fullGameArray.length / 20)
        console.log("running guid_pop: " + fullGameArray.length)
        var countryCode = urlRegion.split("-")[1].toUpperCase();
        var guidUrl = 'https://displaycatalog.mp.microsoft.com/v7.0/products?bigIds=GAMEIDS&market=' + countryCode + '&languages=' + urlRegion + '&MS-CV=DGU1mcuYo0WMMp+F.1'
  
        var first12 = rawGuids.slice(0, 12)
        rawGuids = rawGuids.slice(12)
  
        var firstToUrl = first12.join(",");
        guidUrl = guidUrl.replace("GAMEIDS", firstToUrl)
        $.get(guidUrl)
            .done(function(responseData) {
                var apiData = responseData;
                populate(apiData, 0, firstToUrl);
                guidUrl = 'https://displaycatalog.mp.microsoft.com/v7.0/products?bigIds=GAMEIDS&market=' + countryCode + '&languages=' + urlRegion + '&MS-CV=DGU1mcuYo0WMMp+F.1'
                restPop();
            })
  
        function restPop() {
            var m, n, temparray, chunk = 20;
            var arrayCount = 1
            for (m = 0, n = rawGuids.length; m < n; m += chunk) {
                (function(m, n) {
                    temparray = rawGuids.slice(m, m + chunk);
                    var guidsToUrl = temparray.join(",");
                    guidUrl = guidUrl.replace("GAMEIDS", guidsToUrl)
  
                    $.get(guidUrl)
                        .done(function(responseData) {
                            var apiData = responseData;
                            populate(apiData, arrayCount, guidsToUrl);
                            arrayCount++
                        })
                    guidUrl = 'https://displaycatalog.mp.microsoft.com/v7.0/products?bigIds=GAMEIDS&market=' + countryCode + '&languages=' + urlRegion + '&MS-CV=DGU1mcuYo0WMMp+F.1'
                })(m, n);
            }
        }

        var popcounter = 0;
        var bigidUrls = biUrls.items.urls;
        var biuArray = Object.keys(bigidUrls);
        allGames = {};
        allGamesExcludes = [];
        gameIdArrays["exclusives"] = [];
        gameIdArrays["multiplayer"] = [];
        gameIdArrays["kidsfamily"] = [];
  
        selectedGames = [];
        prunedGames = [];
        shownGames = [];

        var locgamesremoved = 0;

        function populate(data, count, bigidsgiven) {
            var productQuantity = data.Products.length;
  
            bigidsgiven = bigidsgiven.split(",");
            var allprodids = [];
            for (var s = 0; s < productQuantity; s++) {
                allprodids.push(data.Products[s].ProductId);
            }
            var eliminated = [];
            eliminated = bigidsgiven.filter(function(v) { return allprodids.indexOf(v) === -1 });
  
            for (var w = 0; w < eliminated.length; w++) {
                locgamesremoved++
                var idind = fullGameArray.indexOf(eliminated[w]);
                if (idind !== -1) { fullGameArray.splice(idind, 1); }
                var idind1 = gameIdArrays["HDRGaming"].indexOf(eliminated[w]);
                if (idind1 !== -1) { gameIdArrays["HDRGaming"].splice(idind1, 1); }
                var idind2 = gameIdArrays["topfree"].indexOf(eliminated[w]);
                if (idind2 !== -1) { gameIdArrays["topfree"].splice(idind2, 1); }
                var idind3 = gameIdArrays["enhanced"].indexOf(eliminated[w]);
                if (idind3 !== -1) { gameIdArrays["enhanced"].splice(idind3, 1); }
                var idind4 = gameIdArrays["fourk"].indexOf(eliminated[w]);
                if (idind4 !== -1) { gameIdArrays["fourk"].splice(idind4, 1); }
                var idind5 = gameIdArrays["xpa"].indexOf(eliminated[w]);
                if (idind5 !== -1) { gameIdArrays["xpa"].splice(idind5, 1); }
                var idind6 = gameIdArrays["exclusives"].indexOf(eliminated[w]);
                if (idind6 !== -1) { gameIdArrays["exclusives"].splice(idind6, 1); }
                var idind7 = gameIdArrays["kidsfamily"].indexOf(eliminated[w]);
                if (idind7 !== -1) { gameIdArrays["kidsfamily"].splice(idind7, 1); }
                var idind8 = gameIdArrays["newreleases"].indexOf(eliminated[w]);
                if (idind8 !== -1) { gameIdArrays["newreleases"].splice(idind8, 1); }
                var idind9 = gameIdArrays["multiplayer"].indexOf(eliminated[w]);
                if (idind9 !== -1) { gameIdArrays["multiplayer"].splice(idind9, 1); }
                var idind10 = gameIdArrays["upcoming"].indexOf(eliminated[w]);
                if (idind10 !== -1) { gameIdArrays["upcoming"].splice(idind10, 1); }
                var idind11 = gameIdArrays["cloud"].indexOf(eliminated[w]);
                if (idind11 !== -1) { gameIdArrays["cloud"].splice(idind11, 1); }
                var idind12 = gameIdArrays["onsale"].indexOf(eliminated[w]);
                if (idind12 !== -1) { gameIdArrays["onsale"].splice(idind12, 1); }
                var idind14 = gameIdArrays["mostplayed"].indexOf(eliminated[w]);
                if (idind14 !== -1) { gameIdArrays["mostplayed"].splice(idind14, 1); }
            }
  
            for (var t = 0; t < allprodids.length; t++) {
                var excludetest = false;
                var producttest = data.Products[t];
                var excludeit404 = 0;
                var excludeitpurch = 0;
                producttest.DisplaySkuAvailabilities.forEach(function(d) {
                        d.Availabilities.forEach(function(av) {
                            if (av.Actions.indexOf("Purchase") !== -1) {
                                excludeit404 += 1;
                                excludeitpurch += 1;
                            }
                            if (av.Actions.indexOf("Details") !== -1) {
                                excludeit404 += 1;
                            }
                        })
                    })
                if (excludeitpurch === 0) {
                    excludetest = true;
                }
  
                if (excludetest === true) {
                    allGamesExcludes.push(allprodids[t]);
                    console.log("NOTE: BigID " + allprodids[t] + " unavailable to buy in this locale. Removing from game lists.");
                    locgamesremoved++
                    popcounter--
                    var idind = fullGameArray.indexOf(allprodids[t]);
                    if (idind !== -1) { fullGameArray.splice(idind, 1); }
                    var idind1 = gameIdArrays["HDRGaming"].indexOf(allprodids[t]);
                    if (idind1 !== -1) { gameIdArrays["HDRGaming"].splice(idind1, 1); }
                    var idind2 = gameIdArrays["topfree"].indexOf(allprodids[t]);
                    if (idind2 !== -1) { gameIdArrays["topfree"].splice(idind2, 1); }
                    var idind3 = gameIdArrays["enhanced"].indexOf(allprodids[t]);
                    if (idind3 !== -1) { gameIdArrays["enhanced"].splice(idind3, 1); }
                    var idind4 = gameIdArrays["fourk"].indexOf(allprodids[t]);
                    if (idind4 !== -1) { gameIdArrays["fourk"].splice(idind4, 1); }
                    var idind5 = gameIdArrays["xpa"].indexOf(allprodids[t]);
                    if (idind5 !== -1) { gameIdArrays["xpa"].splice(idind5, 1); }
                    var idind6 = gameIdArrays["exclusives"].indexOf(allprodids[t]);
                    if (idind6 !== -1) { gameIdArrays["exclusives"].splice(idind6, 1); }
                    var idind7 = gameIdArrays["kidsfamily"].indexOf(allprodids[t]);
                    if (idind7 !== -1) { gameIdArrays["kidsfamily"].splice(idind7, 1); }
                    var idind8 = gameIdArrays["newreleases"].indexOf(allprodids[t]);
                    if (idind8 !== -1) { gameIdArrays["newreleases"].splice(idind8, 1); }
                    var idind9 = gameIdArrays["multiplayer"].indexOf(allprodids[t]);
                    if (idind9 !== -1) { gameIdArrays["multiplayer"].splice(idind9, 1); }
                    var idind10 = gameIdArrays["upcoming"].indexOf(allprodids[t]);
                    if (idind10 !== -1) { gameIdArrays["upcoming"].splice(idind10, 1); }
                    var idind11 = gameIdArrays["cloud"].indexOf(allprodids[t]);
                    if (idind11 !== -1) { gameIdArrays["cloud"].splice(idind11, 1); }
                    var idind12 = gameIdArrays["onsale"].indexOf(allprodids[t]);
                    if (idind12 !== -1) { gameIdArrays["onsale"].splice(idind12, 1); }
                    // var idind13 = gameIdArrays["physical"].indexOf(allprodids[t]);
                    // if (idind13 !== -1) { gameIdArrays["physical"].splice(idind13, 1); }
                    var idind14 = gameIdArrays["mostplayed"].indexOf(allprodids[t]);
                    if (idind14 !== -1) { gameIdArrays["mostplayed"].splice(idind14, 1); }
                }
            }
  
            for (var i = 0; i < productQuantity; i++) {
                var itemId = data.Products[i].ProductId.toUpperCase();
                var descriptionSizeLimit = 300;
  
                var itemTitle = data.Products[i].LocalizedProperties[0].ProductTitle;
                if (itemTitle === undefined) {
                    itemTitle = "";
                }
                var titleClickname = itemTitle.toLowerCase().replace(/\s/g, "-").replace(/[^a-z0-9-]/gi, '');
                if (titleClickname === "") {
                    titleClickname = "-";
                }
  
                var shortdesc = data.Products[i].LocalizedProperties[0].ShortDescription;
                if (shortdesc === "") {
                    shortdesc = data.Products[i].LocalizedProperties[0].ProductDescription;
                }
                if (shortdesc === undefined) {
                    shortdesc = "";
                }
  
                if (shortdesc && (shortdesc.length > descriptionSizeLimit)) { // This should trim the description to prevent overflow
                    for (var j = descriptionSizeLimit; j > 0; j--) {
                        var curChar = shortdesc.charAt(j);
                        if (curChar == '.' || curChar == '?' || curChar == "!") {
                            shortdesc = shortdesc.substring(0, j + 1);
                            break;
                        }
                    }
                }
                // determine physical or download
                // if (gameIdArrays["physical"].indexOf(itemId) !== -1) {
                //   var phys = "true";
                // } else {
                var phys = "false";
                // }
  
                // get boxshot
                if (phys === "false" && data.Products[i].LocalizedProperties[0].Images !== undefined) {
                    var imagesNum = data.Products[i].LocalizedProperties[0].Images.length;
                    var imageInd = 999;
                    for (var j = 0; j < imagesNum; j++) {
                        if (data.Products[i].LocalizedProperties[0].Images[j].ImagePurpose === "Poster") { // boxshots BrandedKeyArt
                            imageInd = j;
                            break;
                        }
                    }
                    if (imageInd === 999) {
                        for (var j = 0; j < imagesNum; j++) {
                            if (data.Products[i].LocalizedProperties[0].Images[j].Width < data.Products[i].LocalizedProperties[0].Images[j].Height) {
                                imageInd = j;
                                break;
                            }
                        }
                    }
                    if (imageInd === 999) {
                        imageInd = 1
                    }
                    if (data.Products[i].LocalizedProperties[0].Images[imageInd]) {
                        var itemBoxshot = data.Products[i].LocalizedProperties[0].Images[imageInd].Uri.replace("http:", "https:");
                        var itemBoxshotSmall;
                    } else {
                        var itemBoxshot = "https://assets.xboxservices.com/assets/98/89/98892da6-cd9f-49da-8bb5-e6753a2f9cd9.jpg?n=X1-Standard-digital-boxshot_584x800.jpg";
                        var itemBoxshotSmall = "https://assets.xboxservices.com/assets/98/89/98892da6-cd9f-49da-8bb5-e6753a2f9cd9.jpg?n=X1-Standard-digital-boxshot_584x800.jpg";
                    }
                    if (itemBoxshot.indexOf("store-images") !== -1) {
                        itemBoxshotSmall = itemBoxshot + "?w=140";
                        // itemBoxshot = itemBoxshot + "&h=300&w=200&format=jpg";
                        itemBoxshot = itemBoxshot + "?w=200";
                    } else {
                        itemBoxshotSmall = itemBoxshot;
                    }
                } else if (phys === "true" && data.Products[i].LocalizedProperties[0].Images !== undefined) {
                    var imagesNum = data.Products[i].LocalizedProperties[0].Images.length;
                    var imageInd = 999;
                    for (var j = 0; j < imagesNum; j++) {
                        if (data.Products[i].LocalizedProperties[0].Images[j].ImagePurpose === "Poster") {
                            imageInd = j;
                            break;
                        }
                    }
                    if (data.Products[i].LocalizedProperties[0].Images[imageInd]) {
                        var itemBoxshot = data.Products[i].LocalizedProperties[0].Images[imageInd].Uri.replace("http:", "https:");
                        var itemBoxshotSmall;
                    } else {
                        if (data.Products[i].LocalizedProperties[0].Images[0]) {
                            if (data.Products[i].LocalizedProperties[0].Images[0].Uri.toLowerCase().indexOf("s-microsoft") === -1) {
                                var itemBoxshot = data.Products[i].LocalizedProperties[0].Images[0].Uri.replace("http:", "https:") + "&w=231&h=197&q=90&m=6&b=%23FFFFFFFF&o=f";
                            } else {
                                var itemBoxshot = data.Products[i].LocalizedProperties[0].Images[0].Uri.replace("http:", "https:")
                            }
                            var itemBoxshotSmall = itemBoxshot;
                        } else {
                            var itemBoxshot = "https://assets.xboxservices.com/assets/98/89/98892da6-cd9f-49da-8bb5-e6753a2f9cd9.jpg?n=X1-Standard-digital-boxshot_584x800.jpg";
                            var itemBoxshotSmall = "https://assets.xboxservices.com/assets/98/89/98892da6-cd9f-49da-8bb5-e6753a2f9cd9.jpg?n=X1-Standard-digital-boxshot_584x800.jpg";
                        }
                    }
                } else {
                    var itemBoxshot = "https://assets.xboxservices.com/assets/98/89/98892da6-cd9f-49da-8bb5-e6753a2f9cd9.jpg?n=X1-Standard-digital-boxshot_584x800.jpg";
                    var itemBoxshotSmall = "https://assets.xboxservices.com/assets/98/89/98892da6-cd9f-49da-8bb5-e6753a2f9cd9.jpg?n=X1-Standard-digital-boxshot_584x800.jpg";
                }
  
                // get screenshot
                if (phys === "false" && data.Products[i].LocalizedProperties[0].Images !== undefined) {
                    var imagesNum = data.Products[i].LocalizedProperties[0].Images.length;
                    var imageInd = 1;
                    for (var j = 0; j < imagesNum; j++) {
                        var im = data.Products[i].LocalizedProperties[0].Images[j];
                        if ((im.ImagePurpose === "ImageGallery" || im.ImagePurpose === "Screenshot") && (im.Height < im.Width)) {
                            imageInd = j;
                            break;
                        }
                    }
                    if (data.Products[i].LocalizedProperties[0].Images[imageInd]) {
                        var itemScreenshot = data.Products[i].LocalizedProperties[0].Images[imageInd].Uri.replace("http:", "https:");
                    } else {
                        var itemScreenshot = "https://assets.xboxservices.com/assets/98/89/98892da6-cd9f-49da-8bb5-e6753a2f9cd9.jpg?n=X1-Standard-digital-boxshot_584x800.jpg";
                    }
                    if (itemScreenshot.indexOf("xboxlive.com") !== -1) {
                        itemScreenshot = itemScreenshot + "&w=480&format=jpg";
                    }
                } else {
                    if (data.Products[i].LocalizedProperties[0].Images !== undefined && data.Products[i].LocalizedProperties[0].Images[0]) {
                        var itemScreenshot = data.Products[i].LocalizedProperties[0].Images[0].Uri.replace("http:", "https:") + "&w=231&h=197&q=90&m=6&b=%23FFFFFFFF&o=f";
                    } else {
                        var itemScreenshot = "https://assets.xboxservices.com/assets/98/89/98892da6-cd9f-49da-8bb5-e6753a2f9cd9.jpg?n=X1-Standard-digital-boxshot_584x800.jpg";
                    }
                }
  
                // get screenshot array
                var ssarray = [];
                var superheroart = "";
                if (phys === "false" && data.Products[i].LocalizedProperties[0].Images !== undefined) {
                    var imagesNum = data.Products[i].LocalizedProperties[0].Images.length;
                    var sslimit = 5;
                    var imageInd = 1;
                    for (var j = 0; j < imagesNum; j++) {
                        var im = data.Products[i].LocalizedProperties[0].Images[j];
                        if ((im.ImagePurpose.toLowerCase() === "imagegallery" || im.ImagePurpose.toLowerCase() === "screenshot") && (im.Height < im.Width)) {
                            if (im.Uri.indexOf("xboxlive.com") !== -1) {
                                var ssimg = im.Uri.replace("http:", "https:") + "&w=980&format=jpg";
                            } else {
                                var ssimg = im.Uri.replace("http:", "https:");
                            }
                            if (ssarray.length < sslimit) {
                                // if (ssarray.indexOf(ssimg) === -1 && omitimages.indexOf(ssimg) === -1) {
                                //     ssarray.push(ssimg);
                                // }
                            } else {
                                break;
                            }
                        } else if (im.ImagePurpose.toLowerCase() === "superheroart") {
                            if (im.Uri.indexOf("xboxlive.com") !== -1) {
                                var shimg = im.Uri.replace("http:", "https:") + "&w=980&format=jpg";
                            } else {
                                var shimg = im.Uri.replace("http:", "https:");
                            }
                            //console.log("keyart = " + kaimg);
                            superheroart = shimg;
                    }
                }
            }
  
  
                var releaseDate = data.Products[i].MarketProperties[0].OriginalReleaseDate;
                if (releaseDate === undefined) {
                    releaseDate = 0;
                }
                var msproduct = data.Products[i].IsMicrosoftProduct;
                if (specialexclusives.indexOf(itemId) !== -1) {
                    msproduct = true;
                }
                var multiplayer = "false";
                var coop = "false";
                var mptest = data.Products[i].Properties;
                if (mptest.Attributes) {
                    for (var n = 0; n < mptest.Attributes.length; n++) {
                        if (mptest.Attributes[n].Name.toLowerCase().indexOf("multiplayer") !== -1) {
                            multiplayer = "true";
                        }
                        if (mptest.Attributes[n].Name.toLowerCase().indexOf("coop") !== -1) {
                            coop = "true";
                        }
                    }
                }
  
                //get prices
                var listprice;
                var msrpprice;
                var currencycode;
                var onsale = "false";
                var gwg = "false";
                var golddiscount = "false"; // deals with gold ... and gold member sale prices?
                var goldandsilversale = "false";
                var goldandsilversalegoldprice = 100000000;
                var specialprice = 100000000;
                var eaaccessgame = "false";
                var gamepassgame = "false";
                var purchasable = "false";
                var tempea = "false"
                var tempgs = "false";
                var goldaffids = [];
                var platxbox = "false";
                var platpc = "false";
                var platxo = "false";
                var platxsx = "false";
                var plat360 = "false";
                var silversaleperc = "0%";
                var goldandsilversalegoldperc = "0%";
  
                if (phys === "false") {
                    if (data.Products[i].LocalizedProperties[0].EligibilityProperties !== null && data.Products[i].LocalizedProperties[0].EligibilityProperties !== undefined &&
                        data.Products[i].LocalizedProperties[0].EligibilityProperties !== "undefined") {
                        if (data.Products[i].LocalizedProperties[0].EligibilityProperties.Affirmations.length > 0) {
                            data.Products[i].LocalizedProperties[0].EligibilityProperties.Affirmations.forEach(function(aff) {
                                if (aff.Description.toLowerCase().indexOf("ea access") !== -1) {
                                    tempea = "true";
                                }
                                if (aff.Description.toLowerCase().indexOf("game pass") !== -1) {
                                    gamepassgame = "true";
                                }
                                if (aff.Description.toLowerCase().indexOf("gold") !== -1) {
                                    tempgs = "true";
                                    goldaffids.push(aff.AffirmationProductId);
                                }
                            })
                        }
                    }
                    data.Products[i].DisplaySkuAvailabilities.forEach(function(sku) {
                        var purchnum = 0;
                        sku.Availabilities.forEach(function(av, ind) {
                            if (av.Actions.indexOf("Purchase") !== -1) {
                                purchasable = "true";
                                purchnum++;
                                if (purchnum > 1 && tempgs === "true" && av.RemediationRequired === true && goldaffids.indexOf(av.Remediations[0].BigId) !== -1) {
                                    goldandsilversale = "true";
                                }
                                // get platform info
                                av.Conditions.ClientConditions.AllowedPlatforms.forEach(function(plat) {
                                    if (plat.PlatformName === "Windows.Xbox") {
                                        platxbox = "true";
                                    }
                                    if (plat.PlatformName === "Windows.Desktop") {
                                        platpc = "true";
                                    }
                                })
                            }
                            if (av.Actions.indexOf("Purchase") !== -1 && (av.OrderManagementData.Price.MSRP !== 0 || (av.OrderManagementData.Price.MSRP === 0 && av.OrderManagementData.Price.ListPrice === 0)) &&
                                sku.Sku.Properties.IsTrial === false) {
                                if ((av.OrderManagementData.Price.ListPrice !== av.OrderManagementData.Price.MSRP || (av.OrderManagementData.Price.MSRP === 0 && av.OrderManagementData.Price.ListPrice === 0)) && ind !== 0) {
                                    specialprice = av.OrderManagementData.Price.ListPrice;
                                } else {
                                    listprice = av.OrderManagementData.Price.ListPrice;
                                }
                                if (ind === 0) {
                                    msrpprice = av.OrderManagementData.Price.MSRP;
                                }
                                if ((specialprice !== msrpprice) && gamepassgame === "true") {
                                    goldandsilversale = "true";
                                }
                                currencycode = av.OrderManagementData.Price.CurrencyCode;
                                if (av.Properties.MerchandisingTags !== undefined) {
                                    if (av.Properties.MerchandisingTags.indexOf("LegacyGamesWithGold") !== -1) {
                                        gwg = "true";
                                        goldandsilversale = "true";
                                        specialprice = listprice;
                                        listprice = msrpprice;
                                    }
                                    if (av.Properties.MerchandisingTags.indexOf("LegacyDiscountGold") !== -1) {
                                        golddiscount = "true";
                                        goldandsilversalegoldprice = av.OrderManagementData.Price.ListPrice;
                                        var golddiff = msrpprice - goldandsilversalegoldprice;
                                        goldandsilversalegoldperc = Math.round(golddiff / msrpprice * 100).toString() + "%";
                                    }
                                }
                                if (goldandsilversale === "true" && av.DisplayRank === 1) {
                                    goldandsilversalegoldprice = av.OrderManagementData.Price.ListPrice;
                                    var golddiff = msrpprice - goldandsilversalegoldprice;
                                    goldandsilversalegoldperc = Math.round(golddiff / msrpprice * 100).toString() + "%";
                                }
                                if (tempea === "true" && av.Actions.length === 2) {
                                    eaaccessgame = "true";
                                }
                                if (gameIdArrays["onsale"].indexOf(itemId) !== -1) {
                                    onsale = "true";
                                }
                                if (listprice < msrpprice || specialprice < msrpprice) {
                                  var listdiff = msrpprice - listprice;
                                  silversaleperc = Math.round(listdiff / msrpprice * 100).toString() + "%";
                                }
                            }
                        })
                    })
  
                    if (platxbox === "true") {
                        if (data.Products[i].Properties.XboxConsoleGenCompatible === null) {
                            platxo = "true";
                            platxsx = "true";
                        } else if (data.Products[i].Properties.XboxConsoleGenCompatible === undefined) {
                            platxo = "true";
                        } else if (data.Products[i].Properties.XboxConsoleGenCompatible.length === 2) {
                            platxo = "true";
                            platxsx = "true";
                        } else if (data.Products[i].Properties.XboxConsoleGenCompatible[0] === "ConsoleGen8") {
                            platxo = "true";
                        } else if (data.Products[i].Properties.XboxConsoleGenCompatible[0] === "ConsoleGen9") {
                            platxsx = "true";
                        }
                      }
  
                } else {
                    data.Products[i].DisplaySkuAvailabilities.forEach(function(sku) {
                        sku.Availabilities.forEach(function(av) {
                            if (av.Actions.indexOf("Purchase") !== -1 && av.Actions.indexOf("Browse") !== -1 && (av.OrderManagementData.Price.MSRP !== 0 || (av.OrderManagementData.Price.MSRP === 0 && av.OrderManagementData.Price.ListPrice === 0)) && av.Actions.length > 2) {
                                listprice = av.OrderManagementData.Price.ListPrice;
                                msrpprice = av.OrderManagementData.Price.MSRP;
                                currencycode = av.OrderManagementData.Price.CurrencyCode;
                                // if (listprice < msrpprice) { 
                                //   onsale = "true";
                                //   if (gameIdArrays["onsale"].indexOf(itemId) === -1) {
                                //     gameIdArrays["onsale"].push(itemId); 
                                //   }
                                // }
                                if (gameIdArrays["onsale"].indexOf(itemId) !== -1) {
                                    onsale = "true";
                                }
                            }
                        })
                    })
                }
  
  
                if (listprice === undefined) {
                    console.log("NOTE: BigID " + itemId + " has no price information.");
                    listprice = 100000000;
                    msrpprice = 100000000;
                    currencycode = "USD";
                }
                var rating = "none";
                var ratingUrl = "https://www.esrb.org/";
                var ratingcode = "";
                var ratingage = 99;
                var ratingsystem = "none";
                var kidfamilyratings = ["ESRB:T", "ESRB:E10", "ESRB:E", "PEGI:3", "PEGI:7", "PEGI:12", "COB-AU:G", "COB-AU:PG", "OFLC-NZ:G", "OFLC-NZ:PG", "OFLC-NZ:R13", "USK:Everyone", "USK:6", "USK:12",
                    "PCBP:0", "PCBP:6", "PCBP:12", "DJCTQ:L", "DJCTQ:10", "DJCTQ:12", "DJCTQ:14", "CSRR:G", "CSRR:PG12", "CSRR:PG15"
                ]
                var rawdescriptors = "none";
                var rawinteractive = "none";
                var rawdisclaimers = "none";
                var pegiFallbackRegions = "en-za ,";
                var iarcFallbackRegions = "ja-jp ,";
                
                var cr = 99;
                var cresrb = 99;
                var crfallback = 0;
                var crfallback_PEGI = -1;
                var crfallback_IARC = -1;
                if (data.Products[i].MarketProperties[0].ContentRatings !== undefined && data.Products[i].MarketProperties[0].ContentRatings !== null && data.Products[i].MarketProperties[0].ContentRatings.length > 0) {
                  for (var c = 0; c < data.Products[i].MarketProperties[0].ContentRatings.length; c++) {
                    // if (data.Products[i].MarketProperties[0].ContentRatings[c].RatingSystem === "ESRB") {
                    //   cresrb = c;
                    // }
                    if (data.Products[i].MarketProperties[0].ContentRatings[c].RatingSystem === "Microsoft") { // Microsoft rating is fallback
                      crfallback = c;
                    }
                    if ((pegiFallbackRegions.includes(urlRegion)) && data.Products[i].MarketProperties[0].ContentRatings[c].RatingSystem === "PEGI") { // PEGI fallback for en-za
                        crfallback_PEGI = c;
                      }
                    if ((iarcFallbackRegions.includes(urlRegion)) && data.Products[i].MarketProperties[0].ContentRatings[c].RatingSystem === "IARC") { // PEGI fallback for en-za
                        crfallback_IARC = c;
                    }
                    if (data.Products[i].MarketProperties[0].ContentRatings[c].RatingSystem === ratingorg) {
                      cr = c;
                    }
                    
                  }
                  if (cr === 99) { cr = cresrb } // if region's rating system is not found, use esrb
                  if (cr === 99) { cr = crfallback } // fallback if no esrb either
                  if ((pegiFallbackRegions.includes(urlRegion)) && crfallback_PEGI !== -1 && cr === crfallback) { cr = crfallback_PEGI } // fallback if pegi needed
                  if ((iarcFallbackRegions.includes(urlRegion)) && crfallback_IARC !== -1 && cr === crfallback) { cr = crfallback_IARC } // fallback if iarc needed  
                  ratingsystem = data.Products[i].MarketProperties[0].ContentRatings[cr].RatingSystem;
                  ratingcode = data.Products[i].MarketProperties[0].ContentRatings[cr].RatingId;
                  var ratimage = ratingData.RatingBoards[ratingsystem].Ratings[ratingcode].LocalizedProperties[0].LogoUrl;
                  ratingage = ratingData.RatingBoards[ratingsystem].Ratings[ratingcode].Age;
                  rating = ratingData.RatingBoards[ratingsystem].Ratings[ratingcode].LocalizedProperties[0].LongName;
                  ratingUrl = ratingData.RatingBoards[ratingsystem].LocalizedProperties[0].Url;
                  
                  if (kidfamilyratings.indexOf(rating) !== -1) {
                      gameIdArrays["kidsfamily"].push(itemId);
                  }
                  rawdescriptors = data.Products[i].MarketProperties[0].ContentRatings[cr].RatingDescriptors.join(",");
                  rawinteractive = data.Products[i].MarketProperties[0].ContentRatings[cr].InteractiveElements.join(",");
                  rawdisclaimers = data.Products[i].MarketProperties[0].ContentRatings[cr].RatingDisclaimers.join(",");
                }
  
                if (urlRegion === "ja-jp" || urlRegion === "ko-kr") {
                    $(".c-label[data-game='kids and family']").remove()
                }
  
                var itemhref = 'https://www.xbox.com/' + urlRegion + '/games/store/' + titleClickname + '/' + itemId;

  
                var avgstars = 0;
                var ratingcount = 0;
                if (data.Products[i].MarketProperties[0].UsageData[0]) {
                    avgstars = data.Products[i].MarketProperties[0].UsageData[0].AverageRating;
                    ratingcount = data.Products[i].MarketProperties[0].UsageData[0].RatingCount;
                }
  
                // custom boxshots
                if (itemId === "9NBLGGH1Z6FQ") {
                    itemBoxshot = "https://assets.xboxservices.com/assets/77/5e/775ea961-c0c2-4020-a8ce-a6f938812aee.jpg?n=ReCore_Boxshot-digital-X1_294x215.jpg";
                    itemBoxshotSmall = "https://assets.xboxservices.com/assets/77/5e/775ea961-c0c2-4020-a8ce-a6f938812aee.jpg?n=ReCore_Boxshot-digital-X1_294x215.jpg";
                }
                if (itemId === "BZFK7WNK7R4M") {
                    itemBoxshot = "https://images-eds-ssl.xboxlive.com/image?url=8Oaj9Ryq1G1_p3lLnXlsaZgGzAie6Mnu24_PawYuDYIoH77pJ.X5Z.MqQPibUVTc6LYEXhNheFwp2halN6MiJq0hK8tHwcOslhHzFcqc.uw90wjv2YtwC_mZJs.lEh1cto.K33xsXgRNctiGCKrDjVsG9PhS5GzkLXFMF5wlXsJAfaI6.Hc6zR2KrB00Sjgkn0kvJZv.PD1.7g.ytDgP368SN3vocTlHhhyS_BQ8qZs-&w=200&format=jpg";
                    itemBoxshotSmall = "https://images-eds-ssl.xboxlive.com/image?url=8Oaj9Ryq1G1_p3lLnXlsaZgGzAie6Mnu24_PawYuDYIoH77pJ.X5Z.MqQPibUVTc6LYEXhNheFwp2halN6MiJq0hK8tHwcOslhHzFcqc.uw90wjv2YtwC_mZJs.lEh1cto.K33xsXgRNctiGCKrDjVsG9PhS5GzkLXFMF5wlXsJAfaI6.Hc6zR2KrB00Sjgkn0kvJZv.PD1.7g.ytDgP368SN3vocTlHhhyS_BQ8qZs-&w=200&format=jpg";
                }
                if (itemId === "C2320MJQP0MS") {
                    itemBoxshot = "https://assets.xboxservices.com/assets/69/9b/699b5006-9996-4d3b-b44f-119ddf8c954f.jpg?n=DwG_Boxshot-digital-X1_Plants-Vs-Zombies-Deluxe_584x800.jpg";
                    itemBoxshotSmall = "https://assets.xboxservices.com/assets/69/9b/699b5006-9996-4d3b-b44f-119ddf8c954f.jpg?n=DwG_Boxshot-digital-X1_Plants-Vs-Zombies-Deluxe_584x800.jpg";
                }
  
                // genres
                if (data.Products[i].Properties.Categories !== undefined && data.Products[i].Properties.Categories !== null) {
                    var gamegenres = data.Products[i].Properties.Categories.join(", ").toLowerCase();
                } else if (data.Products[i].Properties.Category !== undefined && data.Products[i].Properties.Category !== null) {
                    var gamegenres = data.Products[i].Properties.Category.toLowerCase();
                } else {
                    var gamegenres = "unlisted";
                }
  
                allGames[itemId] = {
                    releasedate: releaseDate,
                    msproduct: msproduct,
                    multiplayer: multiplayer,
                    coop: coop,
                    rating: rating,
                    ratingUrl: ratingUrl,
                    ratimage: ratimage,
                    ratingage: ratingage,
                    ratingsystem: ratingsystem,
                    gameurl: itemhref,
                    titleclickname: titleClickname,
                    boxshot: itemBoxshot,
                    boxshotsmall: itemBoxshotSmall,
                    title: itemTitle,
                    msrpprice: msrpprice,
                    listprice: listprice,
                    currencycode: currencycode,
                    onsale: onsale,
                    upcoming: "false",
                    newrelease: "false",
                    physical: phys,
                    genres: gamegenres,
                    screenshot: itemScreenshot,
                    descriptors: rawdescriptors,
                    interactive: rawinteractive,
                    disclaimers: rawdisclaimers,
                    stars: avgstars,
                    starcount: ratingcount,
                    screenarray: ssarray,
                    superheroart: superheroart,
                    description: shortdesc,
                    gameswithgold: gwg,
                    golddiscount: golddiscount,
                    goldandsilversale: goldandsilversale,
                    goldandsilversalegoldprice: goldandsilversalegoldprice,
                    specialprice: specialprice,
                    eaaccessgame: eaaccessgame,
                    gamepassgame: gamepassgame,
                    purchasable: purchasable,
                    platformxbox: platxbox,
                    platformpc: platpc,
                    platformxo: platxo,
                    platformxsx: platxsx,
                    platform360: plat360,
                    silversaleperc: silversaleperc,
                    goldandsilversalegoldperc: goldandsilversalegoldperc
                };

                //make API-provided lists  
                if (allGamesExcludes.indexOf(itemId) === -1) {
                    if (msproduct === true) {
                        gameIdArrays["exclusives"].push(itemId);
                    }
                    if (multiplayer === "true") {
                        gameIdArrays["multiplayer"].push(itemId);
                    }
                    var reldate = new Date(releaseDate);
                    // if (reldate > nowdate && itemId !== "9NBLGGH51QT4") {
                    //   gameIdArrays["upcoming"].push(itemId);
                    //   allGames[itemId]["upcoming"] = "true";
                    // }
                    if (gameIdArrays["upcoming"].indexOf(itemId) !== -1) {
                        allGames[itemId]["upcoming"] = "true";
                    }
                    if (gameIdArrays["newreleases"].indexOf(itemId) !== -1) {
                      allGames[itemId]["newrelease"] = "true";
                    }
                    // if (gameIdArrays["xbox360"].indexOf(itemId) !== -1) {
                    //     allGames[itemId]["platform360"] = "true";
                    // }
                    // if (reldate < nowdate && monthsagofilterdate < reldate) { // only show as new release based on release date, not list
                    //     allGames[itemId]["newrelease"] = "true";
                    // }
                    if (new Date(allGames[itemId]["releasedate"]).getFullYear() > 2025) {
                        allGames[itemId]["releasedate"] = 0;
                    }
                }
  
                popcounter++;

                if ((i === (productQuantity - 1)) && count === chunktotal - 1) {
                    var activecheck = setInterval(function() {
                        var activeAjax = $.active;
                        if (activeAjax === 0) {
                            ajaxdone();
                            clearInterval(activecheck);
                        }
                    }, 500);
  
  
                    function ajaxdone() {
                        for (var r = 0; r < allGamesExcludes.length; r++) {
                            delete allGames[allGamesExcludes[r]];
                        }
                        listGames(fullGameArray, "avail-download", "featured", "nochange");
                        // filtersort();
  
                        // var x1RegionPop = (function() {
                        //     $(".gameDiv a").each(function() {
                        //         var rawHref = $(this).attr("href")
                        //         var splitHref = rawHref.split("/")
                        //         splitHref.splice(3, 0, urlRegion)
                        //         var newHref = splitHref.join("/")
                        //         $(this).attr("href", newHref)
                        //     })
                        // })();
  
                    }
                }
            }
        }
    }


    function listGames(cat, filt) {
        console.warn("fired")
        setTimeout(function() {
            $(".enhancedlink").addClass("hide");
            $(".looklogo").addClass("hide");
            if (cat === "all") {
                cat = fullGameArray;
            }
  
            // filters
            selectedGames = cat;
            //remove based on ratings
            prunedGames = [];
            var ratarrlen = selectedGames.length;
  
            var filterarray = filt.split(",");
            if (filterarray.indexOf("avail-download") === -1) { // when there are no other availabilities
                filterarray.push("avail-download");
            }
  
            if (filterarray.length > 1) {
                for (var i = 0; i < ratarrlen; i++) {
                    var availset, platset, genreset, featureset, ratingset;
                    availset = platset = genreset = featureset = ratingset = 0;
                    var filtsettotal;
  
                    // avail filter
                    if (filterarray.indexOf("avail-download") !== -1 && allGames[selectedGames[i]]["physical"] === "false") {
                        availset = 1;
                    } else if (filterarray.indexOf("avail-physical") !== -1 && allGames[selectedGames[i]]["physical"] === "true") {
                        availset = 1;
                    } else {
                        availset = 0;
                    }
  
                    // plat filter
                    if (filt.indexOf("plat-") !== -1) {
                        if (filt.indexOf("plat-xsx") !== -1 && allGames[selectedGames[i]]["platformxsx"] === "true") {
                            platset = 1;
                            $(".cloudEnabled").hide();
                        } else if (filt.indexOf("plat-xo") !== -1 && allGames[selectedGames[i]]["platformxo"] === "true") {
                            platset = 1;
                            $(".cloudEnabled").hide();
                        } else if (filt.indexOf("plat-360") !== -1 && allGames[selectedGames[i]]["platform360"] === "true") {
                            platset = 1;
                            $(".cloudEnabled").hide();
                        } else if (filt.indexOf("plat-pc") !== -1 && allGames[selectedGames[i]]["platformpc"] === "true") {
                            platset = 1;
                            $(".cloudEnabled").hide();
                        } else if (filt.indexOf("plat-cloudenabled") !== -1 && gameIdArrays["cloud"].indexOf(selectedGames[i]) !== -1) {
                            platset = 1;
                            $(".cloudEnabled").show();
                        }
                    } else {
                        platset = 1;
                    }
  
                    // genre filter
                    if (filt.indexOf("genre-") !== -1) {
                        if (filt.indexOf("genre-indie") !== -1) {
                            for (var h = 0; h < gameIdArrays["indie"].length; h++) {
                                if (selectedGames[i] === gameIdArrays["indie"][h]) {
                                    genreset = 1;
                                    break;
                                }
                            }
                        }
                        var genfilters = [];
                        filterarray.forEach(function(fa) {
                            if (fa.indexOf("genre-") !== -1) {
                                fa = fa.replace("genre-", "");
                                genfilters.push(fa);
                            }
                        })
                        genfilters.forEach(function(gf) {
                            if (allGames[selectedGames[i]]["genres"].indexOf(gf) !== -1) {
                                genreset = 1;
                            }
                        })
                    } else {
                        genreset = 1;
                    }
  
                    // feature filter
  
                    
  
                    if (filt.indexOf("feature-") !== -1) {
                        var allfeats = []
                        filterarray.forEach(function(fa) {
                            if (fa.indexOf("feature-") !== -1) {
                                allfeats.push(fa);
                            }
                        })
                        var featcount = 0;
                        for (var f = 0; f < allfeats.length; f++) {
                            if (allfeats[f] === "feature-4k") {
                                $(".smartDelivery").hide();
                                $(".optimizedGames").hide();
                                if (gameIdArrays["fourk"].indexOf(selectedGames[i]) !== -1) {
                                    featcount++;
                                }
                            } else if (allfeats[f] === "feature-hdr") {
                                $(".smartDelivery").hide();
                                $(".optimizedGames").hide();
                                if (gameIdArrays["HDRGaming"].indexOf(selectedGames[i]) !== -1) {
                                    featcount++;
                                }
                            } else if (allfeats[f] === "feature-singleplayer") {
                                $(".smartDelivery").hide();
                                $(".optimizedGames").hide();
                                if (gameIdArrays["singleplayer"].indexOf(selectedGames[i]) !== -1) {
                                    featcount++;
                                }
                            } else if (allfeats[f] === "feature-multiplayer") {
                                $(".smartDelivery").hide();
                                $(".optimizedGames").hide();
                                if (gameIdArrays["multionline"].indexOf(selectedGames[i]) !== -1) {
                                    featcount++;
                                }
                            } else if (allfeats[f] === "feature-multiplayerlocal") {
                                $(".smartDelivery").hide();
                                $(".optimizedGames").hide();
                                if (gameIdArrays["multilocal"].indexOf(selectedGames[i]) !== -1) {
                                    featcount++;
                                }
                            } else if (allfeats[f] === "feature-coop") {
                                $(".smartDelivery").hide();
                                $(".optimizedGames").hide();
                                if (gameIdArrays["cooponline"].indexOf(selectedGames[i]) !== -1) {
                                    featcount++;
                                }
                            } else if (allfeats[f] === "feature-smartdelivery") {
                                $(".smartDelivery").show();
                                $(".optimizedGames").hide();
                                if (gameIdArrays["cross"].indexOf(selectedGames[i]) !== -1) {
                                    featcount++;
                                }
                            } else if (allfeats[f] === "feature-genNine") {
                                $(".optimizedGames").show();
                                $(".smartDelivery").hide();
                                if (gameIdArrays["genNine"].indexOf(selectedGames[i]) !== -1) {
                                    featcount++;
                                }
                            } else if (allfeats[f] === "feature-cooplocal") {
                                $(".optimizedGames").hide();
                                $(".smartDelivery").hide();
                                if (gameIdArrays["cooplocal"].indexOf(selectedGames[i]) !== -1) {
                                    featcount++;
                                }
                            }
                        }
                        if (featcount === allfeats.length) { featureset = 1 }
                    } else {
                        featureset = 1;
                    }
  
                    // rating filter
                    if (filt.indexOf("rating-") !== -1) {
                        var allrats = []
                        filterarray.forEach(function(fa) {
                            if (fa.indexOf("rating-") !== -1) {
                                allrats.push(fa.replace("rating-", ""));
                            }
                        })
                        for (var f = 0; f < allrats.length; f++) {
                            if (allGames[selectedGames[i]]["rating"] === allrats[f]) {
                                ratingset = 1;
                            }
                        }
                    } else {
                        ratingset = 1;
                    }
  
                    filtsettotal = availset + platset + genreset + featureset + ratingset;
                    // if (allGames[selectedGames[i]]["silversaleperc"] === "0%") { // only games on sale included
                    //   console.log(selectedGames[i] + " should be removed")
                    //   filtsettotal = 0;
                    // }
                    if (filtsettotal === 5) { // game passes all 5 filters
                        prunedGames.push(selectedGames[i]);
                    }
                }
            } else {
                if (filterarray.indexOf("avail-download") !== -1) {
                    for (var p = 0; p < ratarrlen; p++) {
                        if (allGamesExcludes.indexOf(selectedGames[p]) === -1 && allGames[selectedGames[p]] && allGames[selectedGames[p]]["physical"] === "false") {
                            // if (allGames[selectedGames[p]]["silversaleperc"] !== "0%") { // only games on sale included
                              prunedGames.push(selectedGames[p]);
                            // } else {
                            //   console.log(selectedGames[p] + " should be removed")
                            // }
                        }
                    }
                } else if (filterarray.indexOf("avail-physical") !== -1) {
                    for (var p = 0; p < ratarrlen; p++) {
                        if (allGames[selectedGames[p]]["physical"] === "true") {
                            prunedGames.push(selectedGames[p]);
                        }
                    }
                }
            }

  
            paginateSetup(prunedGames);
  
            // after loading get the full list of boxshots to add show/hide
            var boxshots = document.querySelectorAll(".gameDivsWrapper .m-product-placement-item");

            // loop through all the boxshots
            for(var i = 0; i < boxshots.length; i++) {
                if (i >= 12) {
                    boxshots[i].classList.add("gamesMore");
                    boxshots[i].classList.add("hiddenGames");
                };
            };

            $(".showMoreText").on("click", function(e) {
                // $(".gamesMore").toggleClass("hiddenGames");
                if ($(".gamesMore").hasClass("hiddenGames")) {
                    $(".gamesMore").removeClass("hiddenGames");
                    var lessText = $(this).attr("data-less");
                    $(this).text(lessText);
                    lessText= lessText+ ", hide the additional rows of games"
                    $(this).attr("aria-expanded", "true");
                    $(this).attr("aria-label", lessText);
                    $(".gamesMore .m-content-placement-item:first-child a").focus(); // Accessibility: focuses the first hidden FAQ question when it is shown.
                } else if ($(".gamesMore").not("hiddenGames")) {
                    $(".gamesMore").addClass("hiddenGames");
                    window.scrollTo({ top: 1500 });
                    var moreText = $(this).attr("data-more");
                    $(this).text(moreText);
                    moreText= moreText+ ", hide the additional rows of games"
                    $(this).attr("aria-expanded", "true");
                    $(this).attr("aria-label", moreText);
                    $(".gamesMore .m-content-placement-item:first-child a").focus(); // Accessibility: focuses the first hidden FAQ question when it is shown.
                };
            });

        }, 10);
    }


    gamesperpage = 100;
  
    function paginateSetup(array) {
        $(".paginateprevious").removeClass("pag-disabled");
        $(".paginatenext").removeClass("pag-disabled");
        $(document).off("keypress", ".paginateprevious a");
        $(document).off("keypress", ".paginatenext a");
        $(document).off("keypress", ".paginateprevious a");
        $(".paginatenext a").attr("tabindex", "0");
        $(".paginateprevious a").attr("tabindex", "0");
        $(".paginatenum a").attr("tabindex", "0");
        var gamenum = array.length;
        // gamesperpage = gamesperpage || 50;
        var gamesperpage = parseInt($(".paginateDropdown button").text().replace(/\D+/g, '')) || 20;
        var pagenum = Math.ceil(gamenum / gamesperpage);
        if (pagenum < 2) {
            $(".m-pagination-group").hide();
            $(".resultsText").text(regionContent["keyAllresults"].replace("<NUMBER>", gamenum));
            $(".resultsText").show();
            $(".gameDivsWrapper").removeAttr("style");
        } else {
            $(".paginatenum").remove();
            for (var i = 1; i <= pagenum; i++) {
                $(".paginatenext").before('<li data-label="' + i + '" class="paginatenum" data-topage="' + i +
                    '"><a href="#" aria-label="' + regionContent.keyPage + ' ' + i + '">' + i + '</a></li>')
            }
            $(".paginatenum").eq(0).closest("li").addClass("f-active");
            $(".m-pagination-group").show();
        }
        paginate(array, 0);
        //ratings pop
        var systems = {};
        var currentgameslength = selectedGames.length;
        for (var i = 0; i < currentgameslength; i++) {
            if (allGames[selectedGames[i]]) {
                var rs = allGames[selectedGames[i]]["ratingsystem"];
                if (!systems[rs]) {
                    systems[rs] = 1
                } else {
                    systems[rs]++
                }
            }
        }
        var bigsystemnum = 0;
        var bigsystem;
        for (var g = 0; g < Object.keys(systems).length; g++) {
            if (systems[Object.keys(systems)[g]] > bigsystemnum) {
                bigsystemnum = systems[Object.keys(systems)[g]]
                bigsystem = Object.keys(systems)[g].toString();
            }
        }
  
        // $("#ratingSelect li.dynRatingItem").remove(); // to dynamically populate ratings, but MWF can't handle 
        if (pageloadfocus < 2) {
            for (var i = 0; i < currentgameslength; i++) {
                if (allGames[selectedGames[i]]) {
                    if (allGames[selectedGames[i]]["ratingsystem"] !== bigsystem) {
                        allGames[selectedGames[i]]["rating"] = "none";
                    } else {
                        var sentenceRating = allGames[fullGameArray[i]]["rating"].toLowerCase();
                        sentenceRating = sentenceRating.charAt(0).toUpperCase() + sentenceRating.slice(1,sentenceRating.length);
                        allGames[fullGameArray[i]]["rating"].toLowerCase()
                        var gamerating = "rating-" + allGames[fullGameArray[i]]["rating"];
                        if ($(".ratingchoice[data-cat='" + gamerating + "']").length === 0 && allGames[fullGameArray[i]]["rating"] !== "none") {
                            $("#ratingSelect").append('<li class="dynRatingItem" data-ratingage="' + allGames[fullGameArray[i]]["ratingage"] + '">' +
                                '<a class="c-refine-item ratingchoice" href="#" tabindex="0" aria-label="Refine by ' + allGames[fullGameArray[i]]["rating"] + ' games" data-cat="' + gamerating + '">' +
                                '<span aria-hidden="true">' + sentenceRating + '</span>' +
                                '</a></li>');
                        }
                    }
                }
                if (i === currentgameslength - 1) {
                    setTimeout(function() {
                        var $alphadivs = $(".dynRatingItem");
                        var alphaRat = $alphadivs.sort(function(a, b) {
                            return $(a).data("ratingage") > $(b).data("ratingage") ? 1 : -1;
                        });
                        $("#ratingSelect").html(alphaRat);
                        // Ratings Deep Link
                        if (pageloadfocus === 1) {
                            var durl = document.URL.toLowerCase();
                            var ratmap = {
                                "everyone10plus": "rating-EVERYONE 10+",
                                "teen": "rating-TEEN",
                                "mature17plus": "rating-MATURE 17+  ",
                                "ratingpending": "rating-RATING PENDING"
                                };
                        
                            var ratarray = Object.keys(ratmap);
                            
                            for (var g = 0; g < ratarray.length; g++) {
                                if (durl.indexOf(ratarray[g]) !== -1) {
                                    $("#filter-ratings button").click();
                                        var rattoclick = ratmap[ratarray[g]];
                                        $("#ratingSelect a[data-cat='" + rattoclick + "']")[0].click();
                                        entrycat = true;
                                    }
                            }
                        }
                    }, 250)
                }
    
    
            }
        }
  
        $(".m-pagination li").first().css("display", "inline-block").addClass("paginateprevious");
        $(".paginateprevious").addClass("pag-disabled");
  
        // paginate handling
        function totop() {
            var searchtop = $(".searchgroup").offset().top;
            $("HTML, BODY").animate({
                scrollTop: searchtop
            }, 300);
        }
        $(".paginatenum a").on("click", function(e) {
            paginateclick = 1;
            e.preventDefault();
            e.stopPropagation();
            var wrapheight = $(".gameDivsWrapper").height();
            //$(".gameDivsWrapper").css("min-height", wrapheight + "px");
            $(".gameDivsWrapper").css("min-height", "32vw");
            var gotopage = parseInt($(this).closest("li").attr("data-topage")) - 1;
            var lastpage = parseInt($(".paginatenum").last().attr("data-topage")) - 1;
            if ($(this).closest("li").hasClass("f-active")) {
                return false;
            }
            $(".paginatenum").closest("li").removeClass("f-active");
            $(this).closest("li").addClass("f-active");
            if (gotopage === 0) {
                $(".paginateprevious").addClass("pag-disabled");
                $(".paginatenext").removeClass("pag-disabled");
            } else if (gotopage === lastpage) {
                $(".paginatenext").addClass("pag-disabled");
                $(".paginateprevious").removeClass("pag-disabled");
            } else {
                $(".paginateprevious").removeClass("pag-disabled");
                $(".paginatenext").removeClass("pag-disabled");
            }
            totop();
            paginate(prunedGames, gotopage)
            $(".paginatenum a").removeAttr("aria-current");
        })
        $(".paginateprevious").off("click");
        $(".paginateprevious").on("click", function(e) {
            paginateclick = 1;
            e.preventDefault();
            e.stopPropagation();
            var wrapheight = $(".gameDivsWrapper").height();
            //$(".gameDivsWrapper").css("min-height", wrapheight + "px");
            $(".gameDivsWrapper").css("min-height", "32vw");
            var currentpage = parseInt($(".paginatenum.f-active").attr("data-topage")) - 1;
            var gotopage = currentpage - 1;
            $(".paginatenum.f-active").prev(".paginatenum").addClass("f-active");
            $(".paginatenum.f-active").last().removeClass("f-active");
            if (gotopage === 0) {
                $(".paginateprevious").addClass("pag-disabled");
                $(".paginatenext").removeClass("pag-disabled");
            } else {
                $(".paginateprevious").removeClass("pag-disabled");
                $(".paginatenext").removeClass("pag-disabled");
            }
            totop();
            paginate(prunedGames, gotopage)
        })
        $(".paginatenext").off("click");
        $(".paginatenext").on("click", function(e) {
            paginateclick = 1;
            e.preventDefault();
            e.stopPropagation();
            var wrapheight = $(".gameDivsWrapper").height();
            //$(".gameDivsWrapper").css("min-height", wrapheight + "px");
            $(".gameDivsWrapper").css("min-height", "32vw");
            var currentpage = parseInt($(".paginatenum.f-active").attr("data-topage")) - 1;
            var gotopage = currentpage + 1;
            var lastpage = parseInt($(".paginatenum").last().attr("data-topage")) - 1;
            $(".paginatenum.f-active").next(".paginatenum").addClass("f-active");
            $(".paginatenum.f-active").first().removeClass("f-active");
            if (gotopage === lastpage) {
                $(".paginatenext").addClass("pag-disabled");
                $(".paginateprevious").removeClass("pag-disabled");
            } else {
                $(".paginatenext").removeClass("pag-disabled");
                $(".paginateprevious").removeClass("pag-disabled");
            }
            totop();
            paginate(prunedGames, gotopage)
        })
        $(".pag-disabled a").attr("tabindex", "-1");
        $(".paginatenum.f-active a").attr("tabindex", "-1");
  
    }
  
    function paginate(array, page) {
        docwidth = $(document).width();
        var currregion;
        var startgame = page * gamesperpage;
        shownGames = array.slice(startgame, startgame + gamesperpage);
        $(".gameDivsWrapper .gameDiv").remove();
        gamehtml = '';
        var catarrlen = shownGames.length;
        if (array.length > gamesperpage) {
            var firstnum = (page * gamesperpage) + 1;
            var secnum = firstnum + gamesperpage - 1;
            if (secnum > array.length) { secnum = array.length }
            var viewing = firstnum + "-" + secnum;
            $(".resultsText").text(regionContent["keySomeresults"].replace("<NUMBER1>", viewing).replace("<NUMBER2>", array.length));
            $(".resultsText").show();
        }
        for (var i = 0; i < catarrlen; i++) {
            var thebigid = shownGames[i];
            if (urlRegion !== "ar-sa" && urlRegion !== "ar-ae") {
                var msrpshown = allGames[thebigid]["msrpprice"].toLocaleString(urlRegion, { style: 'currency', currency: allGames[thebigid]["currencycode"] });
                var listshown = allGames[thebigid]["listprice"].toLocaleString(urlRegion, { style: 'currency', currency: allGames[thebigid]["currencycode"] });
                var goldPrice = allGames[thebigid]["goldandsilversalegoldprice"].toLocaleString(urlRegion, { style: 'currency', currency: allGames[thebigid]["currencycode"] });
            } else {
                if (urlRegion === "ar-sa") {
                    currregion = "en-us";
                } else {
                    currregion = "en-ca";
                }
                var msrpshown = allGames[thebigid]["msrpprice"].toLocaleString(currregion, { style: 'currency', currency: allGames[thebigid]["currencycode"] });
                var listshown = allGames[thebigid]["listprice"].toLocaleString(currregion, { style: 'currency', currency: allGames[thebigid]["currencycode"] });
                var goldPrice = allGames[thebigid]["goldandsilversalegoldprice"].toLocaleString(currregion, { style: 'currency', currency: allGames[thebigid]["currencycode"] });
            }
            
            if (allGames[thebigid]["listprice"] !== 100000000) {
                if (allGames[thebigid]["msrpprice"] !== allGames[thebigid]["goldandsilversalegoldprice"] && allGames[thebigid]["goldandsilversalegoldprice"] !== 100000000) {
                    var priceshown = '<div class="c-price" itemprop="offers" itemscope="" itemtype="http://schema.org/Offer">' +
                        //'<s aria-label="' + regionContent["keyFullprice"].replace("<PLACEHOLDER>", msrpshown) + '">' + msrpshown + '</s>' +
                        '<s><span class="x-screen-reader">' + regionContent["keyFullprice"] + '</span> ' + msrpshown + '</s>' +
                        '<meta itemprop="priceCurrency" content="' + allGames[thebigid]["currencycode"] + '">' +
                        '<span class="x-screen-reader">' + regionContent["keyNewprice"] + '</span>' + '<span class="textpricenew x-hidden-focus" itemprop="price" style="margin-left: 5px;">' + goldPrice + '</span>' +
                        '</div>';
                } else {
                    var priceshown = '<div class="c-price" itemprop="offers" itemscope="" itemtype="http://schema.org/Offer">' +
                        '<meta itemprop="priceCurrency" content="' + allGames[thebigid]["currencycode"] + '">' +
                        '<span class="textpricenew x-hidden-focus" itemprop="price" style="margin-left: 5px;">' + msrpshown + '</span>' +
                        '</div>';
                }
            } else {
                var priceshown = "";
            }
  
            // Hide prices for WW
            if (urlRegion.toLowerCase() !== "en-us") {
                var priceshown = "";
            }

            var pricestartingat = "";
            if (gameIdArrays["startingat"].indexOf(thebigid) !== -1) {
                pricestartingat = '<div class="startingattext">' + regionContent["keyStartingat"] + '</div>';
            }
  
            badges = '';
            // if (allGames[thebigid]["silversaleperc"] !== "0%") {
            //     badges+= '<span class="c-badge f-small badge-silver">' + regionContent["keyPopbadgepercent"].replace("<PLACEHOLDER>", allGames[thebigid]["silversaleperc"]) + '</span>'
            // }
              if (allGames[thebigid]["goldandsilversalegoldperc"] !== "0%") {
                badges+= '<span class="c-badge f-small f-highlight">' + regionContent["keyPopbadgepercent"].replace("<PLACEHOLDER>", allGames[thebigid]["goldandsilversalegoldperc"]) + '</span>'
              }
  
            if (docwidth < 768) {
                var theboxshot = allGames[thebigid]["boxshotsmall"]
            } else {
                var theboxshot = allGames[thebigid]["boxshot"]
            }
  
            var disprelease = "-"
            if (allGames[thebigid]["releasedate"] !== 0) {
                var d = new Date(allGames[thebigid]["releasedate"]);
                if (d.getFullYear() < 2027) {
                    disprelease = d.toLocaleDateString(urlRegion, { year: 'numeric', month: 'long', day: 'numeric' });
                }
            }
  
            var thestars = '';
            if (allGames[thebigid]["starcount"] > 4) {
                var totalratings = allGames[thebigid]["starcount"];
                var avgrating = allGames[thebigid]["stars"];
                var percentfilled = (avgrating / 5) * 100;
                var offset;
                if (percentfilled <= 20) {
                    offset = 0;
                } else if (percentfilled > 20 && percentfilled <= 40) {
                    offset = 12;
                } else if (percentfilled > 40 && percentfilled <= 60) {
                    offset = 24;
                } else if (percentfilled > 60 && percentfilled <= 80) {
                    offset = 36;
                } else if (percentfilled > 80 && percentfilled <= 100) {
                    offset = 48;
                }
                var starsfilled = ((percentfilled / 100) * 90) + offset;
                thestars = '<div class="ratingstars" data-starpercent="' + starsfilled + '"><div class="c-rating f-individual emptystars" data-value="' + avgrating +
                    '" data-max="5" itemscope itemtype="https://schema.org/Rating">' +
                    '<p class="x-screen-reader">User rating:' +
                    '<span itemprop="ratingValue">' + avgrating + '</span>/' +
                    '<span itemprop="bestRating">5</span>' +
                    '</p>' +
                    // '</div>' + 
                    '<div class="c-rating f-individual filledstars" data-value="5" data-max="5" itemscope itemtype="https://schema.org/Rating">' +
                    '<p class="x-screen-reader">' +
                    '<span itemprop="ratingValue">5</span>/' +
                    '<span itemprop="bestRating">5</span>' +
                    '</p>' +
                    '<div></div>' +
                    '</div></div></div><span class="reviewtotal">' + allGames[thebigid]["starcount"] + '</span>'
                    // $("body").append('<style>.c-rating[data-value].f-individual div {height: 30px;width: 138px;}.ratingstars {position:relative;display: inline-block;vertical-align: middle;}.emptystars {position: absolute;left: 0;right: 0;}' +
                    //     '.filledstars.c-rating[data-value].f-individual div:after, .filledstars.c-rating[data-value].f-individual div:before {width:' + starsfilled + 'px; overflow:hidden;}' +
                    //     '.startotalratings{display: inline-block;font-size: 16px;margin-left: 12px;}');
            }
  
            var thedescriptors = '';
            var rawdesc = allGames[thebigid]["descriptors"];
            var rdarray = rawdesc.split(",");
            var rdtext = [];
            for (var r = 0; r < rdarray.length; r++) {
                var descnum = ratingData.RatingBoards[allGames[thebigid]["ratingsystem"]].LocalizedProperties[0].Descriptors.length;
              for (var s = 0; s < descnum; s++) {
                if (ratingData.RatingBoards[allGames[thebigid]["ratingsystem"]].LocalizedProperties[0].Descriptors[s].Key === rdarray[r]) {
                  var desc = ratingData.RatingBoards[allGames[thebigid]["ratingsystem"]].LocalizedProperties[0].Descriptors[s].Descriptor;
                  rdtext.push(desc);
                }
              }                
            }
            thedescriptors = rdtext.join(",</span> <span class='descNoWrap'>");
            if (thedescriptors !== '') {
              thedescriptors = '<span class="descNoWrap">' + thedescriptors + "</span>"
            }
  
            var theinteractive = '';
            var rawint = allGames[thebigid]["interactive"];
            var rintarray = rawint.split(",");
            var rinttext = [];
            for (var r = 0; r < rintarray.length; r++) {
              var intnum = ratingData.RatingBoards[allGames[thebigid]["ratingsystem"]].LocalizedProperties[0].InteractiveElements.length;
              for (var s = 0; s < intnum; s++) {
                if (ratingData.RatingBoards[allGames[thebigid]["ratingsystem"]].LocalizedProperties[0].InteractiveElements[s].Key === rintarray[r]) {
                  var int = ratingData.RatingBoards[allGames[thebigid]["ratingsystem"]].LocalizedProperties[0].InteractiveElements[s].InteractiveElement;
                  rinttext.push(int);
                }
              }
            }
            theinteractive = rinttext.join(",</span> <span class='descNoWrap'>");
            if (theinteractive !== '') {
              theinteractive = '<span class="descNoWrap">' + theinteractive + "</span>"
            }
  
            var thedisclaimers = '';
            var rawdisc = allGames[thebigid]["disclaimers"];
            var rdiscarray = rawdisc.split(",");
            var rdisctext = [];
            for (var r = 0; r < rdiscarray.length; r++) {
              var discnum = ratingData.RatingBoards[allGames[thebigid]["ratingsystem"]].LocalizedProperties[0].Disclaimers.length;
              for (var s = 0; s < discnum; s++) {
                if (ratingData.RatingBoards[allGames[thebigid]["ratingsystem"]].LocalizedProperties[0].Disclaimers[s].Key === rdiscarray[r]) {
                  var disc = ratingData.RatingBoards[allGames[thebigid]["ratingsystem"]].LocalizedProperties[0].Disclaimers[s].Disclaimer;
                  if (disc.length > 48) {
                    var discarr = disc.split(". ");
                    disc = discarr.join(". <br>");
                  }
                  rdisctext.push(disc);
                }
              }                
            }
            thedisclaimers = rdisctext.join(",</span> <span class='descNoWrap'>");
            if (thedisclaimers !== '') {
              thedisclaimers = '<span class="descNoWrap">' + thedisclaimers + "</span>"
            }
  
            var popiconRating, popiconEnhanced, popiconsXpa, popicon4k, popiconHdr;
            popiconRating = popiconEnhanced = popiconXpa = popicon4k = popiconHdr = '';
  
            var previousExists = false;
  
            if (allGames[thebigid]["rating"] === "none") {
                popiconRating = '';
                // } else if (ratingImages[allGames[thebigid]["rating"]] !== undefined) {
                //   popiconRating = '<span class="popicon piRating"><img src="' + ratingImages[allGames[thebigid]["rating"]] + '"></span>';
            } else {
                popiconRating = '<span class="popicon piRating">' + allGames[thebigid]["rating"] + '</span>';
            }
  
            var popbadges = '';
            var popgoldprice = '';
            if (allGames[thebigid]["msrpprice"] !== allGames[thebigid]["listprice"]) {
                var listdiff = allGames[thebigid]["msrpprice"] - allGames[thebigid]["listprice"];
                var listperc = Math.round(listdiff / allGames[thebigid]["msrpprice"] * 100).toString() + "%";
                popbadges += '<span class="c-badge f-small badge-silver">' + regionContent["keyPopbadgepercent"].replace("<PLACEHOLDER>", listperc) + '</span>'
            }
  
            if (allGames[thebigid]["goldandsilversale"] === "true") {
                popbadges += '<span class="c-badge f-small f-highlight">' + regionContent["keyPopgolddiscount"] + '</span>';
                if (urlRegion !== "ar-sa" && urlRegion !== "ar-ae") {
                    var specialshown = allGames[thebigid]["goldandsilversalegoldprice"].toLocaleString(urlRegion, { style: 'currency', currency: allGames[thebigid]["currencycode"] });
                } else {
                    if (urlRegion === "ar-sa") {
                        currregion = "en-us";
                    } else {
                        currregion = "en-ca";
                    }
                    var specialshown = allGames[thebigid]["goldandsilversalegoldprice"].toLocaleString(currregion, { style: 'currency', currency: allGames[thebigid]["currencycode"] });
                }
  
                popgoldprice += '<div class="popgoldarea"><div class="c-price popgoldprice" itemprop="offers" itemscope="" itemtype="http://schema.org/Offer">' +
                    '<meta itemprop="priceCurrency" content="' + allGames[thebigid]["currencycode"] + '">' +
                    '<span class="textpricenew x-hidden-focus" itemprop="price">' + specialshown + '</span>' +
                    '</div>' +
                    '<img class="popgoldlogo" src="https://assets.xboxservices.com/assets/e1/bf/e1bffa4c-302d-4f87-a022-6ce260147ccf.svg?n=X1-Games-Catalog_0_Gold-Logo_64x23.svg"></div>';
            } else if (allGames[thebigid]["golddiscount"] === "true" || allGames[thebigid]["gameswithgold"] === "true") {
                popbadges += '<span class="c-badge f-small f-highlight">' + regionContent["keyPopgolddiscount"] + '</span>';
                if (urlRegion !== "ar-sa" && urlRegion !== "ar-ae") {
                    var specialshown = allGames[thebigid]["specialprice"].toLocaleString(urlRegion, { style: 'currency', currency: allGames[thebigid]["currencycode"] });
                } else {
                    if (urlRegion === "ar-sa") {
                        currregion = "en-us";
                    } else {
                        currregion = "en-ca";
                    }
                    var specialshown = allGames[thebigid]["specialprice"].toLocaleString(currregion, { style: 'currency', currency: allGames[thebigid]["currencycode"] });
                }
                popgoldprice += '<div class="popgoldarea"><div class="c-price popgoldprice" itemprop="offers" itemscope="" itemtype="http://schema.org/Offer">' +
                    '<meta itemprop="priceCurrency" content="' + allGames[thebigid]["currencycode"] + '">' +
                    '<span class="textpricenew x-hidden-focus" itemprop="price">' + specialshown + '</span>' +
                    '</div>' +
                    '<img class="popgoldlogo" src="https://assets.xboxservices.com/assets/e1/bf/e1bffa4c-302d-4f87-a022-6ce260147ccf.svg?n=X1-Games-Catalog_0_Gold-Logo_64x23.svg"></div>';
            }
  
            var popservices = '';
            var abovetitle = '';
            if (allGames[thebigid]["gamepassgame"] === "true") {
                // popservices += '<div class="servicesarea"><p>' + regionContent["keyPopgpgame"] + '</p></div>';
                abovetitle = '<div class="c-glyph gp-glyph"><img src="https://assets.xboxservices.com/assets/bd/d6/bdd616b4-9210-4d36-9d4f-0f9f21969131.svg?n=Games-Catalog_Image-0_Game-Pass-Badge_144x24.svg" alt="game pass icon"/></div>';
            }
            if (allGames[thebigid]["eaaccessgame"] === "true" && allGames[thebigid]["specialprice"] !== 100000000) {
                if (urlRegion !== "ar-sa" && urlRegion !== "ar-ae") {
                    var eaprice = allGames[thebigid]["specialprice"].toLocaleString(urlRegion, { style: 'currency', currency: allGames[thebigid]["currencycode"] });
                } else {
                    if (urlRegion === "ar-sa") {
                        currregion = "en-us";
                    } else {
                        currregion = "en-ca";
                    }
                    var eaprice = allGames[thebigid]["specialprice"].toLocaleString(currregion, { style: 'currency', currency: allGames[thebigid]["currencycode"] });
                }
  
                popservices += '<div class="servicesarea"><p>' + regionContent["keyPopeagame"].replace("<PLACEHOLDER>", eaprice) + '</p></div>';
            }
  
            var popbuytext = regionContent["keyBuynow"];
            if (allGames[thebigid]["title"].toLowerCase().indexOf("preview") !== -1 || (allGames[thebigid]["description"] !== null && allGames[thebigid]["description"].toLowerCase().indexOf("game preview") !== -1) ||
                (allGames[thebigid]["description"] !== null && allGames[thebigid]["description"].toLowerCase().indexOf("gamepreview") !== -1)) {
                var popbuytext = regionContent["keyBuynow"];
            } else if (gameIdArrays["upcoming"].indexOf(thebigid) !== -1 && allGames[thebigid]["purchasable"] === "true") {
                popbuytext = regionContent["keyPreordernow"];
            }
  
            var datatrack = 'data-retailer="ms store"'
            if (allGames[thebigid]["gameurl"].toLowerCase().indexOf("xbox.com") !== -1) {
                datatrack = 'data-cta="learn"'
            }
  
            if (allGames[thebigid]["gameurl"].toLowerCase().indexOf("xbox.com") === -1) {
                priceButtons = '<a href="' + allGames[thebigid]["gameurl"] + '" target="_blank" ' + datatrack +
                    ' aria-label="' + regionContent["keyLearnmore"] + ", " + allGames[thebigid]["title"] + '">' +
                    '<span>' + regionContent["keyLearnmore"] + '</span>' +
                    '</a>'
            } else {
                priceButtons = '<a href="' + allGames[thebigid]["gameurl"] + '" class="c-call-to-action c-glyph" target="_blank" ' + datatrack + 
                    ' aria-label="' + regionContent["keyLearnmore"] + ", " + allGames[thebigid]["title"] + '">' +
                    '<span>' + regionContent["keyLearnmore"] + '</span>' +
                    '</a>'
  
            }
            if (gameIdArrays["upcoming"].indexOf(thebigid) !== -1 && allGames[thebigid]["purchasable"] === "false") {
                popbadges = '';
                priceshown = '<div class="c-price" itemprop="offers" itemscope="" itemtype="http://schema.org/Offer">' +
                    '<span class="textpricenew soontextprice x-hidden-focus" itemprop="price">' + regionContent["keyBadgecomingsoonlower"] + '</span>' +
                    '</div>';
                popgoldprice = '';
                popservices = '';
                priceButtons = '<a href="' + allGames[thebigid]["gameurl"] + '" data-clickname="www>games>xbox-one>' + allGames[thebigid]["titleclickname"] +
                    '>learn-more>click" class="c-call-to-action c-glyph" target="_blank">' +
                    '<span>' + regionContent["keyLearnmore"] + '</span>' +
                    '</a>'
            }
  
            // 24 hours hide price
            var tempreldate = new Date(allGames[thebigid]["releasedate"]);
            var tempnowdate = new Date();
            var hoursaway = new Date(tempreldate.toGMTString()) - new Date(tempnowdate.toGMTString());
            hoursaway = hoursaway / 1000 / 60 / 60; // gives hours
  
            var poppriceclass = '';
            if (gameIdArrays["upcoming"].indexOf(thebigid) !== -1 && hoursaway > 0 && hoursaway < 24) {
                priceshown = '';
                popprice = '';
                poppriceclass = ' nopricegame ';
            } else {
                popprice = '<div class="popprice">'
            }
  
            var plxb = '';
            var plpc = '';
            var plxsx = '';
            var plmo = '';
  
  
            if (allGames[thebigid]["platformxsx"] === "true") {
                plxsx = '<div class="c-tag">' +
                    // '<span class="c-glyph svg-xbox-series-x"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 2048 2048" width="20" height="20"><path d="M832 384q-26 0-45-19t-19-45q0-26 19-45t45-19q26 0 45 19t19 45q0 26-19 45t-45 19zM512 0h1024v2048H512V0zm896 1920V128H640v1792h128v-896h128v896h512z"></path></svg></span>' +
                    'Xbox Series X|S' +
                    '</div>';
            }
  
            if (allGames[thebigid]["platformxbox"] === "true") {
                plxb = '<div class="c-tag">' +
                    // '<span class="c-glyph glyph-xbox-one-console"></span>' +
                    'Xbox One' +
                    '</div>';
            }
  
            var qlbutclass = '';
            if (allGames[thebigid]["physical"] === "true") { qlbutclass = ' physgame' }
  
            var eachGameClass = '';
            if (docwidth > 1083 && navigator.userAgent.indexOf("iPad") === -1) { // Added check -EL 11/23/20
                eachGameClass = 'm-product-placement-item f-size-medium context-game gameDiv x1games';
            } else {
                eachGameClass = 'm-product-placement-item f-size-medium context-game gameDiv x1games qlButtonFunc';
            }
  
            var eachgameA = '<div class="' + eachGameClass + qlbutclass + '" itemscope="" itemtype="http://schema.org/Product" data-bigid="' + thebigid + '" ' +
                'data-releasedate="' + allGames[thebigid]["releasedate"] + '" data-msproduct="' + allGames[thebigid]["msproduct"] + '" data-multiplayer="' + allGames[thebigid]["multiplayer"] +
                '" data-rating="' + allGames[thebigid]["rating"] + '" data-ratingsystem="' + allGames[thebigid]["ratingsystem"] + '" data-listprice="' + allGames[thebigid]["listprice"] + '">' +
                '<a class="gameDivLink ignoreContStore" href="' + allGames[thebigid]["gameurl"] + '" target="_blank" data-clickname="www>games>xbox-one>' + allGames[thebigid]["titleclickname"] +
                '>click" ' + datatrack + '>' +
                '<picture class="containerIMG">' +
                '<img class="c-image" aria-hidden="true" alt="' + boxshotlocstrings.locales[urlRegion]["keyPlaceholderboxshot"].replace("<PLACEHOLDER>", allGames[thebigid]["title"]) +
                '" srcset="" src="' + theboxshot + '">' +
                '</picture>' +
                badges +
                '<div>' +
                '<h3 class="c-heading x1GameName zpt" itemprop="product name">' + allGames[thebigid]["title"] + '</h3>' +
                priceshown +
                '</div>' +
                '</a>';
  
            var interactiveLine = '';
            var disclaimersLine = '';
            if (theinteractive !== '' && thedescriptors !== '') {
              interactiveLine = '<div class="descLine"></div>';
            }
            if (thedisclaimers !== '' && (theinteractive !== '' || thedescriptors !== '')) {
              disclaimersLine = '<div class="descLine"></div>';
            }
  
            var quickLookButton = '<div class="qlButton popupShow">' +
                '<button class="c-call-to-action c-glyph black-c" role="button" tabindex="0" aria-label="' + regionContent["keyQuickaria"] + '">' + regionContent["keyQuicklook"] + '</button>' +
                '</div>';
  
            var thepoptitle = allGames[thebigid]["title"];
            if (thepoptitle.length > 68) {
              thepoptitle = thepoptitle.slice(0, 68) + "...";
            }
            var thedescription = '';
            if (allGames[thebigid]["description"] !== null) { thedescription = allGames[thebigid]["description"]; }
            if (thedescription.length > 200) {
              var descarr = thedescription.split(".");
              var newdesc = '';
              if (descarr[0].length > 200) {
                thedescription = descarr[0].slice(0, 200) + "...";
              } else if (descarr.length > 1) {
                newdesc = descarr[0];
                for (var d = 1; d < descarr.length; d++) {
                  if (newdesc.length + descarr[d].length > 200) {
                    break;
                  } else {
                    newdesc = newdesc + ". " + descarr[d];
                  }
                }
                thedescription = newdesc + ".";
              }
            }
  
            var eachgameB = '</div>';
  
            if (docwidth > 1083) {
                gamehtml += eachgameA + eachgameB;
            } else {
                gamehtml += eachgameA + eachgameB;
            }
        }
  
        $(".gameDivsWrapper").append(gamehtml);
        // mwf.ComponentFactory.create([
        //      {component: mwf.MultiSlideCarousel,
        //      eventToBind: mwf.DOMContentLoaded}
        // ]);
        if (page === 0 && array.length > gamesperpage) {
            setTimeout(function() {
                // var wrapheight = $(".gameDivsWrapper").height();
                // $(".gameDivsWrapper").css("min-height", wrapheight + "px");
                $(".gameDivsWrapper").css("min-height", "32vw");
            }, 2000)
        }
        paginateClean();
    }

    function paginateClean() {
        $(".paginatenext a").attr("tabindex", "0");
        $(".paginateprevious a").attr("tabindex", "0");
        $(".paginatenum a").attr("tabindex", "0");
        var screenwidth = $(document).width();
        if (screenwidth > 768) {
            var pagnummax = 9;
        } else {
            var pagnummax = 3;
        }
        $(".paginatenum").show();
        $(".pagskipstart").remove();
        $(".pagskipend").remove();
        var pagnumber = $(".paginatenum").length;
        if (pagnumber > pagnummax) {
            // trim following
            var pagnumprev = $(".paginatenum.f-active").prevAll().length;
            if (pagnumprev <= Math.floor(pagnummax / 2)) {
                var totrimnext = pagnummax - pagnumprev - 1;
                $(".paginatenum.f-active").nextAll(".paginatenum:gt(" + totrimnext + ")").hide();
            } else {
                $(".paginatenum.f-active").nextAll(".paginatenum:gt(" + (Math.floor(pagnummax / 2) - 1) + ")").hide();
            }
            if (pagnumprev > Math.floor(pagnummax / 2) + 2) {
  
                $(".paginatenum").first().after('<li class="pagskipstart" style="display: inline-block;">...</li>');
            }
            // trim before
            var pagnumnext = $(".paginatenum.f-active").nextAll().length;
            if (pagnumnext <= Math.floor(pagnummax / 2)) {
                var totrimprev = pagnummax - pagnumnext - 1;
                $(".paginatenum.f-active").prevAll(".paginatenum:gt(" + totrimprev + ")").hide();
            } else {
                $(".paginatenum.f-active").prevAll(".paginatenum:gt(" + (Math.floor(pagnummax / 2) - 1) + ")").hide();
            }
            if (pagnumnext > Math.floor(pagnummax / 2) + 2) {
  
                $(".paginatenum").last().before('<li class="pagskipend" style="display: inline-block;">...</li>');
            }
            $(".paginatenum").first().show();
            $(".paginatenum").last().show();
        }
        $(".pag-disabled a").attr("tabindex", "-1");
        $(".paginatenum.f-active a").attr("tabindex", "-1");
  
        var currentwidth = $(window).width();
        pageloadfocus++
        if (navigator.userAgent.match(/iPad/i) === null && pageloadfocus > 1) {
            if ($(".gameDiv").not(".pagHide").not(".catHide").length === 0) {
                setTimeout(function() {
                    $(".nogamesfound h3").eq(0).focus();
                }, 600)
            } else {
                if (paginateclick === 1) {
                    $(".gameDiv").not(".pagHide").not(".catHide").eq(0).find(".gameDivLink").focus();
                    paginateclick = 0;
                }            
            }
        }
    }
  
    $(document).on("mouseenter", ".c-glyph.f-toggle", function() {
        var idtoshow = "#" + $(this).attr("aria-describedby");
        setTimeout(function() {
            $(idtoshow).show();
        }, 500)
    })
    $(document).on("mouseleave", ".c-glyph.f-toggle", function() {
        var idtoshow = "#" + $(this).attr("aria-describedby");
        setTimeout(function() {
            $(idtoshow).hide();
        }, 510)
    })

    $(".disclosureClose").click(function() {
      $(this).closest(".c-flyout").prev("button").click();
    })
    $("#disclosureContainer .glyph-prepend").click(function() {
      setTimeout(function() {
        if ($("#frDisclosure").css("display") !== 'none') {
          if ($(".CatAnnounce").text() === "l'info-bulle s'est ouverte") {
            $(".CatAnnounce").text("l'info-bulle s'est ouverte.")
          } else {
            $(".CatAnnounce").text("l'info-bulle s'est ouverte")
          }
        } else {  
          $(".CatAnnounce").text("l'info-bulle s'est fermée")
        }
        $(".disclosureClose")[0].focus()
      }, 30)
    })
  
    // jQuery slideToggle inserts inline styles that break stuff >767. This removes those styles.
    var resizeInterval = false;
  
    function resizeCheck() {
        if (window.innerWidth > 767) {
            $(".gameSelectors").attr("style", "");
        }
        clearInterval(resizeInterval);
        resizeInterval = false;
    }
  
    window.onresize = function() {
        if (!resizeInterval) {
            resizeInterval = setInterval(resizeCheck, 200);
        }
    }
  
});
  
boxshotlocstrings = {
"locales": {
        "en-us": {
            "keyPlaceholderboxshot": "box shot of <PLACEHOLDER>"
        },
        "en-ca": {
            "keyPlaceholderboxshot": "box shot of <PLACEHOLDER>"
        },
        "de-at": {
            "keyPlaceholderboxshot": "<PLACEHOLDER> – Verpackung"
        },
        "tr-tr": {
            "keyPlaceholderboxshot": "<PLACEHOLDER> kutu resmi"
        },
        "en-nz": {
            "keyPlaceholderboxshot": "<PLACEHOLDER> boxshot"
        },
        "de-de": {
            "keyPlaceholderboxshot": "<PLACEHOLDER> – Verpackung"
        },
        "el-gr": {
            "keyPlaceholderboxshot": "<PLACEHOLDER> boxshot"
        },
        "nl-nl": {
            "keyPlaceholderboxshot": "<PLACEHOLDER> - boxshot"
        },
        "en-za": {
            "keyPlaceholderboxshot": "<PLACEHOLDER> boxshot"
        },
        "en-sg": {
            "keyPlaceholderboxshot": "<PLACEHOLDER> boxshot"
        },
        "en-gb": {
            "keyPlaceholderboxshot": "<PLACEHOLDER> boxshot"
        },
        "es-ar": {
            "keyPlaceholderboxshot": "Imagen de la caja de <PLACEHOLDER>"
        },
        "es-mx": {
            "keyPlaceholderboxshot": "Imagen de la caja de <PLACEHOLDER>"
        },
        "en-au": {
            "keyPlaceholderboxshot": "<PLACEHOLDER> boxshot"
        },
        "nb-no": {
            "keyPlaceholderboxshot": "<PLACEHOLDER> coverbilde"
        },
        "ar-ae": {
            "keyPlaceholderboxshot": "<PLACEHOLDER> boxshot"
        },
        "ar-sa": {
            "keyPlaceholderboxshot": "<PLACEHOLDER> boxshot"
        },
        "de-ch": {
            "keyPlaceholderboxshot": "<PLACEHOLDER> – Verpackung"
        },
        "ja-jp": {
            "keyPlaceholderboxshot": "<PLACEHOLDER> パッケージショット"
        },
        "ko-kr": {
            "keyPlaceholderboxshot": "<PLACEHOLDER> 박스샷"
        },
        "fr-ca": {
            "keyPlaceholderboxshot": "Image de la boîte de <PLACEHOLDER>"
        },
        "he-il": {
            "keyPlaceholderboxshot": "<PLACEHOLDER> boxshot"
        },
        "fi-fi": {
            "keyPlaceholderboxshot": "Pakkauksen kansi: <PLACEHOLDER>"
        },
        "pt-br": {
            "keyPlaceholderboxshot": "<PLACEHOLDER> imagem da caixa"
        },
        "zh-hk": {
            "keyPlaceholderboxshot": "<PLACEHOLDER> 包裝圖"
        },
        "zh-tw": {
            "keyPlaceholderboxshot": "<PLACEHOLDER> 包裝圖"
        },
        "ru-ru": {
            "keyPlaceholderboxshot": "<PLACEHOLDER> — обложка"
        },
        "da-dk": {
            "keyPlaceholderboxshot": "<PLACEHOLDER> billede af æsken"
        },
        "cs-cz": {
            "keyPlaceholderboxshot": "Obrázek krabice <PLACEHOLDER>"
        },
        "es-cl": {
            "keyPlaceholderboxshot": "Imagen de la caja de <PLACEHOLDER>"
        },
        "zh-cn": {
            "keyPlaceholderboxshot": "<PLACEHOLDER> 包装盒"
        },
        "sv-se": {
            "keyPlaceholderboxshot": "<PLACEHOLDER> bild på förpackning"
        },
        "en-ie": {
            "keyPlaceholderboxshot": "<PLACEHOLDER> boxshot"
        },
        "it-it": {
            "keyPlaceholderboxshot": "Immagine della confezione di <PLACEHOLDER>"
        },
        "es-es": {
            "keyPlaceholderboxshot": "Imagen de la caja de <PLACEHOLDER>"
        },
        "fr-fr": {
            "keyPlaceholderboxshot": "<PLACEHOLDER> image de la boîte"
        },
        "fr-be": {
            "keyPlaceholderboxshot": "<PLACEHOLDER> image de la boîte"
        },
        "es-co": {
            "keyPlaceholderboxshot": "Imagen de la caja de <PLACEHOLDER>"
        },
        "en-hk": {
            "keyPlaceholderboxshot": "<PLACEHOLDER> boxshot"
        },
        "fr-ch": {
            "keyPlaceholderboxshot": "<PLACEHOLDER> image de la boîte"
        },
        "pl-pl": {
            "keyPlaceholderboxshot": "<PLACEHOLDER> – zdjęcie opakowania"
        },
        "hu-hu": {
            "keyPlaceholderboxshot": "<PLACEHOLDER> dobozának képe"
        },
        "en-in": {
            "keyPlaceholderboxshot": "<PLACEHOLDER> boxshot"
        },
        "nl-be": {
            "keyPlaceholderboxshot": "<PLACEHOLDER> - boxshot"
        },
        "pt-pt": {
            "keyPlaceholderboxshot": "Imagem da caixa de <PLACEHOLDER>"
        },
        "sk-sk": {
            "keyPlaceholderboxshot": "<PLACEHOLDER> – obrázok balenia"
        }
    }
}