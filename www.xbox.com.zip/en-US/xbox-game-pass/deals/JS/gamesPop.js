$(document).ready(function() {
    var urlRegion = document.URL.split("/")[3].toLowerCase();
    var productDataArr = [];
    var gamesArr = [];
    var newGamesArr = [];
    var productQuantity;

    getTheConsolesBigIds();

    // Aria Attr  
    $("#join .jump-g").attr("aria-hidden", "true");

        $('#consoleGames').on('focus', function(e) {
            unloadData() 
            $('#pcGames').removeClass('activePivot')
            $('#consoleGames').addClass('activePivot')

            setTimeout(() => { 
                loadConsolesGameData()
            }, 100) 
        })

        $('#pcGames').on('focus', function(e) {
            unloadData() 
            $('#consoleGames').removeClass('activePivot')
            $('#pcGames').addClass('activePivot')

            setTimeout(() => { 
            loadPcGamesData()
            }, 200) 
        })

        if( $('#consoleGames').hasClass('activePivot')) {
           // unloadData() 
            loadConsolesGameData()
        }

       function unloadData() {
            gamesArr = [];
            newGamesArr = [];
            productDataArr = [];
           // urlData = null;
            productQuantity = 0 
           $('.recentDeals').css("display", "none");
            $('.recentDeals ul').fadeOut(100).empty()
       }

       function getTheConsolesBigIds() {
            $('.recentDeals').css("display", "block");
            var sigl = "https://catalog.gamepass.com/sigls/v2?id=f6f1f99f-9b49-4ccd-b3bf-4d9767a77f5e&language=LANG&market=MARK";
            var xgpDealsUrl = sigl.replace("LANG", urlRegion).replace("MARK", urlRegion.split("-")[1].toUpperCase());

            $.get(xgpDealsUrl) 
            .done(function(responseData) {
                var productData = responseData;
                var productDataLength = productData.length
                //console.log(responseData)
            for(var i = 1; i <  productDataLength; i++) {
                productDataArr.push(productData[i].id);
               // console.log(productData[i].id)
               
                if(i > 100) {
                  break;
                }
            }
            })
        }

       

       function loadConsolesGameData() {
        $('.recentDeals').css("display", "block");
        var sigl = "https://catalog.gamepass.com/sigls/v2?id=f6f1f99f-9b49-4ccd-b3bf-4d9767a77f5e&language=LANG&market=MARK";
        var xgpDealsUrl = sigl.replace("LANG", urlRegion).replace("MARK", urlRegion.split("-")[1].toUpperCase());


        // get the bigID's
        $.get(xgpDealsUrl) 
            .done(function(responseData) {
                var productData = responseData;
                var productDataLength = productData.length
                //console.log(responseData)
               for(var i = 1; i <  productDataLength; i++) {
                productDataArr.push(productData[i].id);
                   // console.log(productData[i].id)
                  
                 if(i > 100) {
                  break;
                } 
               }
               var xgpDealsGuids = productDataArr.join(",");
               
               //get the games data
               var countryCode = urlRegion.split("-")[1].toUpperCase();
               var guidUrlRecentDeals = 'https://displaycatalog.mp.microsoft.com/v7.0/products?bigIds=GAMEIDS&market=' + countryCode + '&languages=' + urlRegion + '&MS-CV=DGU1mcuYo0WMMp+F.1'
               
               guidUrlRecentDeals = guidUrlRecentDeals.replace("GAMEIDS", xgpDealsGuids);

              $.get(guidUrlRecentDeals)
               .done(function(responseData) {
                var bestRatedData = responseData;
               // console.log(bestRatedData)

               // sort the bigID list according to release date
               sortBigIdsByDate(bestRatedData);

                newGamesArr = newGamesArr.join(',');
                var urlData = 'https://displaycatalog.mp.microsoft.com/v7.0/products?bigIds=GAMEIDS&market=' + countryCode + '&languages=' + urlRegion + '&MS-CV=DGU1mcuYo0WMMp+F.1'
                    urlData = urlData.replace("GAMEIDS", newGamesArr);

                //call the api with the new bigID list
                $.get(urlData)
                  .done(function(responseData) {
                    var sortedData = responseData
                    populateGamesData(sortedData)
                  })
                
                
               })

            })
       }

       function loadPcGamesData() {
        $('.recentDeals').css("display", "block");
        var sigl = "https://catalog.gamepass.com/sigls/v2?id=609d944c-d395-4c0a-9ea4-e9f39b52c1ad&language=LANG&market=MARK";
        var xgpDealsUrl = sigl.replace("LANG", urlRegion).replace("MARK", urlRegion.split("-")[1].toUpperCase());

        // get the bigID's
        $.get(xgpDealsUrl) 
            .done(function(responseData) {
                var productData = responseData;

                var productDataLength = productData.length
                //console.log(responseData)
                for(var i = 2; i <  productDataLength; i++) {
                    productDataArr.push(productData[i].id);
                
                   // console.log(productData[i].id)
                 if(i > 100) {
                    break;
                   } 
                    
                   }
                   var xgpDealsGuids = productDataArr.join(",");
                   
                   //get the games data
                   var countryCode = urlRegion.split("-")[1].toUpperCase();
                   var guidUrlRecentDeals = 'https://displaycatalog.mp.microsoft.com/v7.0/products?bigIds=GAMEIDS&market=' + countryCode + '&languages=' + urlRegion + '&MS-CV=DGU1mcuYo0WMMp+F.1'
                   
                   guidUrlRecentDeals = guidUrlRecentDeals.replace("GAMEIDS", xgpDealsGuids);
                  // console.log(guidUrlRecentDeals);

                  $.get(guidUrlRecentDeals)
                  .done(function(responseData) {
                   var bestRatedPCData = responseData;
                    //console.log(bestRatedPCData)
                   // sort the bigID list according to release date
                   sortBigIdsByDate(bestRatedPCData);

                newGamesArr = newGamesArr.join(',');
                var urlPCData = 'https://displaycatalog.mp.microsoft.com/v7.0/products?bigIds=GAMEIDS&market=' + countryCode + '&languages=' + urlRegion + '&MS-CV=DGU1mcuYo0WMMp+F.1'
                urlPCData = urlPCData.replace("GAMEIDS", newGamesArr);

               // console.log(urlPCData)

                //call the api with the new bigID list
                $.get(urlPCData)
                  .done(function(responseData) {
                    var sortedPCData = responseData
                   // console.log(sortedPCData);
                    populatePCData(sortedPCData)
                  })
                
                  })
            })
       }

       function sortBigIdsByDate(data) {
        // console.log(data.Products.length)
     
         for(var e = 0; e < data.Products.length; e++) {
            var releaseDate;
            if(data.Products[e].DisplaySkuAvailabilities[0].HistoricalBestAvailabilities[0] !== undefined) {
               // console.log(data.Products[e].DisplaySkuAvailabilities[0].HistoricalBestAvailabilities[0])
                var monthreleaseDate = new Date(data.Products[e].DisplaySkuAvailabilities[0].HistoricalBestAvailabilities[0].Properties.OriginalReleaseDate).toLocaleDateString('en-us', { month:'numeric'});
                var yearreleaseDate = new Date(data.Products[e].DisplaySkuAvailabilities[0].HistoricalBestAvailabilities[0].Properties.OriginalReleaseDate).toLocaleDateString('en-us', {  year:"numeric"});

                var dateCalc = yearreleaseDate + "." + monthreleaseDate;
                dateCalc = Number(dateCalc)

              // console.log(` Year: ${yearreleaseDate}, Month: ${monthreleaseDate}, ${data.Products[e].LocalizedProperties[0].ProductTitle}`)
                
                gamesArr.push(`Date: ${dateCalc}, product: ${data.Products[e].ProductId}`)
                    
            }
           
         }
         
         gamesArr.sort().reverse()
         gamesArr = gamesArr.join(' ').split(' ');  

           // console.log(gamesArr)
           if(newGamesArr.length < 9) {
                newGamesArr.push(gamesArr[3])
                newGamesArr.push(gamesArr[7])
                newGamesArr.push(gamesArr[11])
                newGamesArr.push(gamesArr[15])
                newGamesArr.push(gamesArr[19])
                newGamesArr.push(gamesArr[23])
                newGamesArr.push(gamesArr[27])
                newGamesArr.push(gamesArr[31])
                newGamesArr.push(gamesArr[35])

           }
         
         
       }




       function populatePCData(data) {
        var locStrings = globalLocStrings.locales[urlRegion];
            // var bigidUrls = biUrls.items.urls;
            // var biuArray = Object.keys(bigidUrls);
    
            var productQuantity = data.Products.length;

            
    
            for (var x = 0; x < productQuantity; x++) {
                
               // console.log(new Date(data.Products[x].DisplaySkuAvailabilities[0].HistoricalBestAvailabilities[0].Properties.OriginalReleaseDate).toLocaleDateString('en-us', {  year:"numeric"}))
                // Item Id/Title
                var itemId = data.Products[x].ProductId.toUpperCase();
                var itemTitle = data.Products[x].LocalizedProperties[0].ProductTitle;
                if (itemTitle === undefined) {
                    itemTitle = "";
                }
                var itemUrlName = itemTitle.toLowerCase().replace(/\s/g, "-").replace(/[^a-z0-9-]/gi, "");
                if (itemUrlName === "") {
                    itemUrlName = "-"
                }
    
                var shortDesc = data.Products[x].LocalizedProperties[0].ShortDescription;
                if (shortDesc === "") {
                    shortDesc = data.Products[x].LocalizedProperties[0].ProductDescription;
                }
                if (shortDesc === undefined) {
                    shortDesc = "";
                }
    
                var imagesNum = data.Products[x].LocalizedProperties[0].Images.length;
                var imgEnd = 999;
    
                for (var j = 0; j < imagesNum; j++) {
                    if (data.Products[x].LocalizedProperties[0].Images[j].ImagePurpose === "Poster") {
                        imgEnd = j;
                        break;
                    }
                }
    
                if (imgEnd === 999) {
                    for (var j = 0; j < imagesNum; j++) {
                        if (data.Products[x].LocalizedProperties[0].Images[j].Width < data.Products[x].LocalizedProperties[0].Images[j].Height) {
                            imgEnd = j;
                            break
                        }
                    }
                }
    
                if (imgEnd === 999) {
                    imgEnd = 1;
                }
    
                // Grabbing Image Path
                if (data.Products[x].LocalizedProperties[0].Images[imgEnd]) {
                    var itemBoxshot = data.Products[x].LocalizedProperties[0].Images[imgEnd].Uri.replace("http:", "https:");
                    var itemBoxshotSmall;
                } else {
                    var itemBoxshot = "https://assets.xboxservices.com/assets/5a/e5/5ae523e2-593f-4eda-ba08-56e5c68ca289.jpg?n=X1-Standard-digital-boxshot_584x800.jpg";
                    var itemBoxshotSmall = "https://assets.xboxservices.com/assets/5a/e5/5ae523e2-593f-4eda-ba08-56e5c68ca289.jpg?n=X1-Standard-digital-boxshot_584x800.jpg";
                }
                if (itemBoxshot.indexOf("xboxlive.com") !== -1) {
                    itemBoxshotSmall = itemBoxshot + "&w=140&format=jpg";
                    itemBoxshot = itemBoxshot + "&h=300&w=200&format=jpg";
                } else {
                    itemBoxshotSmall = itemBoxshot;
                }
    
                // URL
                var itemhref = 'https://www.xbox.com/' + urlRegion + '/play/games/' + itemUrlName + '/' + itemId;

                var cardObj = {
                    itemId: itemId,
                    itemhref: itemhref,
                    itemTitle: itemTitle,
                    locStrings: locStrings,
                    itemBoxshot: itemBoxshot,
                    itemTitle: itemTitle
                }

                if(cardObj.itemhref.includes('/play')) {
                    cardObj.itemhref = cardObj.itemhref.replace('/play/games', "/games/store");
                   // console.log(cardObj.itemhref)
                }
                

    
                $(".recentDeals" + " ul").append('<li>' +
                    '<section class="m-product-placement-item f-size-large context-device f-clean" data-prodid="' + cardObj.itemId + '">' +
                    '<a class="ignoreContStore" target="blank" href="' + cardObj.itemhref + '" data-retailer="MS Store" aria-label="' + cardObj.itemTitle + ' ' + cardObj.locStrings["keyLearnmoregamearia"] + '">' +
                    '<picture>' +
                    '<source srcset="' + cardObj.itemBoxshot + '" media="(min-width:0)">' +
                    '<img class="c-image" srcset="' + cardObj.itemBoxshot + '" src="' + cardObj.itemBoxshot + '" ' +
                    'alt="' + cardObj.itemTitle + ' boxshot">' +
                    '</picture>' +
                    '<div>' +
                    '<h3 class="c-heading">' + cardObj.itemTitle + '</h3>' +
                    '</div>' +
                    '</a>' +
                    '</section>' +
                    '</li>').fadeIn(500)

            }

            // Adding last tile
            var activecheck = setInterval(function() {
                var check = $(".recentDeals .m-product-placement-item").length
                var activeAjax = $(".recentDeals .m-product-placement-item").length >= 9;
                //console.log(check)
                if (activeAjax === true) {

                    var locStrings = globalLocStrings.locales[urlRegion];
                    $(".recentDeals").find("ul").append('<li>' +
                        '<section class="m-product-placement-item f-size-large context-device f-clean">' +
                        '<a target="_blank" href="https://www.xbox.com/xbox-game-pass/games#pcgames" data-cta="learn" aria-label="' + locStrings["keyExploreallaria"] + '">' +
                        '<picture>' +
                        '<source srcset="https://assets.xboxservices.com/assets/dd/a1/dda1aa1d-99f2-470b-9773-710eabf849e0.jpg?n=Game-Pass-Deals_Boxshot-0_XGP-Logo_720x1080.jpg" media="(min-width:0)">' +
                        '<img class="c-image" srcset="https://assets.xboxservices.com/assets/dd/a1/dda1aa1d-99f2-470b-9773-710eabf849e0.jpg?n=Game-Pass-Deals_Boxshot-0_XGP-Logo_720x1080.jpg" src="https://assets.xboxservices.com/assets/dd/a1/dda1aa1d-99f2-470b-9773-710eabf849e0.jpg?n=Game-Pass-Deals_Boxshot-0_XGP-Logo_720x1080.jpg" alt="explore all games image">' +
                        '</picture>' +
                        '<div>' +
                        '<h3 class="c-heading">' + locStrings["keyExploreall"].toUpperCase() + '</h3>' +
                        '</div>' +
                        '</a>' +
                        '</section>' +
                        '</li>');
                        clearInterval(activecheck);
                    }
                    
                
            }, 100)
        }




       function populateGamesData(data) {
        var locStrings = globalLocStrings.locales[urlRegion];
            // var bigidUrls = biUrls.items.urls;
            // var biuArray = Object.keys(bigidUrls);
    
            var productQuantity = data.Products.length;

            
            for (var x = 0; x < productQuantity; x++) {


                // Item Id/Title
                var itemId = data.Products[x].ProductId.toUpperCase();
                
                var itemTitle = data.Products[x].LocalizedProperties[0].ProductTitle;
                
                if (itemTitle === undefined) {
                    itemTitle = "";
                }
                var itemUrlName = itemTitle.toLowerCase().replace(/\s/g, "-").replace(/[^a-z0-9-]/gi, "");
                if (itemUrlName === "") {
                    itemUrlName = "-"
                }
    
                var shortDesc = data.Products[x].LocalizedProperties[0].ShortDescription;
                if (shortDesc === "") {
                    shortDesc = data.Products[x].LocalizedProperties[0].ProductDescription;
                }
                if (shortDesc === undefined) {
                    shortDesc = "";
                }
    
                var imagesNum = data.Products[x].LocalizedProperties[0].Images.length;
                var imgEnd = 999;
    
                for (var j = 0; j < imagesNum; j++) {
                    if (data.Products[x].LocalizedProperties[0].Images[j].ImagePurpose === "Poster") {
                        imgEnd = j;
                        break;
                    }
                }
    
                if (imgEnd === 999) {
                    for (var j = 0; j < imagesNum; j++) {
                        if (data.Products[x].LocalizedProperties[0].Images[j].Width < data.Products[x].LocalizedProperties[0].Images[j].Height) {
                            imgEnd = j;
                            break
                        }
                    }
                }
    
                if (imgEnd === 999) {
                    imgEnd = 1;
                }
    
                // Grabbing Image Path
                if (data.Products[x].LocalizedProperties[0].Images[imgEnd]) {
                    var itemBoxshot = data.Products[x].LocalizedProperties[0].Images[imgEnd].Uri.replace("http:", "https:");
                    var itemBoxshotSmall;
                } else {
                    var itemBoxshot = "https://assets.xboxservices.com/assets/5a/e5/5ae523e2-593f-4eda-ba08-56e5c68ca289.jpg?n=X1-Standard-digital-boxshot_584x800.jpg";
                    var itemBoxshotSmall = "https://assets.xboxservices.com/assets/5a/e5/5ae523e2-593f-4eda-ba08-56e5c68ca289.jpg?n=X1-Standard-digital-boxshot_584x800.jpg";
                }
                if (itemBoxshot.indexOf("xboxlive.com") !== -1) {
                    itemBoxshotSmall = itemBoxshot + "&w=140&format=jpg";
                    itemBoxshot = itemBoxshot + "&h=300&w=200&format=jpg";
                } else {
                    itemBoxshotSmall = itemBoxshot;
                }
    
                // URL
                var itemhref = 'https://www.xbox.com/' + urlRegion + '/play/games/' + itemUrlName + '/' + itemId;

                var cardObj = {
                    itemId: itemId,
                    itemhref: itemhref,
                    itemTitle: itemTitle,
                    locStrings: locStrings,
                    itemBoxshot: itemBoxshot,
                    itemTitle: itemTitle
                }

                 if(cardObj.itemhref.includes('/play')) {
                    cardObj.itemhref = cardObj.itemhref.replace('/play/games', "/games/store");
                   // console.log(cardObj.itemhref)
                }

    
                $(".recentDeals" + " ul").append('<li>' +
                    '<section class="m-product-placement-item f-size-large context-device f-clean" data-prodid="' + cardObj.itemId + '">' +
                    '<a class="ignoreContStore" target="blank" href="' + cardObj.itemhref + '" data-retailer="MS Store" aria-label="' + cardObj.itemTitle + ' ' + cardObj.locStrings["keyLearnmoregamearia"] + '">' +
                    '<picture>' +
                    '<source srcset="' + cardObj.itemBoxshot + '" media="(min-width:0)">' +
                    '<img class="c-image" srcset="' + cardObj.itemBoxshot + '" src="' + cardObj.itemBoxshot + '" ' +
                    'alt="' + cardObj.itemTitle + ' boxshot">' +
                    '</picture>' +
                    '<div>' +
                    '<h3 class="c-heading">' + cardObj.itemTitle + '</h3>' +
                    '</div>' +
                    '</a>' +
                    '</section>' +
                    '</li>').fadeIn(500)

            }

        

            // Adding last tile
            var activecheck = setInterval(function() {
                var check = $(".recentDeals .m-product-placement-item").length
                var activeAjax = $(".recentDeals .m-product-placement-item").length >= 9;
                //console.log(check)
                if (activeAjax === true) {

                    var locStrings = globalLocStrings.locales[urlRegion];
                    $(".recentDeals").find("ul").append('<li>' +
                        '<section class="m-product-placement-item f-size-large context-device f-clean">' +
                        '<a target="_blank" href="https://www.xbox.com/xbox-game-pass/games#consolegames" data-cta="learn" aria-label="' + locStrings["keyExploreallaria"] + '">' +
                        '<picture>' +
                        '<source srcset="https://assets.xboxservices.com/assets/dd/a1/dda1aa1d-99f2-470b-9773-710eabf849e0.jpg?n=Game-Pass-Deals_Boxshot-0_XGP-Logo_720x1080.jpg" media="(min-width:0)">' +
                        '<img class="c-image" srcset="https://assets.xboxservices.com/assets/dd/a1/dda1aa1d-99f2-470b-9773-710eabf849e0.jpg?n=Game-Pass-Deals_Boxshot-0_XGP-Logo_720x1080.jpg" src="https://assets.xboxservices.com/assets/dd/a1/dda1aa1d-99f2-470b-9773-710eabf849e0.jpg?n=Game-Pass-Deals_Boxshot-0_XGP-Logo_720x1080.jpg" alt="explore all games image">' +
                        '</picture>' +
                        '<div>' +
                        '<h3 class="c-heading">' + locStrings["keyExploreall"].toUpperCase() + '</h3>' +
                        '</div>' +
                        '</a>' +
                        '</section>' +
                        '</li>');
                        clearInterval(activecheck);
                    }
                    
                
            }, 100)
        }

    




    globalLocStrings = {
        "locales": {
          "en-us": {
              "keyExploreall": "Explore all games",
              "keyExploreallaria": "Explore all Xbox Game Pass Games",
              "keyLearnmoregamearia": "Learn more about "
          },
          "ar-ae": {
              "keyExploreall": "Explore all games",
              "keyExploreallaria": "Explore all Xbox Game Pass Games",
              "keyLearnmoregamearia": "Learn more about "
          },
          "ar-sa": {
              "keyExploreall": "Explore all games",
              "keyExploreallaria": "Explore all Xbox Game Pass Games",
              "keyLearnmoregamearia": "Learn more about "
          },
          "cs-cz": {
              "keyExploreall": "Procházet hry",
              "keyExploreallaria": "Explore all Xbox Game Pass Games",
              "keyLearnmoregamearia": "Learn more about "
          },
          "da-dk": {
              "keyExploreall": "Udforsk spil",
              "keyExploreallaria": "Explore all Xbox Game Pass Games",
              "keyLearnmoregamearia": "Learn more about "
          },
          "de-at": {
              "keyExploreall": "Spiele erkunden",
              "keyExploreallaria": "Explore all Xbox Game Pass Games",
              "keyLearnmoregamearia": "Learn more about "
          },
          "de-ch": {
              "keyExploreall": "Spiele erkunden",
              "keyExploreallaria": "Explore all Xbox Game Pass Games",
              "keyLearnmoregamearia": "Learn more about "
          },
          "de-de": {
              "keyExploreall": "Spiele erkunden",
              "keyExploreallaria": "Explore all Xbox Game Pass Games",
              "keyLearnmoregamearia": "Learn more about "
          },
          "el-gr": {
              "keyExploreall": "Explore all games",
              "keyExploreallaria": "Explore all Xbox Game Pass Games",
              "keyLearnmoregamearia": "Learn more about "
          },
          "en-au": {
              "keyExploreall": "Explore all games",
              "keyExploreallaria": "Explore all Xbox Game Pass Games",
              "keyLearnmoregamearia": "Learn more about "
          },
          "en-ca": {
              "keyExploreall": "Explore all games",
              "keyExploreallaria": "Explore all Xbox Game Pass Games",
              "keyLearnmoregamearia": "Learn more about "
          },
          "en-gb": {
              "keyExploreall": "Explore all games",
              "keyExploreallaria": "Explore all Xbox Game Pass Games",
              "keyLearnmoregamearia": "Learn more about "
          },
          "en-hk": {
              "keyExploreall": "Explore all games",
              "keyExploreallaria": "Explore all Xbox Game Pass Games",
              "keyLearnmoregamearia": "Learn more about "
          },
          "en-ie": {
              "keyExploreall": "Explore all games",
              "keyExploreallaria": "Explore all Xbox Game Pass Games",
              "keyLearnmoregamearia": "Learn more about "
          },
          "en-in": {
              "keyExploreall": "Explore all games",
              "keyExploreallaria": "Explore all Xbox Game Pass Games",
              "keyLearnmoregamearia": "Learn more about "
          },
          "en-nz": {
              "keyExploreall": "Explore all games",
              "keyExploreallaria": "Explore all Xbox Game Pass Games",
              "keyLearnmoregamearia": "Learn more about "
          },
          "en-sg": {
              "keyExploreall": "Explore all games",
              "keyExploreallaria": "Explore all Xbox Game Pass Games",
              "keyLearnmoregamearia": "Learn more about "
          },
          "en-za": {
              "keyExploreall": "Explore all games",
              "keyExploreallaria": "Explore all Xbox Game Pass Games",
              "keyLearnmoregamearia": "Learn more about "
          },
          "es-ar": {
              "keyExploreall": "Explore all games",
              "keyExploreallaria": "Explore all Xbox Game Pass Games",
              "keyLearnmoregamearia": "Learn more about "
          },
          "es-cl": {
              "keyExploreall": "Explore all games",
              "keyExploreallaria": "Explore all Xbox Game Pass Games",
              "keyLearnmoregamearia": "Learn more about "
          },
          "es-co": {
              "keyExploreall": "Explore all games",
              "keyExploreallaria": "Explore all Xbox Game Pass Games",
              "keyLearnmoregamearia": "Learn more about "
          },
          "es-es": {
              "keyExploreall": "Explorar los juegos",
              "keyExploreallaria": "Explore all Xbox Game Pass Games",
              "keyLearnmoregamearia": "Learn more about "
          },
          "es-mx": {
              "keyExploreall": "Explore all games",
              "keyExploreallaria": "Explore all Xbox Game Pass Games",
              "keyLearnmoregamearia": "Learn more about "
          },
          "fi-fi": {
              "keyExploreall": "Selaa pelejä",
              "keyExploreallaria": "Explore all Xbox Game Pass Games",
              "keyLearnmoregamearia": "Learn more about "
          },
          "fr-be": {
              "keyExploreall": "Explorer les jeux",
              "keyExploreallaria": "Explore all Xbox Game Pass Games",
              "keyLearnmoregamearia": "Learn more about "
          },
          "fr-ca": {
              "keyExploreall": "Découvrez les jeux",
              "keyExploreallaria": "Explore all Xbox Game Pass Games",
              "keyLearnmoregamearia": "Learn more about "
          },
          "fr-ch": {
              "keyExploreall": "Explorer les jeux",
              "keyExploreallaria": "Explore all Xbox Game Pass Games",
              "keyLearnmoregamearia": "Learn more about "
          },
          "fr-fr": {
              "keyExploreall": "Explorer les jeux",
              "keyExploreallaria": "Explore all Xbox Game Pass Games",
              "keyLearnmoregamearia": "Learn more about "
          },
          "he-il": {
              "keyExploreall": "Explore all games",
              "keyExploreallaria": "Explore all Xbox Game Pass Games",
              "keyLearnmoregamearia": "Learn more about "
          },
          "hu-hu": {
              "keyExploreall": "Játékok felfedezése",
              "keyExploreallaria": "Explore all Xbox Game Pass Games",
              "keyLearnmoregamearia": "Learn more about "
          },
          "it-it": {
              "keyExploreall": "Esplora i giochi",
              "keyExploreallaria": "Explore all Xbox Game Pass Games",
              "keyLearnmoregamearia": "Learn more about "
          },
          "ja-jp": {
              "keyExploreall": "Explore all games",
              "keyExploreallaria": "Explore all Xbox Game Pass Games",
              "keyLearnmoregamearia": "Learn more about "
          },
          "ko-kr": {
              "keyExploreall": "게임 살펴보기",
              "keyExploreallaria": "Explore all Xbox Game Pass Games",
              "keyLearnmoregamearia": "Learn more about "
          },
          "nb-no": {
              "keyExploreall": "Utforsk spill",
              "keyExploreallaria": "Explore all Xbox Game Pass Games",
              "keyLearnmoregamearia": "Learn more about "
          },
          "nl-be": {
              "keyExploreall": "Gamen op een hoger niveau",
              "keyExploreallaria": "Explore all Xbox Game Pass Games",
              "keyLearnmoregamearia": "Learn more about "
          },
          "nl-nl": {
              "keyExploreall": "Gamen op een hoger niveau",
              "keyExploreallaria": "Explore all Xbox Game Pass Games",
              "keyLearnmoregamearia": "Learn more about "
          },
          "pl-pl": {
              "keyExploreall": "Ulepsz swoją grę",
              "keyExploreallaria": "Explore all Xbox Game Pass Games",
              "keyLearnmoregamearia": "Learn more about "
          },
          "pt-br": {
              "keyExploreall": "Eleva o teu jogo",
              "keyExploreallaria": "Explore all Xbox Game Pass Games",
              "keyLearnmoregamearia": "Learn more about "
          },
          "pt-pt": {
              "keyExploreall": "Explore all games",
              "keyExploreallaria": "Explore all Xbox Game Pass Games",
              "keyLearnmoregamearia": "Learn more about "
          },
          "ru-ru": {
              "keyExploreall": "Explore all games",
              "keyExploreallaria": "Explore all Xbox Game Pass Games",
              "keyLearnmoregamearia": "Learn more about "
          },
          "sk-sk": {
              "keyExploreall": "Nová úroveň hrania",
              "keyExploreallaria": "Explore all Xbox Game Pass Games",
              "keyLearnmoregamearia": "Learn more about "
          },
          "sv-se": {
              "keyExploreall": "Förstärk spelkänslan",
              "keyExploreallaria": "Explore all Xbox Game Pass Games",
              "keyLearnmoregamearia": "Learn more about "
          },
          "tr-tr": {
              "keyExploreall": "Explore all games",
              "keyExploreallaria": "Explore all Xbox Game Pass Games",
              "keyLearnmoregamearia": "Learn more about "
          },
          "zh-hk": {
              "keyExploreall": "Explore all games",
              "keyExploreallaria": "Explore all Xbox Game Pass Games",
              "keyLearnmoregamearia": "Learn more about "
          },
          "zh-tw": {
              "keyExploreall": "Explore all games",
              "keyExploreallaria": "Explore all Xbox Game Pass Games",
              "keyLearnmoregamearia": "Learn more about "
          }
        }
      }



    
})